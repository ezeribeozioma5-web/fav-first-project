import { useState } from 'react';
import { View, Text, FlatList, Pressable, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as DocumentPicker from 'expo-document-picker';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { supabase } from '@/services/supabase';
import { useAuthStore } from '@/stores/useAuthStore';
import { useIsOffline } from '@/hooks/useIsOffline';

interface UploadedNote {
  id: string;
  title: string;
  fileType: string;
  status: 'uploading' | 'processing' | 'done' | 'failed';
}

const FILE_ICON: Record<string, string> = {
  pdf: '📕',
  docx: '📘',
  pptx: '📙',
  image: '🖼️',
  text: '📄',
};

export default function NotesUpload() {
  const { session } = useAuthStore();
  const isOffline = useIsOffline();
  const [notes, setNotes] = useState<UploadedNote[]>([]);
  const [picking, setPicking] = useState(false);

  const pickAndUpload = async () => {
    if (isOffline) return; // button is disabled in this state; guard belt-and-braces
    const result = await DocumentPicker.getDocumentAsync({
      type: ['application/pdf', 'image/*', 'text/plain',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation'],
      copyToCacheDirectory: true,
    });
    if (result.canceled || !session) return;

    const file = result.assets[0];
    const tempId = Date.now().toString();
    const ext = file.name.split('.').pop()?.toLowerCase() ?? 'text';
    const fileType = ext === 'pdf' ? 'pdf' : ext === 'docx' ? 'docx' : ext === 'pptx' ? 'pptx' : 'text';

    setNotes((prev) => [{ id: tempId, title: file.name, fileType, status: 'uploading' }, ...prev]);
    setPicking(true);

    try {
      const path = `${session.user.id}/${tempId}-${file.name}`;
      const fileData = await fetch(file.uri).then((r) => r.blob());

      const { error: uploadError } = await supabase.storage.from('notes').upload(path, fileData);
      if (uploadError) throw uploadError;

      // Insert the DB row, then explicitly invoke `process-note` — the
      // client-triggered approach we're using for MVP (see README).
      const { data: noteRow, error: insertError } = await supabase
        .from('notes')
        .insert({
          user_id: session.user.id,
          title: file.name,
          file_path: path,
          file_type: fileType,
          processing_status: 'pending',
        } as any)
        .select()
        .single();
      if (insertError) throw insertError;

      setNotes((prev) => prev.map((n) => (n.id === tempId ? { ...n, status: 'processing' } : n)));

      const { data, error: fnError } = await supabase.functions.invoke('process-note', {
        body: { note_id: noteRow.id },
      });
      if (fnError) {
        const message = (fnError as any)?.context?.message ?? 'Note processing failed.';
        throw new Error(message);
      }

      setNotes((prev) =>
        prev.map((n) => (n.id === tempId ? { ...n, status: data?.note?.processing_status ?? 'done' } : n))
      );
    } catch (e) {
      setNotes((prev) => prev.map((n) => (n.id === tempId ? { ...n, status: 'failed' } : n)));
    } finally {
      setPicking(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-bg-light">
      <View className="px-6 pt-2 pb-4">
        <Text className="text-2xl font-bold text-ink">Your Notes</Text>
        <Text className="text-ink-muted text-sm mt-1">
          Upload lecture notes, slides, or textbook pages — AI turns them into study material.
        </Text>
      </View>

      <View className="px-6 mb-4">
        <Button
          label={isOffline ? 'Offline — reconnect to upload' : picking ? 'Uploading...' : '📤  Upload a note'}
          onPress={pickAndUpload}
          loading={picking}
          disabled={isOffline}
        />
      </View>

      {notes.length === 0 ? (
        <View className="flex-1 items-center justify-center px-10">
          <Text className="text-5xl mb-4">📚</Text>
          <Text className="text-ink font-semibold text-base mb-1">No notes yet</Text>
          <Text className="text-ink-muted text-sm text-center">
            Upload your first PDF, Word doc, slides, or a photo of your notes to get started.
          </Text>
        </View>
      ) : (
        <FlatList
          data={notes}
          keyExtractor={(n) => n.id}
          contentContainerClassName="px-6 gap-3 pb-6"
          renderItem={({ item }) => (
            <Card className="flex-row items-center">
              <Text className="text-2xl mr-3">{FILE_ICON[item.fileType]}</Text>
              <View className="flex-1">
                <Text className="text-ink font-semibold" numberOfLines={1}>
                  {item.title}
                </Text>
                <StatusLabel status={item.status} />
              </View>
              {(item.status === 'uploading' || item.status === 'processing') && (
                <ActivityIndicator color="#6C5CE7" />
              )}
            </Card>
          )}
        />
      )}
    </SafeAreaView>
  );
}

function StatusLabel({ status }: { status: UploadedNote['status'] }) {
  const map: Record<UploadedNote['status'], { text: string; className: string }> = {
    uploading: { text: 'Uploading...', className: 'text-ink-muted' },
    processing: { text: 'AI is reading this note...', className: 'text-primary' },
    done: { text: 'Ready — tap to generate flashcards or a quiz', className: 'text-secondary' },
    failed: { text: 'Upload failed — tap to retry', className: 'text-danger' },
  };
  const { text, className } = map[status];
  return <Text className={`text-xs mt-0.5 ${className}`}>{text}</Text>;
}
