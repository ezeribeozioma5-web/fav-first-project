import { useState } from 'react';
import { View, Text, TextInput, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { useAuthStore } from '@/stores/useAuthStore';
import { FREE_TIER_LIMITS } from '@/theme/tokens';
import { supabase } from '@/services/supabase';
import { useIsOffline } from '@/hooks/useIsOffline';

export default function QuizGenerator() {
  const { profile } = useAuthStore();
  const isPremium = profile?.plan === 'premium';
  const isOffline = useIsOffline();
  const [topic, setTopic] = useState('');
  const [generating, setGenerating] = useState(false);
  const [usedToday, setUsedToday] = useState(0); // TODO: hydrate from ai_usage_log
  const [serverLimitReached, setServerLimitReached] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const remaining = FREE_TIER_LIMITS.quizGenerationsPerDay - usedToday;
  const limitReached = (!isPremium && remaining <= 0) || serverLimitReached;

  const generate = async () => {
    if (!topic.trim() || limitReached) return;
    if (isOffline) {
      setErrorMessage("You're offline — reconnect to generate a quiz.");
      return;
    }
    setGenerating(true);
    setErrorMessage(null);
    try {
      // Calls the topic-based `generate-quiz` Edge Function, which enforces
      // the daily quiz cap server-side and returns the created quiz + questions.
      const { data, error } = await supabase.functions.invoke('generate-quiz', { body: { topic } });
      if (error) {
        const ctx = (error as any)?.context;
        if (ctx?.error === 'daily_limit_reached') setServerLimitReached(true);
        setErrorMessage(ctx?.message ?? 'Could not generate a quiz. Please try again.');
        return;
      }
      setUsedToday((n) => n + 1);
      // data.quiz / data.questions are ready here — navigate to a
      // quiz-taking screen once that's built (Phase 2).
    } finally {
      setGenerating(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-bg-light">
      <ScrollView contentContainerClassName="px-6 pt-2 pb-8">
        <Text className="text-2xl font-bold text-ink mb-1">Practice</Text>
        <Text className="text-ink-muted text-sm mb-6">
          Generate a quick quiz on any topic, or from one of your uploaded notes.
        </Text>

        {!isPremium && (
          <View className="bg-primary-light/15 rounded-card px-4 py-3 mb-5 flex-row justify-between items-center">
            <Text className="text-primary text-sm font-semibold">
              {Math.max(remaining, 0)}/{FREE_TIER_LIMITS.quizGenerationsPerDay} quizzes left today
            </Text>
          </View>
        )}

        <Card className="mb-6">
          <Text className="text-ink font-semibold mb-2">What do you want to practice?</Text>
          <TextInput
            value={topic}
            onChangeText={setTopic}
            placeholder="e.g. Photosynthesis, Newton's laws, French Revolution..."
            className="bg-bg-light rounded-card px-4 py-3 border border-ink/10 text-base mb-4"
          />
          <Button
            label={limitReached ? 'Daily limit reached' : generating ? 'Generating...' : 'Generate quiz'}
            onPress={generate}
            loading={generating}
            disabled={limitReached || !topic.trim()}
          />
          {errorMessage && <Text className="text-danger text-sm mt-3">{errorMessage}</Text>}
        </Card>

        <Text className="text-lg font-bold text-ink mb-3">Quick start</Text>
        <View className="flex-row flex-wrap gap-2">
          {['Daily practice', 'From my notes', 'Timed quiz'].map((label) => (
            <View key={label} className="bg-white border border-ink/10 rounded-pill px-4 py-2">
              <Text className="text-ink text-sm font-medium">{label}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
