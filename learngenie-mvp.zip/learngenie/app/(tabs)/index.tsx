import { View, Text, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Card } from '@/components/Card';
import { StreakBadge } from '@/components/StreakBadge';
import { useAuthStore } from '@/stores/useAuthStore';

const QUICK_ACTIONS = [
  { id: 'upload', emoji: '📤', label: 'Upload notes', route: '/(tabs)/notes', color: 'bg-primary' },
  { id: 'tutor', emoji: '🤖', label: 'Ask AI Tutor', route: '/(tabs)/tutor', color: 'bg-secondary' },
  { id: 'quiz', emoji: '🎯', label: 'Practice quiz', route: '/(tabs)/quiz', color: 'bg-warning' },
] as const;

export default function Dashboard() {
  const { profile } = useAuthStore();
  const router = useRouter();

  const firstName = profile?.full_name?.split(' ')[0] ?? 'there';

  return (
    <SafeAreaView className="flex-1 bg-bg-light">
      <ScrollView contentContainerClassName="px-6 pb-8" showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="flex-row items-center justify-between mt-2 mb-6">
          <View>
            <Text className="text-ink-muted text-sm">Welcome back,</Text>
            <Text className="text-2xl font-bold text-ink">{firstName} 👋</Text>
          </View>
          <StreakBadge count={profile?.streak_count ?? 0} />
        </View>

        {/* Today's focus / exam readiness placeholder */}
        <Card className="mb-6 bg-primary">
          <Text className="text-white/80 text-sm mb-1">Today's focus</Text>
          <Text className="text-white text-lg font-semibold mb-3">
            No study plan yet — set one up to get daily topics here.
          </Text>
          <Pressable className="self-start bg-white/15 rounded-pill px-4 py-2">
            <Text className="text-white font-semibold text-sm">Create a study plan →</Text>
          </Pressable>
        </Card>

        {/* Quick actions */}
        <Text className="text-lg font-bold text-ink mb-3">Quick actions</Text>
        <View className="flex-row gap-3 mb-6">
          {QUICK_ACTIONS.map((action) => (
            <Pressable
              key={action.id}
              onPress={() => router.push(action.route as any)}
              className="flex-1 bg-white rounded-card p-4 items-center border border-ink/5"
            >
              <View className={`${action.color} w-11 h-11 rounded-full items-center justify-center mb-2`}>
                <Text className="text-lg">{action.emoji}</Text>
              </View>
              <Text className="text-ink text-xs font-semibold text-center">{action.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* Progress snapshot */}
        <Text className="text-lg font-bold text-ink mb-3">This week</Text>
        <View className="flex-row gap-3">
          <Card className="flex-1 items-center py-5">
            <Text className="text-2xl font-bold text-primary">0</Text>
            <Text className="text-ink-muted text-xs mt-1">Quizzes done</Text>
          </Card>
          <Card className="flex-1 items-center py-5">
            <Text className="text-2xl font-bold text-secondary">0h</Text>
            <Text className="text-ink-muted text-xs mt-1">Hours studied</Text>
          </Card>
          <Card className="flex-1 items-center py-5">
            <Text className="text-2xl font-bold text-warning">—</Text>
            <Text className="text-ink-muted text-xs mt-1">Avg score</Text>
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
