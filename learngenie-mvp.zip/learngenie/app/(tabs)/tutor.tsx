import { useState, useRef } from 'react';
import { View, Text, TextInput, FlatList, Pressable, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuthStore } from '@/stores/useAuthStore';
import { FREE_TIER_LIMITS } from '@/theme/tokens';
import { supabase } from '@/services/supabase';
import { useIsOffline } from '@/hooks/useIsOffline';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export default function TutorChat() {
  const { profile } = useAuthStore();
  const isPremium = profile?.plan === 'premium';
  const isOffline = useIsOffline();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "Hi! I'm your AI tutor 👋 Ask me to explain a topic, walk through a problem, or quiz you on something you've studied.",
    },
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [usedToday, setUsedToday] = useState(0); // TODO: hydrate from ai_usage_log via Edge Function
  const [serverLimitReached, setServerLimitReached] = useState(false);
  const listRef = useRef<FlatList>(null);

  const remaining = FREE_TIER_LIMITS.tutorMessagesPerDay - usedToday;
  const limitReached = (!isPremium && remaining <= 0) || serverLimitReached;

  const send = async () => {
    if (!input.trim() || limitReached || sending) return;

    if (isOffline) {
      setMessages((prev) => [
        ...prev,
        { id: `${Date.now()}-offline`, role: 'assistant', content: "You're offline — reconnect to talk to your AI tutor." },
      ]);
      return;
    }

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: input.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setSending(true);

    try {
      // Calls the `ai-tutor-chat` Edge Function, which enforces the daily cap
      // server-side, injects the student's recent weak-topics for context,
      // and proxies to Claude. This is a thin client — no AI keys here.
      const { data, error } = await supabase.functions.invoke('ai-tutor-chat', {
        body: { message: userMsg.content },
      });

      if (error) {
        const ctx = (error as any)?.context;
        if (ctx?.error === 'daily_limit_reached') {
          setServerLimitReached(true);
        }
        throw new Error(ctx?.message ?? 'Something went wrong. Please try again.');
      }

      setMessages((prev) => [...prev, { id: `${Date.now()}-ai`, role: 'assistant', content: data.reply }]);
      setUsedToday((n) => n + 1);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `${Date.now()}-err`,
          role: 'assistant',
          content: e?.message ?? "Sorry, I couldn't respond just now — please try again.",
        },
      ]);
    } finally {
      setSending(false);
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-bg-light">
      {/* Header with usage indicator */}
      <View className="flex-row items-center justify-between px-6 py-3 border-b border-ink/5">
        <Text className="text-xl font-bold text-ink">AI Tutor</Text>
        {!isPremium && (
          <View className="bg-primary-light/20 rounded-pill px-3 py-1">
            <Text className="text-primary text-xs font-semibold">
              {Math.max(remaining, 0)}/{FREE_TIER_LIMITS.tutorMessagesPerDay} today
            </Text>
          </View>
        )}
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1" keyboardVerticalOffset={90}>
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(m) => m.id}
          contentContainerClassName="px-4 py-4 gap-3"
          renderItem={({ item }) => (
            <View className={`max-w-[85%] ${item.role === 'user' ? 'self-end' : 'self-start'}`}>
              <View
                className={`rounded-card px-4 py-3 ${
                  item.role === 'user' ? 'bg-primary rounded-br-sm' : 'bg-white border border-ink/5 rounded-bl-sm'
                }`}
              >
                <Text className={item.role === 'user' ? 'text-white' : 'text-ink'}>{item.content}</Text>
              </View>
            </View>
          )}
        />

        {limitReached ? (
          <View className="mx-4 mb-4 bg-warning/10 rounded-card p-4">
            <Text className="text-ink font-semibold mb-1">Daily limit reached</Text>
            <Text className="text-ink-muted text-sm mb-3">
              You've used all {FREE_TIER_LIMITS.tutorMessagesPerDay} free messages today. Resets in 24h, or go
              Premium for unlimited tutoring.
            </Text>
            <Pressable className="bg-primary rounded-pill py-2.5 items-center">
              <Text className="text-white font-semibold text-sm">Upgrade to Premium</Text>
            </Pressable>
          </View>
        ) : (
          <View className="flex-row items-end gap-2 px-4 py-3 border-t border-ink/5 bg-bg-light">
            <TextInput
              value={input}
              onChangeText={setInput}
              placeholder="Ask about anything you're studying..."
              multiline
              className="flex-1 bg-white rounded-card px-4 py-3 border border-ink/10 max-h-28 text-base"
            />
            <Pressable
              onPress={send}
              disabled={!input.trim() || sending}
              className={`w-11 h-11 rounded-full items-center justify-center ${
                input.trim() ? 'bg-primary' : 'bg-primary/30'
              }`}
            >
              <Text className="text-white text-lg">↑</Text>
            </Pressable>
          </View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
