import { View, Text, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Card } from '@/components/Card';
import { useAuthStore } from '@/stores/useAuthStore';

const MENU = [
  { label: 'Edit profile', icon: '✏️' },
  { label: 'Notification settings', icon: '🔔' },
  { label: 'Appearance', icon: '🌗' },
  { label: 'Manage subscription', icon: '💎' },
  { label: 'Privacy & data', icon: '🔒' },
  { label: 'Help & support', icon: '💬' },
];

export default function Profile() {
  const { profile, signOut } = useAuthStore();

  return (
    <SafeAreaView className="flex-1 bg-bg-light">
      <ScrollView contentContainerClassName="px-6 pt-2 pb-8">
        <View className="items-center mb-6">
          <View className="w-20 h-20 rounded-full bg-primary-light/30 items-center justify-center mb-3">
            <Text className="text-3xl">{profile?.full_name?.[0]?.toUpperCase() ?? '🎓'}</Text>
          </View>
          <Text className="text-xl font-bold text-ink">{profile?.full_name ?? 'Student'}</Text>
          <View className={`mt-2 rounded-pill px-3 py-1 ${profile?.plan === 'premium' ? 'bg-warning/15' : 'bg-ink/5'}`}>
            <Text className={`text-xs font-semibold ${profile?.plan === 'premium' ? 'text-warning' : 'text-ink-muted'}`}>
              {profile?.plan === 'premium' ? '💎 Premium' : 'Free plan'}
            </Text>
          </View>
        </View>

        {profile?.plan !== 'premium' && (
          <Card className="mb-6 bg-primary">
            <Text className="text-white font-bold text-base mb-1">Go Premium</Text>
            <Text className="text-white/80 text-sm mb-3">
              Unlimited AI tutoring, unlimited quizzes, and full note-to-flashcard conversion.
            </Text>
            <Pressable className="self-start bg-white rounded-pill px-4 py-2">
              <Text className="text-primary font-semibold text-sm">Upgrade now</Text>
            </Pressable>
          </Card>
        )}

        <Card className="p-0 overflow-hidden mb-6">
          {MENU.map((item, i) => (
            <Pressable
              key={item.label}
              className={`flex-row items-center px-4 py-4 ${i !== MENU.length - 1 ? 'border-b border-ink/5' : ''}`}
            >
              <Text className="text-lg mr-3">{item.icon}</Text>
              <Text className="flex-1 text-ink text-base">{item.label}</Text>
              <Text className="text-ink-muted">›</Text>
            </Pressable>
          ))}
        </Card>

        <Pressable onPress={signOut} className="items-center py-3">
          <Text className="text-danger font-semibold">Log out</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}
