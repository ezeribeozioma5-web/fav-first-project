import { useEffect } from 'react';
import { View, Text } from 'react-native';
import { useRouter } from 'expo-router';
import Animated, { useSharedValue, useAnimatedStyle, withSpring, withTiming, withSequence } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuthStore } from '@/stores/useAuthStore';

export default function SplashScreen() {
  const router = useRouter();
  const { session } = useAuthStore();
  const scale = useSharedValue(0.7);
  const opacity = useSharedValue(0);

  const logoStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));

  useEffect(() => {
    scale.value = withSpring(1, { damping: 8, stiffness: 90 });
    opacity.value = withTiming(1, { duration: 500 });

    const timer = setTimeout(async () => {
      const seenOnboarding = await AsyncStorage.getItem('onboarding_seen');
      if (session) {
        router.replace('/(tabs)');
      } else if (seenOnboarding) {
        router.replace('/(auth)/login');
      } else {
        router.replace('/onboarding');
      }
    }, 1400);

    return () => clearTimeout(timer);
  }, [session]);

  return (
    <LinearGradient colors={['#6C5CE7', '#5546C8']} className="flex-1 items-center justify-center">
      <Animated.View style={logoStyle} className="items-center">
        <View className="w-20 h-20 bg-white/15 rounded-[24px] items-center justify-center mb-4">
          <Text className="text-4xl">✨</Text>
        </View>
        <Text className="text-white text-3xl font-bold">LearnGenie</Text>
        <Text className="text-white/70 text-base mt-1">Study smarter, not harder</Text>
      </Animated.View>
    </LinearGradient>
  );
}
