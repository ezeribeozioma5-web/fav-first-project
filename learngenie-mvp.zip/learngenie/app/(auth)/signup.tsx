import { useState } from 'react';
import { View, Text, TextInput, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Link, useRouter } from 'expo-router';
import { Button } from '@/components/Button';
import { supabase } from '@/services/supabase';

export default function Signup() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const handleSignup = async () => {
    setError(null);
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    // A DB trigger (see supabase/schema.sql) creates the `profiles` row
    // automatically on signup, defaulted to the free plan.
    if (data.session) {
      router.replace('/(tabs)');
    } else {
      // Email confirmation required
      router.replace('/(auth)/login');
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-bg-light">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1">
        <ScrollView contentContainerClassName="flex-1 px-6 justify-center" keyboardShouldPersistTaps="handled">
          <Text className="text-3xl font-bold text-ink mb-1">Create your account</Text>
          <Text className="text-base text-ink-muted mb-8">Start studying smarter today.</Text>

          <Text className="text-sm font-medium text-ink mb-1.5">Full name</Text>
          <TextInput
            value={fullName}
            onChangeText={setFullName}
            placeholder="Ada Lovelace"
            className="bg-white rounded-card px-4 py-3.5 mb-4 border border-ink/10 text-base"
          />

          <Text className="text-sm font-medium text-ink mb-1.5">Email</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            placeholder="you@school.edu"
            className="bg-white rounded-card px-4 py-3.5 mb-4 border border-ink/10 text-base"
          />

          <Text className="text-sm font-medium text-ink mb-1.5">Password</Text>
          <TextInput
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            placeholder="At least 6 characters"
            className="bg-white rounded-card px-4 py-3.5 mb-2 border border-ink/10 text-base"
          />

          {error && <Text className="text-danger text-sm mb-2">{error}</Text>}

          <View className="mt-4">
            <Button label="Create Account" onPress={handleSignup} loading={loading} />
          </View>

          <View className="flex-row justify-center mt-6">
            <Text className="text-ink-muted">Already have an account? </Text>
            <Link href="/(auth)/login" className="text-primary font-semibold">
              Log in
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
