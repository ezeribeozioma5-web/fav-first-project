import { useState } from 'react';
import { View, Text, TextInput, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Link, useRouter } from 'expo-router';
import { Button } from '@/components/Button';
import { supabase } from '@/services/supabase';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const handleLogin = async () => {
    setError(null);
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    router.replace('/(tabs)');
  };

  return (
    <SafeAreaView className="flex-1 bg-bg-light">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1">
        <ScrollView contentContainerClassName="flex-1 px-6 justify-center" keyboardShouldPersistTaps="handled">
          <Text className="text-3xl font-bold text-ink mb-1">Welcome back</Text>
          <Text className="text-base text-ink-muted mb-8">Log in to keep your streak going.</Text>

          <Text className="text-sm font-medium text-ink mb-1.5">Email</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            placeholder="you@school.edu"
            className="bg-white rounded-card px-4 py-3.5 mb-4 border border-ink/10 text-base"
          />

          <Text className="text-sm font-medium text-ink mb-1.5">Password</Text>
          <TextInput
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            placeholder="••••••••"
            className="bg-white rounded-card px-4 py-3.5 mb-2 border border-ink/10 text-base"
          />

          {error && <Text className="text-danger text-sm mb-2">{error}</Text>}

          <View className="mt-4">
            <Button label="Log In" onPress={handleLogin} loading={loading} />
          </View>

          <View className="flex-row justify-center mt-6">
            <Text className="text-ink-muted">Don't have an account? </Text>
            <Link href="/(auth)/signup" className="text-primary font-semibold">
              Sign up
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
