import { useRef, useState } from 'react';
import { View, Text, FlatList, useWindowDimensions, ViewToken } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Button } from '@/components/Button';

const SLIDES = [
  {
    emoji: '📚',
    title: 'Turn notes into study tools',
    body: 'Upload your lecture notes and let AI create summaries, flashcards, and quizzes in seconds.',
  },
  {
    emoji: '🤖',
    title: 'Ask your AI tutor anything',
    body: 'Stuck on a topic? Chat with your AI tutor for clear, patient explanations — any time.',
  },
  {
    emoji: '🎯',
    title: 'Practice smarter, not more',
    body: 'Get quizzes generated from what you actually studied, and track your progress as you go.',
  },
];

export default function Onboarding() {
  const { width } = useWindowDimensions();
  const [index, setIndex] = useState(0);
  const router = useRouter();
  const listRef = useRef<FlatList>(null);

  const onViewableItemsChanged = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => {
    if (viewableItems[0]?.index != null) setIndex(viewableItems[0].index);
  }).current;

  const finish = async () => {
    await AsyncStorage.setItem('onboarding_seen', 'true');
    router.replace('/(auth)/login');
  };

  const next = () => {
    if (index < SLIDES.length - 1) {
      listRef.current?.scrollToIndex({ index: index + 1 });
    } else {
      finish();
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-bg-light">
      <View className="flex-row justify-end px-6 pt-2">
        <Text onPress={finish} className="text-ink-muted text-base">
          Skip
        </Text>
      </View>

      <FlatList
        ref={listRef}
        data={SLIDES}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.title}
        onViewableItemsChanged={onViewableItemsChanged}
        viewabilityConfig={{ itemVisiblePercentThreshold: 60 }}
        renderItem={({ item }) => (
          <View style={{ width }} className="flex-1 items-center justify-center px-10">
            <View className="w-32 h-32 bg-primary-light/20 rounded-full items-center justify-center mb-8">
              <Text className="text-6xl">{item.emoji}</Text>
            </View>
            <Text className="text-2xl font-bold text-ink text-center mb-3">{item.title}</Text>
            <Text className="text-base text-ink-muted text-center leading-6">{item.body}</Text>
          </View>
        )}
      />

      <View className="flex-row justify-center gap-2 mb-6">
        {SLIDES.map((_, i) => (
          <View
            key={i}
            className={`h-2 rounded-full ${i === index ? 'w-6 bg-primary' : 'w-2 bg-primary/20'}`}
          />
        ))}
      </View>

      <View className="px-6 pb-6">
        <Button label={index === SLIDES.length - 1 ? "Let's get started" : 'Next'} onPress={next} />
      </View>
    </SafeAreaView>
  );
}
