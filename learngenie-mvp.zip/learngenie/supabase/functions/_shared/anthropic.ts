import { AppError } from './supabaseClient.ts';

const ANTHROPIC_API_URL = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-sonnet-4-6';

interface ContentBlock {
  type: 'text' | 'image' | 'document';
  text?: string;
  source?: { type: 'base64'; media_type: string; data: string };
}

interface CallClaudeArgs {
  system: string;
  messages: { role: 'user' | 'assistant'; content: string | ContentBlock[] }[];
  maxTokens?: number;
}

/**
 * Thin wrapper around the Anthropic Messages API. Every Edge Function
 * routes its Claude calls through here so retry/error handling and the
 * API key stay in one place.
 */
export async function callClaude({ system, messages, maxTokens = 1500 }: CallClaudeArgs): Promise<string> {
  const apiKey = Deno.env.get('ANTHROPIC_API_KEY');
  if (!apiKey) {
    throw new AppError('Server misconfiguration: missing ANTHROPIC_API_KEY', 500);
  }

  let response: Response;
  try {
    response = await fetch(ANTHROPIC_API_URL, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: maxTokens,
        system,
        messages,
      }),
    });
  } catch (e) {
    throw new AppError('Could not reach the AI service. Please try again.', 502);
  }

  if (!response.ok) {
    // Don't leak upstream error details to the client; log server-side only.
    console.error('Anthropic API error', response.status, await response.text());
    if (response.status === 429) {
      throw new AppError('The AI service is busy right now — please try again in a moment.', 503);
    }
    throw new AppError('The AI service failed to respond. Please try again.', 502);
  }

  const data = await response.json();
  const textBlock = data.content?.find((b: any) => b.type === 'text');
  if (!textBlock?.text) {
    throw new AppError('The AI returned an empty response. Please try again.', 502);
  }
  return textBlock.text as string;
}

/**
 * Claude is asked to respond with pure JSON for structured features (quiz
 * generation). This strips accidental code-fences and parses defensively,
 * since a malformed response should surface as a clean error, not a crash.
 */
export function parseJsonResponse<T>(raw: string): T {
  const cleaned = raw.replace(/```json\s*|\s*```/g, '').trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    throw new AppError('The AI response was not in the expected format. Please try again.', 502);
  }
}
