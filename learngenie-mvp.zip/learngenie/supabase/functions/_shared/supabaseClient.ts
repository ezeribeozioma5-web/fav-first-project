import { createClient, SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2.43.0';

/**
 * Creates a Supabase client scoped to the calling user's JWT (passed through
 * from the client's Authorization header). All queries through this client
 * respect RLS — this is intentional. We never use the service-role key in
 * these functions; the `check_and_log_ai_usage` Postgres function is
 * SECURITY DEFINER, so it can safely bypass RLS for the one write it needs
 * to make, without us handing out a privileged key to every function.
 */
export function createUserClient(req: Request): SupabaseClient {
  const authHeader = req.headers.get('Authorization');
  if (!authHeader) {
    throw new AppError('Missing Authorization header', 401);
  }
  return createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_ANON_KEY')!,
    { global: { headers: { Authorization: authHeader } } }
  );
}

export async function getAuthedUser(supabase: SupabaseClient) {
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) {
    throw new AppError('Invalid or expired session', 401);
  }
  return data.user;
}

/** Lets handlers throw with an intended HTTP status; caught at the top level. */
export class AppError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}
