// supabase/functions/ai-tutor-chat/index.ts
//
// Flow: check daily cap -> load recent conversation context -> call Claude ->
// persist both the user message and the assistant reply -> return the reply.
//
// Deploy: supabase functions deploy ai-tutor-chat
// Secrets required: ANTHROPIC_API_KEY (supabase secrets set ANTHROPIC_API_KEY=...)

import { handleCors, corsHeaders } from '../_shared/cors.ts';
import { createUserClient, getAuthedUser, AppError } from '../_shared/supabaseClient.ts';
import { callClaude } from '../_shared/anthropic.ts';

const DAILY_LIMIT_FREE = 10;
const CONTEXT_WINDOW = 12; // last N messages pulled in for context, keeps token cost bounded

const SYSTEM_PROMPT = `You are LearnGenie's AI Tutor, a patient, encouraging study companion for secondary
school and university students. Explain concepts clearly, use simple language and examples, break down
complex topics step by step, and check understanding by inviting follow-up questions. Keep responses
focused and study-relevant — you are not a general-purpose assistant. Never provide answers to what
appears to be a live, proctored exam or assignment being submitted for a grade; instead, help the
student understand the underlying concept.`;

interface RequestBody {
  message: string;
  subject_id?: string;
}

Deno.serve(async (req) => {
  const cors = handleCors(req);
  if (cors) return cors;

  try {
    if (req.method !== 'POST') throw new AppError('Method not allowed', 405);

    const supabase = createUserClient(req);
    const user = await getAuthedUser(supabase);

    const body = (await req.json().catch(() => null)) as RequestBody | null;
    const message = body?.message?.trim();
    if (!message) throw new AppError('A message is required.', 400);
    if (message.length > 4000) throw new AppError('Message is too long.', 400);

    // --- Server-side usage cap check (source of truth, not the client) ---
    const { data: allowed, error: usageError } = await supabase.rpc('check_and_log_ai_usage', {
      p_user_id: user.id,
      p_feature: 'tutor_chat',
      p_daily_limit: DAILY_LIMIT_FREE,
    });
    if (usageError) {
      console.error('usage check failed', usageError);
      throw new AppError('Could not verify usage limits. Please try again.', 500);
    }
    if (!allowed) {
      return new Response(
        JSON.stringify({
          error: 'daily_limit_reached',
          message: `You've used all ${DAILY_LIMIT_FREE} free tutor messages today. Upgrade to Premium for unlimited access, or try again in 24 hours.`,
        }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // --- Load recent context (for AI Memory Tutor continuity) ---
    let contextQuery = supabase
      .from('ai_chat_messages')
      .select('role, content')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(CONTEXT_WINDOW);
    if (body?.subject_id) contextQuery = contextQuery.eq('subject_id', body.subject_id);

    const { data: history, error: historyError } = await contextQuery;
    if (historyError) {
      console.error('history load failed', historyError);
      // Non-fatal — proceed without history rather than failing the whole request.
    }

    const conversation = (history ?? [])
      .reverse()
      .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }));
    conversation.push({ role: 'user', content: message });

    // --- Call Claude ---
    const reply = await callClaude({ system: SYSTEM_PROMPT, messages: conversation, maxTokens: 1000 });

    // --- Persist both turns so history is reconstructable from the DB alone ---
    const { error: insertError } = await supabase.from('ai_chat_messages').insert([
      { user_id: user.id, subject_id: body?.subject_id ?? null, role: 'user', content: message },
      { user_id: user.id, subject_id: body?.subject_id ?? null, role: 'assistant', content: reply },
    ]);
    if (insertError) {
      // The reply was already generated (and billed) — log loudly but still
      // return it to the student rather than discarding a paid-for answer.
      console.error('failed to persist chat messages', insertError);
    }

    return new Response(JSON.stringify({ reply }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const status = err instanceof AppError ? err.status : 500;
    const message = err instanceof AppError ? err.message : 'Something went wrong. Please try again.';
    if (status === 500) console.error('ai-tutor-chat unhandled error', err);
    return new Response(JSON.stringify({ error: 'request_failed', message }), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
