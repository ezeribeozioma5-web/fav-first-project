// supabase/functions/generate-quiz/index.ts
//
// Flow: check daily cap -> gather context (note text or raw topic) -> ask
// Claude for strict JSON questions -> write quizzes + quiz_questions rows ->
// return the created quiz.
//
// Deploy: supabase functions deploy generate-quiz
// Secrets required: ANTHROPIC_API_KEY

import { handleCors, corsHeaders } from '../_shared/cors.ts';
import { createUserClient, getAuthedUser, AppError } from '../_shared/supabaseClient.ts';
import { callClaude, parseJsonResponse } from '../_shared/anthropic.ts';

const DAILY_LIMIT_FREE = 3;
const DEFAULT_QUESTION_COUNT = 5;

const SYSTEM_PROMPT = `You are LearnGenie's quiz generator. Given study content or a topic, produce
exam-style practice questions. Respond with ONLY valid JSON, no prose, no markdown code fences, matching
exactly this shape:
{
  "title": "string, short quiz title",
  "questions": [
    {
      "question_text": "string",
      "question_type": "mcq" | "true_false" | "fill_blank" | "short_answer",
      "options": ["string", "string", "string", "string"] | null,
      "correct_answer": "string",
      "explanation": "string, 1-2 sentences on why this is correct",
      "difficulty": "easy" | "medium" | "hard",
      "topic_tag": "string, a short sub-topic label, e.g. 'cell membrane'"
    }
  ]
}
Mix question types and difficulty levels. "options" must be present (4 items) for "mcq" and null for
every other type. Base every question strictly on the provided content or topic — do not invent facts.`;

interface RequestBody {
  topic?: string;
  source_note_id?: string;
  subject_id?: string;
  question_count?: number;
  difficulty?: 'easy' | 'medium' | 'hard' | 'mixed';
}

interface GeneratedQuestion {
  question_text: string;
  question_type: 'mcq' | 'true_false' | 'fill_blank' | 'short_answer';
  options: string[] | null;
  correct_answer: string;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  topic_tag: string;
}

interface GeneratedQuiz {
  title: string;
  questions: GeneratedQuestion[];
}

Deno.serve(async (req) => {
  const cors = handleCors(req);
  if (cors) return cors;

  try {
    if (req.method !== 'POST') throw new AppError('Method not allowed', 405);

    const supabase = createUserClient(req);
    const user = await getAuthedUser(supabase);

    const body = (await req.json().catch(() => null)) as RequestBody | null;
    if (!body?.topic && !body?.source_note_id) {
      throw new AppError('Provide either a topic or a source_note_id.', 400);
    }

    // --- Server-side usage cap check ---
    const { data: allowed, error: usageError } = await supabase.rpc('check_and_log_ai_usage', {
      p_user_id: user.id,
      p_feature: 'quiz_generation',
      p_daily_limit: DAILY_LIMIT_FREE,
    });
    if (usageError) {
      console.error('usage check failed', usageError);
      throw new AppError('Could not verify usage limits. Please try again.', 500);
    }
    if (!allowed) {
      return new Response(
        JSON.stringify({
          error: 'daily_limit_reached',
          message: `You've used all ${DAILY_LIMIT_FREE} free quiz generations today. Upgrade to Premium for unlimited quizzes, or try again in 24 hours.`,
        }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // --- Gather source content ---
    let sourceContent = body.topic ?? '';
    let resolvedTopic = body.topic ?? 'Untitled topic';

    if (body.source_note_id) {
      const { data: note, error: noteError } = await supabase
        .from('notes')
        .select('title, extracted_text, processing_status')
        .eq('id', body.source_note_id)
        .single();

      if (noteError || !note) throw new AppError('Note not found.', 404);
      if (note.processing_status !== 'done' || !note.extracted_text) {
        throw new AppError('This note is still being processed. Try again shortly.', 409);
      }
      sourceContent = note.extracted_text;
      resolvedTopic = body.topic ?? note.title;
    }

    if (!sourceContent.trim()) throw new AppError('No content available to generate a quiz from.', 400);

    const questionCount = Math.min(Math.max(body.question_count ?? DEFAULT_QUESTION_COUNT, 3), 15);
    const difficulty = body.difficulty ?? 'mixed';

    // --- Call Claude for structured quiz JSON ---
    const raw = await callClaude({
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: `Generate ${questionCount} questions at "${difficulty}" difficulty on: ${resolvedTopic}\n\nContent:\n${sourceContent.slice(0, 12000)}`,
        },
      ],
      maxTokens: 3000,
    });

    const generated = parseJsonResponse<GeneratedQuiz>(raw);
    if (!generated.questions?.length) {
      throw new AppError('The AI did not return any questions. Please try again.', 502);
    }

    // --- Persist quiz + questions ---
    const { data: quiz, error: quizError } = await supabase
      .from('quizzes')
      .insert({
        user_id: user.id,
        subject_id: body.subject_id ?? null,
        source_note_id: body.source_note_id ?? null,
        topic: resolvedTopic,
        title: generated.title || resolvedTopic,
        difficulty,
        question_count: generated.questions.length,
        status: 'ready',
      })
      .select()
      .single();

    if (quizError || !quiz) {
      console.error('failed to insert quiz', quizError);
      throw new AppError('Could not save the generated quiz. Please try again.', 500);
    }

    const questionRows = generated.questions.map((q, i) => ({
      quiz_id: quiz.id,
      order_index: i,
      question_text: q.question_text,
      question_type: q.question_type,
      options: q.question_type === 'mcq' ? q.options : null,
      correct_answer: q.correct_answer,
      explanation: q.explanation,
      difficulty: q.difficulty,
      topic_tag: q.topic_tag,
    }));

    const { data: questions, error: questionsError } = await supabase
      .from('quiz_questions')
      .insert(questionRows)
      .select();

    if (questionsError) {
      console.error('failed to insert questions', questionsError);
      // Roll back the orphaned quiz so the student doesn't see an empty quiz.
      await supabase.from('quizzes').delete().eq('id', quiz.id);
      throw new AppError('Could not save the generated questions. Please try again.', 500);
    }

    return new Response(JSON.stringify({ quiz, questions }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const status = err instanceof AppError ? err.status : 500;
    const message = err instanceof AppError ? err.message : 'Something went wrong. Please try again.';
    if (status === 500) console.error('generate-quiz unhandled error', err);
    return new Response(JSON.stringify({ error: 'request_failed', message }), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
