/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx,ts,tsx}", "./src/**/*.{js,jsx,ts,tsx}"],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: {
        primary: { DEFAULT: "#6C5CE7", light: "#A29BFE", dark: "#5546C8" },
        secondary: { DEFAULT: "#00D9A3", light: "#5EEAC4" },
        warning: "#FFB020",
        danger: "#FF5C5C",
        bg: { light: "#FAFAFC", dark: "#121218" },
        surface: { light: "#FFFFFF", dark: "#1C1C24" },
        ink: { DEFAULT: "#1A1A2E", muted: "#6B7280", inverse: "#F2F2F7" },
      },
      borderRadius: { card: "16px", pill: "999px" },
    },
  },
  plugins: [],
};
