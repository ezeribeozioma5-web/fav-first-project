# LearnGenie — MVP

AI-powered study companion. React Native (Expo) + TypeScript + Supabase.

## What's built (Phase 1 MVP)

- ✅ Branded splash screen with animation
- ✅ Onboarding (3-slide swipeable intro)
- ✅ Sign up / Login (Supabase Auth)
- ✅ Home dashboard (streak, quick actions, weekly stats placeholder)
- ✅ AI Tutor chat with daily free-tier limit UI (10 msgs/day free, unlimited premium)
- ✅ Notes upload flow (PDF/DOCX/PPTX/image → Supabase Storage + processing status)
- ✅ Basic quiz generator screen (3/day free, unlimited premium)
- ✅ Profile / settings screen with upgrade prompt

Design system tokens live in `src/theme/tokens.ts` and `tailwind.config.js`.
Full architecture, schema rationale, and phased roadmap are in `blueprint.md`
(the doc from our planning step — keep it alongside this repo).

## Edge Functions (now implemented)

Located in `supabase/functions/`, each self-contained and independently deployable:

- **`ai-tutor-chat`** — checks the daily cap (`check_and_log_ai_usage`), loads
  the last 12 messages for context, calls Claude, persists both the user
  message and the reply to `ai_chat_messages`, returns the reply. Returns a
  `429` with `{ error: 'daily_limit_reached', message }` when the cap is hit.
- **`generate-quiz`** — checks the daily cap, pulls context from either a raw
  topic string or a processed note's `extracted_text`, asks Claude for strict
  JSON questions, writes one `quizzes` row + N `quiz_questions` rows
  (transactional-ish: rolls back the quiz row if question insert fails).
- **`process-note`** — Premium-gated server-side (not just hidden in the UI),
  downloads the file from Storage, extracts text (PDF/images via Claude's
  native document/vision support; plain text decoded directly), updates the
  `notes` row. **Known MVP limitation:** DOCX/PPTX aren't parsed yet — the
  function returns a clear `415` error for those; see the comment in
  `process-note/index.ts` for the recommended next step.

All three: validate input, wrap logic in try/catch, return structured
`{ error, message }` JSON with an appropriate status code, and never expose
raw upstream error details to the client (logged server-side only).

Shared code lives in `supabase/functions/_shared/`: `supabaseClient.ts` (user
JWT-scoped client + `AppError`), `anthropic.ts` (Claude API wrapper + JSON
parsing), `cors.ts`.

## Setup

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Create a Supabase project** at supabase.com, then run `supabase/schema.sql`
   in the SQL editor (Table Editor → SQL Editor → paste → run). This now
   includes `quizzes`, `quiz_questions`, `quiz_attempts`, `quiz_answers` in
   addition to the core tables.

3. **Create the `notes` storage bucket** (private) — SQL for this is
   commented at the bottom of `schema.sql`.

4. **Set Edge Function secrets**
   ```bash
   supabase secrets set ANTHROPIC_API_KEY=your-key-here
   ```
   (`SUPABASE_URL` and `SUPABASE_ANON_KEY` are injected automatically by
   Supabase for Edge Functions — you don't set those yourself.)

5. **Deploy the functions**
   ```bash
   supabase functions deploy ai-tutor-chat
   supabase functions deploy generate-quiz
   supabase functions deploy process-note
   ```

6. **App environment variables** — create `.env` in the project root:
   ```
   EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
   ```

7. **Run it**
   ```bash
   npx expo start
   ```

## Next steps (in priority order)

1. Wire real `ai_usage_log` counts into the Tutor/Quiz screens on mount
   (currently local state that resets per session — the server-side cap is
   already authoritative, this is just a UI polish item).
2. Build the quiz-taking screen (question flow + scoring, writing to
   `quiz_attempts`/`quiz_answers`) — `generate-quiz` already returns
   structured questions, this just needs a UI.
3. Flashcard generation + review screen for `ai_generated_content` of type
   `flashcards` (not yet built — quizzes shipped first per this round's scope).
4. DOCX/PPTX support in `process-note` (see limitation noted above).
5. Study planner (Exam Survival Mode) — schema sketched in the structure
   review doc, not yet in `schema.sql`.
6. Weak-topic detection — `quiz_answers.topic_tag` already captures the raw
   signal; add an aggregation (cron or on-attempt-complete trigger) once quiz
   volume exists to aggregate over.
