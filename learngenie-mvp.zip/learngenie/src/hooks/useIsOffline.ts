import { useEffect, useState } from 'react';
import NetInfo from '@react-native-community/netinfo';

/** True when the device has no usable internet connection. */
export function useIsOffline(): boolean {
  const [isOffline, setIsOffline] = useState(false);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      // isInternetReachable can be null while still determining — treat
      // "connected but unknown reachability" as online to avoid false positives.
      setIsOffline(state.isConnected === false || state.isInternetReachable === false);
    });
    return unsubscribe;
  }, []);

  return isOffline;
}
