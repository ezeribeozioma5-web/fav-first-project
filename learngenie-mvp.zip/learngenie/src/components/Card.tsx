import React from 'react';
import { View, ViewProps } from 'react-native';

export function Card({ className = '', children, ...rest }: ViewProps & { className?: string }) {
  return (
    <View
      className={`bg-surface-light dark:bg-surface-dark rounded-card p-4 shadow-sm shadow-primary/5 ${className}`}
      {...rest}
    >
      {children}
    </View>
  );
}
