import { View, Text } from 'react-native';
import Animated, { FadeInDown, FadeOutUp } from 'react-native-reanimated';
import { useIsOffline } from '@/hooks/useIsOffline';

/** Slim banner pinned under the header when the device has no connection. */
export function OfflineBanner() {
  const isOffline = useIsOffline();
  if (!isOffline) return null;

  return (
    <Animated.View entering={FadeInDown} exiting={FadeOutUp} className="bg-ink px-4 py-2">
      <View className="flex-row items-center justify-center gap-2">
        <Text className="text-xs">📡</Text>
        <Text className="text-white text-xs font-medium">
          You're offline — some features won't work until you reconnect.
        </Text>
      </View>
    </Animated.View>
  );
}
