import React from 'react';
import { Pressable, Text, ActivityIndicator, PressableProps } from 'react-native';
import * as Haptics from 'expo-haptics';

type Variant = 'primary' | 'secondary' | 'ghost';

interface ButtonProps extends PressableProps {
  label: string;
  variant?: Variant;
  loading?: boolean;
  fullWidth?: boolean;
}

const variantStyles: Record<Variant, { container: string; text: string }> = {
  primary: {
    container: 'bg-primary active:bg-primary-dark',
    text: 'text-white',
  },
  secondary: {
    container: 'bg-primary-light/20 active:bg-primary-light/30 border border-primary-light',
    text: 'text-primary',
  },
  ghost: {
    container: 'bg-transparent active:bg-ink/5',
    text: 'text-ink dark:text-ink-inverse',
  },
};

export function Button({
  label,
  variant = 'primary',
  loading = false,
  fullWidth = true,
  disabled,
  onPress,
  ...rest
}: ButtonProps) {
  const styles = variantStyles[variant];

  return (
    <Pressable
      disabled={disabled || loading}
      onPress={(e) => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        onPress?.(e);
      }}
      className={`${styles.container} ${fullWidth ? 'w-full' : ''} rounded-card py-4 px-6 items-center justify-center ${
        disabled ? 'opacity-40' : ''
      }`}
      {...rest}
    >
      {loading ? (
        <ActivityIndicator color={variant === 'primary' ? '#fff' : '#6C5CE7'} />
      ) : (
        <Text className={`${styles.text} text-base font-semibold`}>{label}</Text>
      )}
    </Pressable>
  );
}
