import React from 'react';
import { View, Text } from 'react-native';

export function StreakBadge({ count }: { count: number }) {
  return (
    <View className="flex-row items-center bg-warning/15 rounded-pill px-3 py-1.5">
      <Text className="text-base mr-1">🔥</Text>
      <Text className="text-warning font-bold text-sm">{count} day streak</Text>
    </View>
  );
}
