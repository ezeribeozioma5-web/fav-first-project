// Hand-written for now — once the schema is live, replace this file by running:
//   npx supabase gen types typescript --project-id <id> > src/types/database.ts

export type Plan = 'free' | 'premium';

export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  education_level: 'secondary' | 'university' | null;
  plan: Plan;
  streak_count: number;
  xp_points: number;
  last_active_date: string | null;
  onboarding_completed: boolean;
  created_at: string;
}

export interface Subject {
  id: string;
  user_id: string;
  name: string;
  color: string;
  icon: string;
  created_at: string;
}

export interface Note {
  id: string;
  user_id: string;
  subject_id: string | null;
  title: string;
  file_path: string;
  file_type: 'pdf' | 'docx' | 'pptx' | 'image' | 'text';
  extracted_text: string | null;
  processing_status: 'pending' | 'processing' | 'done' | 'failed';
  created_at: string;
}

export interface AIGeneratedContent {
  id: string;
  user_id: string;
  source_note_id: string | null;
  type: 'summary' | 'flashcards' | 'mcq' | 'true_false' | 'fill_blank' | 'short_answer';
  subject_id: string | null;
  content: Record<string, unknown>;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  user_id: string;
  subject_id: string | null;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}

// Minimal Supabase Database type so the typed client compiles.
// Expand per-table as features are built out.
export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile; Insert: Partial<Profile>; Update: Partial<Profile> };
      subjects: { Row: Subject; Insert: Partial<Subject>; Update: Partial<Subject> };
      notes: { Row: Note; Insert: Partial<Note>; Update: Partial<Note> };
      ai_generated_content: {
        Row: AIGeneratedContent;
        Insert: Partial<AIGeneratedContent>;
        Update: Partial<AIGeneratedContent>;
      };
      ai_chat_messages: {
        Row: ChatMessage;
        Insert: Partial<ChatMessage>;
        Update: Partial<ChatMessage>;
      };
    };
  };
}
