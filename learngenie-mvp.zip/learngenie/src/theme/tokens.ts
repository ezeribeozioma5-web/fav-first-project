// Design tokens — single source of truth, mirrored in tailwind.config.js.
// Import these when you need raw values (e.g. inside StyleSheet.create,
// SVG fills, or chart libraries that don't accept Tailwind classes).

export const colors = {
  primary: '#6C5CE7',
  primaryLight: '#A29BFE',
  primaryDark: '#5546C8',
  secondary: '#00D9A3',
  secondaryLight: '#5EEAC4',
  warning: '#FFB020',
  danger: '#FF5C5C',
  bgLight: '#FAFAFC',
  bgDark: '#121218',
  surfaceLight: '#FFFFFF',
  surfaceDark: '#1C1C24',
  ink: '#1A1A2E',
  inkMuted: '#6B7280',
  inkInverse: '#F2F2F7',
} as const;

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32, xxxl: 48 } as const;

export const radius = { sm: 8, md: 12, lg: 16, pill: 999 } as const;

export const typography = {
  display: { fontSize: 32, lineHeight: 40, fontWeight: '700' as const },
  h1: { fontSize: 24, lineHeight: 32, fontWeight: '700' as const },
  h2: { fontSize: 20, lineHeight: 28, fontWeight: '600' as const },
  body: { fontSize: 16, lineHeight: 24, fontWeight: '400' as const },
  bodySm: { fontSize: 14, lineHeight: 20, fontWeight: '400' as const },
  caption: { fontSize: 12, lineHeight: 16, fontWeight: '500' as const },
};

// Free-tier daily AI limits — mirrored server-side in Supabase (source of truth
// is the DB function `check_ai_limit`; this copy is only for optimistic UI).
export const FREE_TIER_LIMITS = {
  tutorMessagesPerDay: 10,
  quizGenerationsPerDay: 3,
};
