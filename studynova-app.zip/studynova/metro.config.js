// Required by NativeWind v4 to process the `import '../global.css'` in
// app/_layout.tsx and turn Tailwind classes into RN styles. This file was
// missing entirely — without it, Metro has no idea what to do with a .css
// import and the bundle fails immediately on the very first screen (root
// layout is the app's entry point), before anything renders.
const { getDefaultConfig } = require('expo/metro-config');
const { withNativeWind } = require('nativewind/metro');

const config = getDefaultConfig(__dirname);

module.exports = withNativeWind(config, { input: './global.css' });
