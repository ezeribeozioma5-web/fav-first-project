-- Education Stage/Class taxonomy + official content catalog.
-- Purely additive: no existing table (subjects, notes, quizzes, profiles'
-- other columns) is restructured. `subjects` deliberately stays untouched —
-- personal subjects don't carry a stage dimension; that context lives on
-- the student's profile instead.
--
-- Two axes, kept separate on purpose:
--   class_levels — grade/level (JSS1...SS3, 100L...500L+)
--   exam_tracks  — which exam a student is prepping for (BECE/WAEC/NECO/JAMB),
--                  since e.g. an SS3 student might target WAEC, NECO, or both,
--                  and JAMB candidates aren't all in the same class level.
-- Forcing these into one column would mean encoding two independent
-- concerns as string soup ("SS3-WAEC-NECO"); keeping them separate keeps
-- both queryable and each one independently extensible.

-- =========================================================
-- CLASS LEVELS (global lookup, admin-managed, not user-owned)
-- =========================================================
create table class_levels (
  id uuid primary key default uuid_generate_v4(),
  stage text not null check (stage in ('junior_secondary', 'senior_secondary', 'tertiary')),
  label text not null,          -- 'JSS1', 'SS3', '300 Level', etc.
  sort_order int not null,
  created_at timestamptz not null default now()
);

alter table class_levels enable row level security;
create policy "Anyone can read class levels" on class_levels for select using (true);
-- No insert/update/delete policy for the authenticated role — this is
-- reference data seeded below and maintained via migrations / service role,
-- not something any current UI creates.

insert into class_levels (stage, label, sort_order) values
  ('junior_secondary', 'JSS1', 1),
  ('junior_secondary', 'JSS2', 2),
  ('junior_secondary', 'JSS3', 3),
  ('senior_secondary', 'SS1', 4),
  ('senior_secondary', 'SS2', 5),
  ('senior_secondary', 'SS3', 6),
  ('tertiary', '100 Level', 7),
  ('tertiary', '200 Level', 8),
  ('tertiary', '300 Level', 9),
  ('tertiary', '400 Level', 10),
  ('tertiary', '500 Level+', 11);

-- =========================================================
-- EXAM TRACKS (global lookup, same ownership model as class_levels)
-- =========================================================
create table exam_tracks (
  id uuid primary key default uuid_generate_v4(),
  code text not null unique,     -- 'BECE', 'WAEC', 'NECO', 'JAMB'
  label text not null,
  applies_to_stage text check (applies_to_stage in ('junior_secondary', 'senior_secondary', 'tertiary')),
  created_at timestamptz not null default now()
);

alter table exam_tracks enable row level security;
create policy "Anyone can read exam tracks" on exam_tracks for select using (true);

insert into exam_tracks (code, label, applies_to_stage) values
  ('BECE', 'BECE', 'junior_secondary'),
  ('WAEC', 'WAEC', 'senior_secondary'),
  ('NECO', 'NECO', 'senior_secondary'),
  ('JAMB', 'JAMB / UTME', 'senior_secondary');

-- =========================================================
-- PROFILES — replace the old, unused, wrong-shaped enum
-- =========================================================
-- `education_level text check (in ('secondary','university'))` has never
-- been read or written by any app code (verified before writing this
-- migration) — safe to replace outright rather than carry it forward
-- alongside the real thing.
alter table profiles drop column if exists education_level;
alter table profiles add column class_level_id uuid references class_levels(id) on delete set null;
alter table profiles add column exam_track_id uuid references exam_tracks(id) on delete set null;

-- =========================================================
-- STUDY MATERIALS — official, built-in content catalog
-- Deliberately ownerless: no user_id. This is admin-managed content shown
-- to everyone (or gated by `tier_required`, reusing the existing free/
-- premium model), never created by a student. Kept fully separate from
-- `notes`/`ai_generated_content` (user-generated) rather than merged with
-- a nullable user_id + conditional RLS, which would complicate every
-- existing policy on those tables for a case that doesn't apply to them.
-- =========================================================
create table study_materials (
  id uuid primary key default uuid_generate_v4(),
  class_level_id uuid references class_levels(id) on delete set null,
  exam_track_id uuid references exam_tracks(id) on delete set null,
  subject_tag text not null,        -- free-text for v1 ('Mathematics', 'English Language')
  type text not null check (type in ('note', 'summary', 'quiz', 'flashcards', 'study_guide')),
  title text not null,
  content jsonb not null,
  tier_required text not null default 'free' check (tier_required in ('free', 'premium')),
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

alter table study_materials enable row level security;
create policy "Anyone can read published official content" on study_materials for select
  using (is_published = true);
-- No client insert/update/delete policy — populated by admin tooling
-- (service role) once that exists. Nothing in the current app writes here.

create index idx_study_materials_class_level on study_materials(class_level_id);
create index idx_study_materials_exam_track on study_materials(exam_track_id);
create index idx_study_materials_subject_tag on study_materials(subject_tag);
