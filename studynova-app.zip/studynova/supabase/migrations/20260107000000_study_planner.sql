-- Study Planner + Assignment & Exam Tracker.
-- Foundational tables per the approved implementation plan — Daily Brief,
-- Semester Dashboard, Smart Exam Mode, and Smart Notifications all depend
-- on this existing first.
--
-- Same discipline as every table added so far: user_id + RLS, subject_id
-- FK (reusing the existing personal Subjects system, not duplicating it),
-- indexes on every FK and every date column added now rather than
-- retrofitted later.
--
-- `remind_at` columns are included now but NOT wired to any notification
-- delivery in this milestone — that's the separately-scoped Smart
-- Notifications phase. Capturing the column now avoids the exact class of
-- retrofit this project has hit twice already; not building the delivery
-- UI yet avoids shipping a "reminder" that doesn't actually remind anyone.

create table assignments (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  title text not null,
  description text,
  due_date timestamptz not null,
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high')),
  status text not null default 'pending' check (status in ('pending', 'completed')),
  remind_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table assignments enable row level security;
create policy "Users manage own assignments" on assignments for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_assignments_user_id on assignments(user_id);
create index idx_assignments_subject_id on assignments(subject_id);
create index idx_assignments_due_date on assignments(due_date);

create trigger on_assignments_updated
  before update on assignments
  for each row execute procedure public.touch_updated_at();

create table exams (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  title text not null,
  exam_date timestamptz not null,
  notes text,
  remind_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table exams enable row level security;
create policy "Users manage own exams" on exams for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_exams_user_id on exams(user_id);
create index idx_exams_subject_id on exams(subject_id);
create index idx_exams_exam_date on exams(exam_date);

create trigger on_exams_updated
  before update on exams
  for each row execute procedure public.touch_updated_at();

create table study_sessions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  linked_assignment_id uuid references assignments(id) on delete set null,
  linked_exam_id uuid references exams(id) on delete set null,
  title text not null,
  scheduled_date date not null,
  duration_minutes int not null default 60,
  status text not null default 'planned' check (status in ('planned', 'completed', 'missed')),
  created_at timestamptz not null default now()
);

alter table study_sessions enable row level security;
create policy "Users manage own study sessions" on study_sessions for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_study_sessions_user_id on study_sessions(user_id);
create index idx_study_sessions_subject_id on study_sessions(subject_id);
create index idx_study_sessions_scheduled_date on study_sessions(scheduled_date);
create index idx_study_sessions_linked_assignment on study_sessions(linked_assignment_id);
create index idx_study_sessions_linked_exam on study_sessions(linked_exam_id);
