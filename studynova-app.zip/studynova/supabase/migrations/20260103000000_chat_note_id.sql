-- Fixes a bug found during MVP stabilization review: "Ask AI About This
-- Note" threaded conversations by `subject_id`, but nothing in the app ever
-- assigns a subject to a note (there's no subject-picker UI), so
-- notes.subject_id is null for virtually every real note. That made the
-- `ai-tutor-chat` context query's `if (subjectIdForThread) ...` condition
-- false, which meant:
--   1. note-context chats pulled in the user's ENTIRE recent chat history
--      as context, not just messages about that note, and
--   2. general chat and every note-context chat wrote to the same
--      undifferentiated (subject_id = null) bucket, so unrelated
--      conversations bled into each other.
-- Fix: give ai_chat_messages its own note_id column and thread on that
-- directly when present, instead of overloading subject_id (which was
-- never a reliable grouping key for this).

alter table ai_chat_messages
  add column note_id uuid references notes(id) on delete set null;

create index idx_ai_chat_messages_note_id on ai_chat_messages(note_id);
