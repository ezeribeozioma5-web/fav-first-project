-- Activates the existing `subjects` table and subject_id foreign keys.
-- Deliberately non-destructive: no existing columns, FKs, or RLS policies
-- are touched. `notes`/`ai_generated_content`/`ai_chat_messages`/`quizzes`
-- already reference subjects(id) with `on delete set null`, which is exactly
-- the right behavior (deleting a subject un-links content, never deletes
-- it) — nothing to change there. This migration only adds what's needed to
-- query and enter data efficiently.

-- Prevents duplicate subject names per user from the lightweight inline
-- "+ New Subject" flow (no separate validation screen in v1).
alter table subjects
  add constraint subjects_user_id_name_key unique (user_id, name);

-- subject_id has never been queried against until this feature; these
-- columns will now be filtered on constantly (Notes/Practice chip filters,
-- Tutor's subject-scoped threads).
create index idx_notes_subject_id on notes(subject_id);
create index idx_ai_chat_messages_subject_id on ai_chat_messages(subject_id);
create index idx_ai_generated_content_subject_id on ai_generated_content(subject_id);
-- Note: idx_quizzes_subject_id already exists from the original quizzes migration.
