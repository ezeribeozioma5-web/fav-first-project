-- Flashcards (Priority 3). Mirrors the quizzes/quiz_questions pattern
-- already proven out: a parent "deck" row (like quizzes) + child card rows
-- (like quiz_questions). Includes subject_id from day one — no retrofit
-- needed now that subjects exist, which was the whole point of building
-- subjects first.

create table flashcard_decks (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  source_note_id uuid references notes(id) on delete set null,
  title text not null,
  card_count int not null default 0,
  created_at timestamptz not null default now()
);

alter table flashcard_decks enable row level security;
create policy "Users manage own flashcard decks" on flashcard_decks for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_flashcard_decks_user_id on flashcard_decks(user_id);
create index idx_flashcard_decks_subject_id on flashcard_decks(subject_id);
create index idx_flashcard_decks_source_note_id on flashcard_decks(source_note_id);

create table flashcards (
  id uuid primary key default uuid_generate_v4(),
  deck_id uuid not null references flashcard_decks(id) on delete cascade,
  order_index int not null default 0,
  front text not null,
  back text not null,
  -- Progress tracking per product decision: three states, no spaced-
  -- repetition scheduling (ease factors / intervals) — deliberately simple
  -- for MVP, per "avoid unnecessary complexity."
  status text not null default 'learning' check (status in ('learning', 'known', 'review_later')),
  last_reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

alter table flashcards enable row level security;
-- Access via the parent deck's ownership — same pattern as quiz_questions.
create policy "Users access cards of own decks" on flashcards for all
  using (exists (select 1 from flashcard_decks d where d.id = deck_id and d.user_id = auth.uid()))
  with check (exists (select 1 from flashcard_decks d where d.id = deck_id and d.user_id = auth.uid()));

create index idx_flashcards_deck_id on flashcards(deck_id);
