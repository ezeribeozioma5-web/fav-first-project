-- StudyNova MVP schema
-- Scoped to: Auth/profiles, subjects, notes, AI generated content,
-- AI tutor chat, and usage-limit tracking.
-- Deliberately leaves room (see "FUTURE" comments) for: quiz history/attempts,
-- study planner, progress snapshots, XP/streak gamification, and communities —
-- those tables are sketched in blueprint.md and will be added in later phases
-- without breaking this schema.

create extension if not exists "uuid-ossp";

-- =========================================================
-- CLASS LEVELS & EXAM TRACKS (global lookups, admin-managed, not user-owned)
-- Two separate axes on purpose: an SS3 student might target WAEC, NECO, or
-- both, and JAMB candidates aren't all in one class level — folding both
-- into a single column would mean encoding two independent concerns as
-- string soup instead of two clean, independently queryable dimensions.
-- =========================================================
create table class_levels (
  id uuid primary key default uuid_generate_v4(),
  stage text not null check (stage in ('junior_secondary', 'senior_secondary', 'tertiary')),
  label text not null,          -- 'JSS1', 'SS3', '300 Level', etc.
  sort_order int not null,
  created_at timestamptz not null default now()
);

alter table class_levels enable row level security;
create policy "Anyone can read class levels" on class_levels for select using (true);
-- No insert/update/delete policy for the authenticated role — reference
-- data, seeded below, maintained via migrations / service role only.

insert into class_levels (stage, label, sort_order) values
  ('junior_secondary', 'JSS1', 1),
  ('junior_secondary', 'JSS2', 2),
  ('junior_secondary', 'JSS3', 3),
  ('senior_secondary', 'SS1', 4),
  ('senior_secondary', 'SS2', 5),
  ('senior_secondary', 'SS3', 6),
  ('tertiary', '100 Level', 7),
  ('tertiary', '200 Level', 8),
  ('tertiary', '300 Level', 9),
  ('tertiary', '400 Level', 10),
  ('tertiary', '500 Level+', 11);

create table exam_tracks (
  id uuid primary key default uuid_generate_v4(),
  code text not null unique,     -- 'BECE', 'WAEC', 'NECO', 'JAMB'
  label text not null,
  applies_to_stage text check (applies_to_stage in ('junior_secondary', 'senior_secondary', 'tertiary')),
  created_at timestamptz not null default now()
);

alter table exam_tracks enable row level security;
create policy "Anyone can read exam tracks" on exam_tracks for select using (true);

insert into exam_tracks (code, label, applies_to_stage) values
  ('BECE', 'BECE', 'junior_secondary'),
  ('WAEC', 'WAEC', 'senior_secondary'),
  ('NECO', 'NECO', 'senior_secondary'),
  ('JAMB', 'JAMB / UTME', 'senior_secondary');

-- =========================================================
-- PROFILES
-- =========================================================
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  class_level_id uuid references class_levels(id) on delete set null,
  exam_track_id uuid references exam_tracks(id) on delete set null,
  plan text not null default 'free' check (plan in ('free', 'premium')),
  plan_renews_at timestamptz,
  streak_count int not null default 0,
  xp_points int not null default 0,             -- FUTURE: gamification
  last_active_date date,
  onboarding_completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table profiles enable row level security;

create policy "Users can view own profile"
  on profiles for select using (auth.uid() = id);
create policy "Users can update own profile"
  on profiles for update using (auth.uid() = id);

-- Auto-create a profile row whenever a new auth user signs up.
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Keeps profiles.updated_at accurate on every update, since the column
-- existed but nothing was maintaining it.
create function public.touch_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger on_profiles_updated
  before update on profiles
  for each row execute procedure public.touch_updated_at();

-- =========================================================
-- SUBJECTS
-- =========================================================
create table subjects (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  color text default '#6C5CE7',
  icon text default '📘',
  created_at timestamptz not null default now(),
  unique (user_id, name)  -- prevents dupes from the lightweight inline "+ New Subject" flow
);

alter table subjects enable row level security;
create policy "Users manage own subjects" on subjects for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- =========================================================
-- NOTES (uploaded by students)
-- =========================================================
create table notes (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  title text not null,
  file_path text not null,          -- path within the `notes` Storage bucket
  file_type text not null check (file_type in ('pdf', 'docx', 'pptx', 'image', 'text')),
  extracted_text text,               -- populated by the process-note Edge Function
  processing_status text not null default 'pending'
    check (processing_status in ('pending', 'processing', 'done', 'failed')),
  created_at timestamptz not null default now()
);

alter table notes enable row level security;
create policy "Users manage own notes" on notes for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_notes_subject_id on notes(subject_id);

-- =========================================================
-- AI GENERATED CONTENT (summaries, flashcards, quizzes from notes/topics)
-- =========================================================
create table ai_generated_content (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  source_note_id uuid references notes(id) on delete set null,
  subject_id uuid references subjects(id) on delete set null,
  type text not null check (
    type in ('summary', 'flashcards', 'mcq', 'true_false', 'fill_blank', 'short_answer', 'revision_guide')
  ),
  content jsonb not null,
  created_at timestamptz not null default now()
);

alter table ai_generated_content enable row level security;
create policy "Users manage own generated content" on ai_generated_content for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_ai_generated_content_subject_id on ai_generated_content(subject_id);

-- =========================================================
-- AI TUTOR CHAT
-- =========================================================
create table ai_chat_messages (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  note_id uuid references notes(id) on delete set null,  -- threads "Ask AI About This Note" chats
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  topic_tags text[],                 -- FUTURE: feeds weak_topics / AI memory
  created_at timestamptz not null default now()
);

alter table ai_chat_messages enable row level security;
create policy "Users manage own chat messages" on ai_chat_messages for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_ai_chat_messages_note_id on ai_chat_messages(note_id);
create index idx_ai_chat_messages_subject_id on ai_chat_messages(subject_id);

-- =========================================================
-- AI USAGE LOG — powers the free-tier daily caps
-- =========================================================
create table ai_usage_log (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  feature text not null check (feature in ('tutor_chat', 'quiz_generation', 'note_conversion')),
  created_at timestamptz not null default now()
);

alter table ai_usage_log enable row level security;
create policy "Users view own usage" on ai_usage_log for select
  using (auth.uid() = user_id);
-- Inserts happen only via check_and_log_ai_usage() (SECURITY DEFINER), never
-- via a direct client insert policy.

-- Speeds up the check_and_log_ai_usage() daily-window lookup, which filters
-- on exactly these three columns on every AI call.
create index idx_ai_usage_log_user_feature_time on ai_usage_log(user_id, feature, created_at);

-- Helper used by Edge Functions to check + enforce the daily cap atomically.
create function public.check_and_log_ai_usage(
  p_user_id uuid,
  p_feature text,
  p_daily_limit int
) returns boolean as $$
declare
  is_premium boolean;
  used_today int;
begin
  select (plan = 'premium') into is_premium from profiles where id = p_user_id;
  if is_premium then
    insert into ai_usage_log (user_id, feature) values (p_user_id, p_feature);
    return true;
  end if;

  select count(*) into used_today
  from ai_usage_log
  where user_id = p_user_id
    and feature = p_feature
    and created_at >= now() - interval '24 hours';

  if used_today >= p_daily_limit then
    return false;
  end if;

  insert into ai_usage_log (user_id, feature) values (p_user_id, p_feature);
  return true;
end;
$$ language plpgsql security definer;

-- =========================================================
-- QUIZZES  (users → quizzes → quiz_questions; attempts + answers below)
-- =========================================================
create table quizzes (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  source_note_id uuid references notes(id) on delete set null,   -- null if topic-based, not note-based
  topic text not null,                                            -- free-text topic, e.g. "Photosynthesis"
  title text not null,
  difficulty text not null default 'mixed'
    check (difficulty in ('easy', 'medium', 'hard', 'mixed')),
  question_count int not null default 0,
  status text not null default 'ready'
    check (status in ('generating', 'ready', 'failed')),
  created_at timestamptz not null default now()
);

alter table quizzes enable row level security;
create policy "Users manage own quizzes" on quizzes for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_quizzes_user_id on quizzes(user_id);
create index idx_quizzes_subject_id on quizzes(subject_id);

-- =========================================================
-- QUIZ QUESTIONS  (one row per question, reusable across attempts)
-- =========================================================
create table quiz_questions (
  id uuid primary key default uuid_generate_v4(),
  quiz_id uuid not null references quizzes(id) on delete cascade,
  order_index int not null default 0,
  question_text text not null,
  question_type text not null
    check (question_type in ('mcq', 'true_false', 'fill_blank', 'short_answer')),
  options jsonb,                    -- e.g. ["A", "B", "C", "D"] for mcq; null otherwise
  correct_answer text not null,
  explanation text,
  difficulty text not null default 'medium' check (difficulty in ('easy', 'medium', 'hard')),
  topic_tag text,                   -- sub-topic, powers weak-topic detection later
  created_at timestamptz not null default now()
);

alter table quiz_questions enable row level security;
-- Access controlled via the parent quiz's ownership (no direct user_id column
-- here — questions belong to a quiz, quizzes belong to a user).
create policy "Users access questions of own quizzes" on quiz_questions for all
  using (exists (select 1 from quizzes q where q.id = quiz_id and q.user_id = auth.uid()))
  with check (exists (select 1 from quizzes q where q.id = quiz_id and q.user_id = auth.uid()));

create index idx_quiz_questions_quiz_id on quiz_questions(quiz_id);
create index idx_quiz_questions_topic_tag on quiz_questions(topic_tag);

-- =========================================================
-- QUIZ ATTEMPTS  (one row per time a student takes a quiz — supports retakes
-- and quiz history / progress analytics)
-- =========================================================
create table quiz_attempts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  quiz_id uuid not null references quizzes(id) on delete cascade,
  status text not null default 'in_progress'
    check (status in ('in_progress', 'completed', 'abandoned')),
  score numeric,                       -- percentage, null until completed
  correct_count int not null default 0,
  total_questions int not null default 0,
  time_taken_seconds int,
  started_at timestamptz not null default now(),
  completed_at timestamptz
);

alter table quiz_attempts enable row level security;
create policy "Users manage own attempts" on quiz_attempts for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_quiz_attempts_user_id on quiz_attempts(user_id);
create index idx_quiz_attempts_quiz_id on quiz_attempts(quiz_id);

-- =========================================================
-- QUIZ ANSWERS  (question-by-question record within an attempt — the
-- foundation for weak-topic detection and personalized revision)
-- =========================================================
create table quiz_answers (
  id uuid primary key default uuid_generate_v4(),
  attempt_id uuid not null references quiz_attempts(id) on delete cascade,
  question_id uuid not null references quiz_questions(id) on delete cascade,
  user_answer text,
  is_correct boolean not null default false,
  topic_tag text,                      -- denormalized copy from quiz_questions for fast aggregation
  answered_at timestamptz not null default now()
);

alter table quiz_answers enable row level security;
-- Access controlled via the parent attempt's ownership.
create policy "Users access answers of own attempts" on quiz_answers for all
  using (exists (select 1 from quiz_attempts a where a.id = attempt_id and a.user_id = auth.uid()))
  with check (exists (select 1 from quiz_attempts a where a.id = attempt_id and a.user_id = auth.uid()));

create index idx_quiz_answers_attempt_id on quiz_answers(attempt_id);
create index idx_quiz_answers_topic_tag on quiz_answers(topic_tag);

-- =========================================================
-- STORAGE BUCKET for uploaded notes (run once via Supabase dashboard/CLI)
-- =========================================================
-- insert into storage.buckets (id, name, public) values ('notes', 'notes', false);
-- create policy "Users manage own note files" on storage.objects for all
--   using (bucket_id = 'notes' and auth.uid()::text = (storage.foldername(name))[1]);

-- =========================================================
-- FLASHCARDS  (mirrors the quizzes/quiz_questions pattern)
-- =========================================================
create table flashcard_decks (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  source_note_id uuid references notes(id) on delete set null,
  title text not null,
  card_count int not null default 0,
  created_at timestamptz not null default now()
);

alter table flashcard_decks enable row level security;
create policy "Users manage own flashcard decks" on flashcard_decks for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_flashcard_decks_user_id on flashcard_decks(user_id);
create index idx_flashcard_decks_subject_id on flashcard_decks(subject_id);
create index idx_flashcard_decks_source_note_id on flashcard_decks(source_note_id);

create table flashcards (
  id uuid primary key default uuid_generate_v4(),
  deck_id uuid not null references flashcard_decks(id) on delete cascade,
  order_index int not null default 0,
  front text not null,
  back text not null,
  status text not null default 'learning' check (status in ('learning', 'known', 'review_later')),
  last_reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

alter table flashcards enable row level security;
create policy "Users access cards of own decks" on flashcards for all
  using (exists (select 1 from flashcard_decks d where d.id = deck_id and d.user_id = auth.uid()))
  with check (exists (select 1 from flashcard_decks d where d.id = deck_id and d.user_id = auth.uid()));

create index idx_flashcards_deck_id on flashcards(deck_id);

-- =========================================================
-- STUDY PLANNER + ASSIGNMENT & EXAM TRACKER
-- =========================================================
create table assignments (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  title text not null,
  description text,
  due_date timestamptz not null,
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high')),
  status text not null default 'pending' check (status in ('pending', 'completed')),
  remind_at timestamptz,   -- captured now, not yet wired to delivery — see Smart Notifications phase
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table assignments enable row level security;
create policy "Users manage own assignments" on assignments for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_assignments_user_id on assignments(user_id);
create index idx_assignments_subject_id on assignments(subject_id);
create index idx_assignments_due_date on assignments(due_date);

create trigger on_assignments_updated
  before update on assignments
  for each row execute procedure public.touch_updated_at();

create table exams (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  title text not null,
  exam_date timestamptz not null,
  notes text,
  remind_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table exams enable row level security;
create policy "Users manage own exams" on exams for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_exams_user_id on exams(user_id);
create index idx_exams_subject_id on exams(subject_id);
create index idx_exams_exam_date on exams(exam_date);

create trigger on_exams_updated
  before update on exams
  for each row execute procedure public.touch_updated_at();

create table study_sessions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  subject_id uuid references subjects(id) on delete set null,
  linked_assignment_id uuid references assignments(id) on delete set null,
  linked_exam_id uuid references exams(id) on delete set null,
  title text not null,
  scheduled_date date not null,
  duration_minutes int not null default 60,
  status text not null default 'planned' check (status in ('planned', 'completed', 'missed')),
  created_at timestamptz not null default now()
);

alter table study_sessions enable row level security;
create policy "Users manage own study sessions" on study_sessions for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index idx_study_sessions_user_id on study_sessions(user_id);
create index idx_study_sessions_subject_id on study_sessions(subject_id);
create index idx_study_sessions_scheduled_date on study_sessions(scheduled_date);
create index idx_study_sessions_linked_assignment on study_sessions(linked_assignment_id);
create index idx_study_sessions_linked_exam on study_sessions(linked_exam_id);

-- =========================================================
-- STUDY MATERIALS — official, built-in content catalog
-- Deliberately ownerless: no user_id. Admin-managed content shown to
-- everyone (or gated by tier_required, reusing the existing free/premium
-- model), never created by a student — kept fully separate from
-- notes/ai_generated_content (user-generated) rather than merged with a
-- nullable user_id + conditional RLS.
-- =========================================================
create table study_materials (
  id uuid primary key default uuid_generate_v4(),
  class_level_id uuid references class_levels(id) on delete set null,
  exam_track_id uuid references exam_tracks(id) on delete set null,
  subject_tag text not null,        -- free-text for v1 ('Mathematics', 'English Language')
  type text not null check (type in ('note', 'summary', 'quiz', 'flashcards', 'study_guide')),
  title text not null,
  content jsonb not null,
  tier_required text not null default 'free' check (tier_required in ('free', 'premium')),
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

alter table study_materials enable row level security;
create policy "Anyone can read published official content" on study_materials for select
  using (is_published = true);
-- No client insert/update/delete policy — populated by admin tooling
-- (service role) once that exists. Nothing in the current app writes here.

create index idx_study_materials_class_level on study_materials(class_level_id);
create index idx_study_materials_exam_track on study_materials(exam_track_id);
create index idx_study_materials_subject_tag on study_materials(subject_tag);

-- =========================================================
-- FUTURE TABLES (Phase 2+, not created yet — kept here for schema continuity)
-- =========================================================
-- study_plans, study_sessions, assignments, timetable_entries -> planner
-- weak_topics, progress_snapshots                         -> analytics rollups
--   (quiz_answers.topic_tag already gives us the raw data to compute these
--    from later — weak_topics would just be a materialized aggregate)
-- xp_events, badges, user_badges                           -> gamification
-- study_groups, group_members, group_messages               -> communities
--   (communities are explicitly out of scope per the product brief's
--    "no social/community features" requirement — only add if that changes)
