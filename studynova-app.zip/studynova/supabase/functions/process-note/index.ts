// supabase/functions/process-note/index.ts
//
// Flow: verify ownership + plan -> download file from Storage -> extract
// text (PDF/image via Claude's native document/vision support; plain text
// decoded directly; DOCX/PPTX flagged as a known MVP limitation) -> update
// the notes row -> return the extracted text.
//
// Deliberately extraction-only. Summary generation lives in the separate
// `generate-summary` function, called by the client right after this one
// succeeds — extraction and summarization stay independently retryable,
// and there's exactly one place that owns the summary JSON shape.
// (A previous version of this file had its own embedded summary generator
// using a different JSON shape than generate-summary's — found and removed
// during the stabilization review. Two summary generators writing
// differently-shaped rows to the same `ai_generated_content` table would
// have crashed the Notes screen's `.map()` calls whenever generate-summary's
// "reuse existing summary" check happened to find one written by the old
// code path instead of its own.)
//
// Deploy: supabase functions deploy process-note
// Secrets required: ANTHROPIC_API_KEY

import { handleCors, corsHeaders } from '../_shared/cors.ts';
import { createUserClient, getAuthedUser, AppError } from '../_shared/supabaseClient.ts';
import { callClaude } from '../_shared/anthropic.ts';

const EXTRACTION_SYSTEM_PROMPT = `You transcribe and lightly clean up study notes. Extract ALL readable
text from the provided document/image, preserving headings, bullet points, and structure as plain text.
Do not summarize, do not omit content, do not add commentary — output only the transcribed text.`;

interface RequestBody {
  note_id: string;
}

Deno.serve(async (req) => {
  const cors = handleCors(req);
  if (cors) return cors;

  try {
    if (req.method !== 'POST') throw new AppError('Method not allowed', 405);

    const supabase = createUserClient(req);
    const user = await getAuthedUser(supabase);

    const body = (await req.json().catch(() => null)) as RequestBody | null;
    if (!body?.note_id) throw new AppError('note_id is required.', 400);

    // Note uploading/processing is a Premium feature per the product plan —
    // enforced here server-side, not just hidden in the UI.
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('plan')
      .eq('id', user.id)
      .single();
    if (profileError || !profile) throw new AppError('Could not verify your plan.', 500);
    if (profile.plan !== 'premium') {
      throw new AppError('Uploading and processing notes is a Premium feature. Upgrade to unlock it.', 403);
    }

    const { data: note, error: noteError } = await supabase
      .from('notes')
      .select('*')
      .eq('id', body.note_id)
      .eq('user_id', user.id)
      .single();
    if (noteError || !note) throw new AppError('Note not found.', 404);

    // Idempotent: safe to call again (e.g. client retry) without re-extracting.
    if (note.processing_status === 'done') {
      return new Response(JSON.stringify({ note }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    await supabase.from('notes').update({ processing_status: 'processing' }).eq('id', note.id);

    let extractedText: string;
    try {
      extractedText = await extractText(supabase, note);
    } catch (extractionErr) {
      await supabase.from('notes').update({ processing_status: 'failed' }).eq('id', note.id);
      throw extractionErr;
    }

    if (!extractedText.trim()) {
      await supabase.from('notes').update({ processing_status: 'failed' }).eq('id', note.id);
      throw new AppError('No readable text was found in this file.', 422);
    }

    const { data: updatedNote, error: updateError } = await supabase
      .from('notes')
      .update({ extracted_text: extractedText, processing_status: 'done' })
      .eq('id', note.id)
      .select()
      .single();

    if (updateError) {
      console.error('failed to save extracted text', updateError);
      throw new AppError('Text was extracted but could not be saved. Please try again.', 500);
    }

    return new Response(JSON.stringify({ note: updatedNote }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const status = err instanceof AppError ? err.status : 500;
    const message = err instanceof AppError ? err.message : 'Something went wrong. Please try again.';
    if (status === 500) console.error('process-note unhandled error', err);
    return new Response(JSON.stringify({ error: 'request_failed', message }), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function extractText(supabase: any, note: { file_path: string; file_type: string }): Promise<string> {
  const { data: fileBlob, error: downloadError } = await supabase.storage.from('notes').download(note.file_path);
  if (downloadError || !fileBlob) {
    throw new AppError('Could not download the uploaded file.', 500);
  }

  if (note.file_type === 'text') {
    return await fileBlob.text();
  }

  if (note.file_type === 'pdf' || note.file_type === 'image') {
    const arrayBuffer = await fileBlob.arrayBuffer();
    const base64 = base64Encode(new Uint8Array(arrayBuffer));
    const mediaType = note.file_type === 'pdf' ? 'application/pdf' : (fileBlob.type || 'image/jpeg');
    const blockType = note.file_type === 'pdf' ? 'document' : 'image';

    return await callClaude({
      system: EXTRACTION_SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: [
            { type: blockType, source: { type: 'base64', media_type: mediaType, data: base64 } },
            { type: 'text', text: 'Transcribe all text from this file.' },
          ],
        },
      ],
      maxTokens: 4000,
    });
  }

  // DOCX/PPTX: known MVP limitation. Deno's Edge runtime doesn't have a
  // lightweight native parser for these, and Claude's document support
  // currently covers PDF/images, not Office formats directly. Recommended
  // next step: convert to PDF at upload time (e.g. via a small conversion
  // service) before calling this function, or add a dedicated parsing
  // library here once volume justifies it.
  throw new AppError(
    `${note.file_type.toUpperCase()} files aren't supported yet — please upload as PDF for now.`,
    415
  );
}

function base64Encode(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}
