// supabase/functions/ai-tutor-chat/index.ts
//
// Flow: check daily cap -> load recent conversation context -> call Claude ->
// persist both the user message and the assistant reply -> return the reply.
//
// Deploy: supabase functions deploy ai-tutor-chat
// Secrets required: ANTHROPIC_API_KEY (supabase secrets set ANTHROPIC_API_KEY=...)

import { handleCors, corsHeaders } from '../_shared/cors.ts';
import { createUserClient, getAuthedUser, AppError } from '../_shared/supabaseClient.ts';
import { callClaude } from '../_shared/anthropic.ts';

const DAILY_LIMIT_FREE = 10;
const CONTEXT_WINDOW = 12; // last N messages pulled in for context, keeps token cost bounded

const SYSTEM_PROMPT = `You are StudyNova's AI Tutor, a patient, encouraging study companion for secondary
school and university students. Explain concepts clearly, use simple language and examples, break down
complex topics step by step, and check understanding by inviting follow-up questions. Keep responses
focused and study-relevant — you are not a general-purpose assistant. Never provide answers to what
appears to be a live, proctored exam or assignment being submitted for a grade; instead, help the
student understand the underlying concept.`;

interface RequestBody {
  message: string;
  subject_id?: string;
  note_id?: string; // "Ask AI About This Note" — injects the note's content as context
}

const NOTE_CONTEXT_CHAR_LIMIT = 6000;

Deno.serve(async (req) => {
  const cors = handleCors(req);
  if (cors) return cors;

  try {
    if (req.method !== 'POST') throw new AppError('Method not allowed', 405);

    const supabase = createUserClient(req);
    const user = await getAuthedUser(supabase);

    const body = (await req.json().catch(() => null)) as RequestBody | null;
    const message = body?.message?.trim();
    if (!message) throw new AppError('A message is required.', 400);
    if (message.length > 4000) throw new AppError('Message is too long.', 400);

    // --- Server-side usage cap check (source of truth, not the client) ---
    const { data: allowed, error: usageError } = await supabase.rpc('check_and_log_ai_usage', {
      p_user_id: user.id,
      p_feature: 'tutor_chat',
      p_daily_limit: DAILY_LIMIT_FREE,
    });
    if (usageError) {
      console.error('usage check failed', usageError);
      throw new AppError('Could not verify usage limits. Please try again.', 500);
    }
    if (!allowed) {
      return new Response(
        JSON.stringify({
          error: 'daily_limit_reached',
          message: `You've used all ${DAILY_LIMIT_FREE} free tutor messages today. Upgrade to Premium for unlimited access, or try again in 24 hours.`,
        }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // --- If chatting about a specific note, load it and build note-aware context ---
    let system = SYSTEM_PROMPT;
    let noteSubjectId: string | null = null;
    if (body?.note_id) {
      const { data: note, error: noteError } = await supabase
        .from('notes')
        .select('title, subject_id, extracted_text, processing_status')
        .eq('id', body.note_id)
        .eq('user_id', user.id)
        .single();
      if (noteError || !note) throw new AppError('Note not found.', 404);
      if (note.processing_status !== 'done' || !note.extracted_text) {
        throw new AppError('This note is still being processed. Try again shortly.', 409);
      }
      noteSubjectId = note.subject_id;
      system = `${SYSTEM_PROMPT}\n\nThe student is asking about a specific uploaded note titled "${note.title}". Use it as your primary source — ground your answers in this content, and say so if something they ask isn't covered by it:\n\n"""\n${note.extracted_text.slice(0, NOTE_CONTEXT_CHAR_LIMIT)}\n"""`;
    }

    // Threads are grouped by note_id when chatting about a specific note,
    // and by subject_id otherwise. (Fixed in review: this used to group
    // note-chats by subject_id too, but notes.subject_id is null for
    // virtually every note in this MVP — there's no subject-picker UI — so
    // every note-context conversation was pulling in, and writing into, the
    // same undifferentiated general-chat bucket instead of its own thread.)
    const noteIdForThread = body?.note_id ?? null;
    const subjectIdForThread = noteIdForThread ? noteSubjectId : body?.subject_id ?? null;

    // --- Load recent context (for AI Memory Tutor continuity) ---
    let contextQuery = supabase
      .from('ai_chat_messages')
      .select('role, content')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(CONTEXT_WINDOW);
    if (noteIdForThread) {
      contextQuery = contextQuery.eq('note_id', noteIdForThread);
    } else {
      // General/subject chat: explicitly exclude note-specific threads so
      // a note conversation never bleeds into general tutor context either.
      contextQuery = contextQuery.is('note_id', null);
      if (subjectIdForThread) contextQuery = contextQuery.eq('subject_id', subjectIdForThread);
    }

    const { data: history, error: historyError } = await contextQuery;
    if (historyError) {
      console.error('history load failed', historyError);
      // Non-fatal — proceed without history rather than failing the whole request.
    }

    const conversation = (history ?? [])
      .reverse()
      .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }));
    conversation.push({ role: 'user', content: message });

    // --- Call Claude ---
    const reply = await callClaude({ system, messages: conversation, maxTokens: 1000 });

    // --- Persist both turns so history is reconstructable from the DB alone ---
    const { error: insertError } = await supabase.from('ai_chat_messages').insert([
      { user_id: user.id, subject_id: subjectIdForThread, note_id: noteIdForThread, role: 'user', content: message },
      { user_id: user.id, subject_id: subjectIdForThread, note_id: noteIdForThread, role: 'assistant', content: reply },
    ]);
    if (insertError) {
      // The reply was already generated (and billed) — log loudly but still
      // return it to the student rather than discarding a paid-for answer.
      console.error('failed to persist chat messages', insertError);
    }

    return new Response(JSON.stringify({ reply }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const status = err instanceof AppError ? err.status : 500;
    const message = err instanceof AppError ? err.message : 'Something went wrong. Please try again.';
    if (status === 500) console.error('ai-tutor-chat unhandled error', err);
    return new Response(JSON.stringify({ error: 'request_failed', message }), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
