// supabase/functions/generate-flashcards/index.ts
//
// Flow: verify ownership + plan -> confirm note is processed -> ask Claude
// for strict JSON flashcards -> write flashcard_decks + flashcards rows.
// Mirrors generate-quiz's structure closely (same sanitize-before-insert
// discipline, same idempotent-reuse pattern as generate-summary).
//
// Deploy: supabase functions deploy generate-flashcards
// Secrets required: ANTHROPIC_API_KEY

import { handleCors, corsHeaders } from '../_shared/cors.ts';
import { createUserClient, getAuthedUser, AppError } from '../_shared/supabaseClient.ts';
import { callClaude, parseJsonResponse } from '../_shared/anthropic.ts';

const DEFAULT_CARD_COUNT = 12;

const SYSTEM_PROMPT = `You create flashcards from study notes. Respond with ONLY valid JSON, no prose, no
markdown code fences, matching exactly this shape:
{
  "title": "string, short deck title",
  "cards": [
    { "front": "string, a question or term", "back": "string, the answer or definition" }
  ]
}
Each card should test one discrete fact, definition, or concept from the content — short front, concise
back (1-3 sentences max). Cover the note's main topics rather than clustering on one section. Base every
card strictly on the provided content — do not invent facts.`;

interface RequestBody {
  source_note_id: string;
  subject_id?: string;
  card_count?: number;
}

interface GeneratedCard {
  front: string;
  back: string;
}

interface GeneratedDeck {
  title: string;
  cards: GeneratedCard[];
}

Deno.serve(async (req) => {
  const cors = handleCors(req);
  if (cors) return cors;

  try {
    if (req.method !== 'POST') throw new AppError('Method not allowed', 405);

    const supabase = createUserClient(req);
    const user = await getAuthedUser(supabase);

    const body = (await req.json().catch(() => null)) as RequestBody | null;
    if (!body?.source_note_id) throw new AppError('source_note_id is required.', 400);

    // Flashcard generation follows a note through the Premium-gated pipeline
    // — no separate daily cap (same reasoning as generate-summary: the note
    // itself already required Premium to exist).
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('plan')
      .eq('id', user.id)
      .single();
    if (profileError || !profile) throw new AppError('Could not verify your plan.', 500);
    if (profile.plan !== 'premium') {
      throw new AppError('Flashcards are a Premium feature. Upgrade to unlock them.', 403);
    }

    const { data: note, error: noteError } = await supabase
      .from('notes')
      .select('id, title, subject_id, extracted_text, processing_status')
      .eq('id', body.source_note_id)
      .eq('user_id', user.id)
      .single();
    if (noteError || !note) throw new AppError('Note not found.', 404);
    if (note.processing_status !== 'done' || !note.extracted_text) {
      throw new AppError('This note is still being processed. Try again shortly.', 409);
    }

    // Reuse an existing deck for this note instead of generating (and
    // paying for) a duplicate every time the student reopens it.
    const { data: existingDeck } = await supabase
      .from('flashcard_decks')
      .select('*')
      .eq('source_note_id', note.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    if (existingDeck) {
      const { data: existingCards } = await supabase
        .from('flashcards')
        .select('*')
        .eq('deck_id', existingDeck.id)
        .order('order_index', { ascending: true });
      return new Response(JSON.stringify({ deck: existingDeck, cards: existingCards ?? [] }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const cardCount = Math.min(Math.max(body.card_count ?? DEFAULT_CARD_COUNT, 5), 25);

    const raw = await callClaude({
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: `Create ${cardCount} flashcards from these notes titled "${note.title}":\n\n${note.extracted_text.slice(0, 15000)}`,
        },
      ],
      maxTokens: 3000,
    });

    const generated = parseJsonResponse<GeneratedDeck>(raw);

    // Same defensive discipline as generate-quiz: don't trust the model's
    // JSON to be perfectly well-formed against what the client will render.
    const sanitizedCards = (generated.cards ?? [])
      .filter((c) => c.front?.trim() && c.back?.trim())
      .map((c) => ({ front: c.front.trim(), back: c.back.trim() }));

    if (!sanitizedCards.length) {
      throw new AppError('The AI did not return any usable flashcards. Please try again.', 502);
    }

    const { data: deck, error: deckError } = await supabase
      .from('flashcard_decks')
      .insert({
        user_id: user.id,
        subject_id: body.subject_id ?? note.subject_id ?? null,
        source_note_id: note.id,
        title: generated.title || note.title,
        card_count: sanitizedCards.length,
      })
      .select()
      .single();

    if (deckError || !deck) {
      console.error('failed to insert flashcard deck', deckError);
      throw new AppError('Could not save the generated flashcards. Please try again.', 500);
    }

    const cardRows = sanitizedCards.map((c, i) => ({
      deck_id: deck.id,
      order_index: i,
      front: c.front,
      back: c.back,
    }));

    const { data: cards, error: cardsError } = await supabase.from('flashcards').insert(cardRows).select();

    if (cardsError) {
      console.error('failed to insert flashcards', cardsError);
      await supabase.from('flashcard_decks').delete().eq('id', deck.id);
      throw new AppError('Could not save the generated flashcards. Please try again.', 500);
    }

    return new Response(JSON.stringify({ deck, cards }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const status = err instanceof AppError ? err.status : 500;
    const message = err instanceof AppError ? err.message : 'Something went wrong. Please try again.';
    if (status === 500) console.error('generate-flashcards unhandled error', err);
    return new Response(JSON.stringify({ error: 'request_failed', message }), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
