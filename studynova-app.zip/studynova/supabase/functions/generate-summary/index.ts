// supabase/functions/generate-summary/index.ts
//
// Flow: verify ownership + plan -> confirm note is processed -> ask Claude
// for a structured summary -> write to ai_generated_content (type='summary')
// -> return it.
//
// Called by the client right after `process-note` succeeds, as a separate
// step (not folded into process-note) so extraction and summarization stay
// independently retryable — a failed summary shouldn't force re-extracting
// a note, and vice versa.
//
// Deploy: supabase functions deploy generate-summary
// Secrets required: ANTHROPIC_API_KEY

import { handleCors, corsHeaders } from '../_shared/cors.ts';
import { createUserClient, getAuthedUser, AppError } from '../_shared/supabaseClient.ts';
import { callClaude, parseJsonResponse } from '../_shared/anthropic.ts';

// Note upload/processing is Premium-only, so summaries aren't rate-limited
// per day the way tutor chat / quiz generation are — but every call is
// still logged to ai_usage_log for cost visibility.
const USAGE_LOG_LIMIT = 999999;

const SYSTEM_PROMPT = `You summarize study notes for students. Respond with ONLY valid JSON, no prose, no
markdown code fences, matching exactly this shape:
{
  "key_points": ["string", "string", ...],
  "sections": [{ "heading": "string", "body": "string, 2-4 sentences" }],
  "exam_tips": ["string", "string", ...]
}
Keep it concise and exam-focused: 4-8 key points, 2-5 sections covering the note's main topics in the
order they appear, and 2-4 practical exam tips grounded in the actual content. Do not invent facts not
present in the source text.`;

interface RequestBody {
  note_id: string;
}

Deno.serve(async (req) => {
  const cors = handleCors(req);
  if (cors) return cors;

  try {
    if (req.method !== 'POST') throw new AppError('Method not allowed', 405);

    const supabase = createUserClient(req);
    const user = await getAuthedUser(supabase);

    const body = (await req.json().catch(() => null)) as RequestBody | null;
    if (!body?.note_id) throw new AppError('note_id is required.', 400);

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('plan')
      .eq('id', user.id)
      .single();
    if (profileError || !profile) throw new AppError('Could not verify your plan.', 500);
    if (profile.plan !== 'premium') {
      throw new AppError('AI summaries are a Premium feature. Upgrade to unlock them.', 403);
    }

    const { data: note, error: noteError } = await supabase
      .from('notes')
      .select('id, title, subject_id, extracted_text, processing_status')
      .eq('id', body.note_id)
      .eq('user_id', user.id)
      .single();
    if (noteError || !note) throw new AppError('Note not found.', 404);
    if (note.processing_status !== 'done' || !note.extracted_text) {
      throw new AppError('This note is still being processed. Try again shortly.', 409);
    }

    // Return the existing summary if one was already generated for this
    // note, rather than paying for a duplicate Claude call.
    const { data: existing } = await supabase
      .from('ai_generated_content')
      .select('*')
      .eq('source_note_id', note.id)
      .eq('type', 'summary')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    if (existing) {
      return new Response(JSON.stringify({ summary: existing }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { error: usageError } = await supabase.rpc('check_and_log_ai_usage', {
      p_user_id: user.id,
      p_feature: 'note_conversion',
      p_daily_limit: USAGE_LOG_LIMIT,
    });
    if (usageError) console.error('usage log failed (non-fatal)', usageError);

    const raw = await callClaude({
      system: SYSTEM_PROMPT,
      messages: [
        { role: 'user', content: `Summarize these notes titled "${note.title}":\n\n${note.extracted_text.slice(0, 15000)}` },
      ],
      maxTokens: 2000,
    });

    const parsedRaw = parseJsonResponse<{ key_points?: unknown; sections?: unknown; exam_tips?: unknown }>(raw);
    // The client calls .map() directly on these fields — a model response
    // that deviates from the requested shape (e.g. returns a string instead
    // of an array) would otherwise crash the Notes screen on render.
    const parsed = {
      key_points: Array.isArray(parsedRaw.key_points) ? parsedRaw.key_points : [],
      sections: Array.isArray(parsedRaw.sections) ? parsedRaw.sections : [],
      exam_tips: Array.isArray(parsedRaw.exam_tips) ? parsedRaw.exam_tips : [],
    };

    const { data: summary, error: insertError } = await supabase
      .from('ai_generated_content')
      .insert({
        user_id: user.id,
        source_note_id: note.id,
        subject_id: note.subject_id,
        type: 'summary',
        content: parsed,
      })
      .select()
      .single();

    if (insertError || !summary) {
      console.error('failed to save summary', insertError);
      throw new AppError('The summary was generated but could not be saved. Please try again.', 500);
    }

    return new Response(JSON.stringify({ summary }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const status = err instanceof AppError ? err.status : 500;
    const message = err instanceof AppError ? err.message : 'Something went wrong. Please try again.';
    if (status === 500) console.error('generate-summary unhandled error', err);
    return new Response(JSON.stringify({ error: 'request_failed', message }), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
