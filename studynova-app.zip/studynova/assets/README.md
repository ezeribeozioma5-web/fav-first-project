# StudyNova brand assets

`icon-concept.svg` is the logo source: an open book + a four-point "Nova"
spark on a deep-navy field, in the brand's light-blue accents — the same
mark used in the animated splash screen (`app/index.tsx`).

**`icon.png` / `adaptive-icon.png` / `splash.png` are placeholders**, added
during the stabilization pass so `app.json` doesn't reference missing files
(which blocked Expo from loading config at all). They're simple
programmatically-drawn circles in the brand colors — functional, not final.
Swap them for a real export of `icon-concept.svg` when ready:

```bash
# any of these work — pick whichever is available to you:
npx svgexport icon-concept.svg icon.png 1024:1024
# or open icon-concept.svg in Figma/Illustrator/Inkscape and export at:
#   icon.png            1024×1024
#   adaptive-icon.png   1024×1024 (foreground layer only, safe-zone centered, transparent background)
#   splash.png          moderate size, e.g. 400×400, transparent background
#                        (app.json's splash.backgroundColor #0F172A fills the rest)
```

Drop the exported files into this folder with those exact names and the app
will pick them up automatically — nothing else needs to change.
