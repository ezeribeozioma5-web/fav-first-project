# StudyNova — MVP

AI-powered study companion. React Native (Expo) + TypeScript + Supabase.

**Tagline:** StudyNova — Your Study Companion

## Branding note
The app was rebranded from LearnGenie to StudyNova (display name, slug, deep-link
scheme, all UI copy, docs, and code comments). The iOS `bundleIdentifier` and
Android `package` in `app.json` were deliberately **left as
`com.learngenie.app`** — those are store-listing identifiers, not display
branding, and changing them would affect app store linkage / analytics
continuity. Rename that separately if/when you're ready to also change the
store listing identity.

## Design system
Light and dark palettes are both first-class (`darkMode: "media"` in
`tailwind.config.js` — the app follows system appearance automatically; there's
no manual toggle wired yet, see Profile → Appearance, still a stub).

| Token | Light | Dark |
|---|---|---|
| Primary | `#7DD3FC` | `#38BDF8` |
| Secondary | `#BFDBFE` | `#60A5FA` |
| Accent | `#38BDF8` | `#7DD3FC` |
| Background | `#FFFDF7` | `#0F172A` |
| Surface | `#FFFFFF` | `#1E293B` |
| Border | `#E5E7EB` | `#334155` |
| Text primary | `#1E293B` | `#F8FAFC` |
| Text secondary | `#64748B` | `#CBD5E1` |
| Success / Warning / Error | `#22C55E` / `#F59E0B` / `#EF4444` | `#22C55E` / `#FBBF24` / `#F87171` |

Usage pattern throughout the app: `bg-primary dark:bg-primary-dk`,
`text-ink dark:text-ink-dk`, etc. — every color token has a `-dk` suffix
variant reached via NativeWind's `dark:` prefix. Raw values (for
`StyleSheet.create`, SVGs, chart libraries) are mirrored in
`src/theme/tokens.ts` under `colors.light` / `colors.dark`.

Radius increased to 20px (`rounded-card`) for the more premium, Linear/Gemini-
inspired feel called for in the rebrand brief (up from 16px). New shared
components: `Skeleton` / `SkeletonCard` (shimmer loading, used on the
dashboard's weekly stats and ready to reuse anywhere AI content is generating),
`EmptyState` (consistent empty-screen pattern, currently used on Notes).

## What's built

- ✅ Branded splash screen — glowing "Nova" star + open-book mark, animated, 1.4s
- ✅ Onboarding (3-slide swipeable intro)
- ✅ Sign up / Login (Supabase Auth)
- ✅ Home dashboard (streak, quick actions, weekly stats with skeleton loading + pull-to-refresh)
- ✅ AI Tutor chat with daily free-tier limit UI (10 msgs/day free, unlimited premium), animated typing indicator, and note-aware context (see below)
- ✅ **Full Notes → Summary → Quiz workflow**: upload → extract → auto-generate summary → generate a quiz or ask the tutor, all from one expandable note card
- ✅ **Full quiz-taking experience**: question navigation, elapsed timer, progress bar, MCQ/true-false/fill-blank/short-answer support, instant scoring, per-question review with explanations, persisted quiz history
- ✅ **Subject/course organization**: create subjects inline, filter Notes and Practice history by subject, subject-scoped AI Tutor threads, notes auto-tag generated quizzes with their subject
- ✅ **Education Stage/Class taxonomy**: `class_levels` (JSS1–SS3, 100L–500L+) + `exam_tracks` (BECE/WAEC/NECO/JAMB), on `profiles` — schema-only in this round, no onboarding/profile UI to collect it yet (see "Architecture decisions" below for why that's deliberate)
- ✅ **Official content catalog scaffolding**: `study_materials` table exists and is queryable (read-only, published+tier-gated), but is empty — no admin tooling to populate it yet
- ✅ **Flashcards**: AI-generated from processed notes, swipe/flip study screen, known/learning/review-later progress tracking, decks persist and are re-openable from the source note
- ✅ **Study Planner + Assignment & Exam Tracker** (new 6th tab): unified view of assignments/exams/study sessions, subject filtering, day-granularity date picker (no native dependency — see below), completion toggling with optimistic UI, Home dashboard's previously-dead "Today's focus" CTA now links here and shows a real count
- ✅ Profile / settings screen with upgrade prompt
- ✅ Offline detection banner + per-screen offline guards

Design system tokens live in `src/theme/tokens.ts` and `tailwind.config.js`.

## Subject/course organization

Activates the `subjects` table and `subject_id` FKs that existed since the
original schema but were never wired to any UI (see "Bugs found" below for
why that mattered more than it looked like it would).

**Database:** no structural changes — `subjects`, and the `subject_id`
columns on `notes`/`quizzes`/`ai_generated_content`/`ai_chat_messages`, were
already correct (`on delete set null` everywhere, so deleting a subject
un-links content rather than touching it). This round added:
- `subjects(user_id, name)` unique constraint — prevents duplicates from the
  lightweight inline "+ New Subject" flow, which has no separate validation screen
- Indexes on the four `subject_id` columns (never queried against until now)
- `ai_chat_messages.note_id` (added during the stabilization review, not this
  feature, but subjects build on top of it — see that section)

Migration: `20260104000000_subjects_activation.sql`

**Scope cuts for v1** (per product decision): no dedicated "My Subjects"
management screen, no color/icon picker. Colors/icons auto-assign from a
fixed rotation (`PALETTE` in `useSubjectsStore.ts`). Rename/delete happen via
long-press on any subject chip, anywhere one appears.

**New shared components** (`src/components/`): `SubjectChip` (tap to
select/filter, long-press for rename/delete — the only subject-management UI
in v1), `SubjectPicker` (bottom-sheet modal: pick existing or create new),
`SubjectFilterRow` (horizontal chip filter, self-hides until ≥1 subject
exists to avoid showing an empty control).

**Where it shows up:**
- **Notes tab** — filter row above the list; picking a subject is now step
  one of uploading (opens right after file selection, "Uncategorized" always
  available as a skip); each note card shows its subject tag
- **Practice tab** — same filter row on quiz history; the manual quiz
  generator has an optional subject tag; quiz-from-note already inherited the
  note's subject automatically (no change needed there)
- **AI Tutor** — a subject switcher in the header for general (non-note)
  chats, which **reactivates previously-dead code**: `ai-tutor-chat` has
  threaded on `subject_id` for general chat since it was written, but nothing
  ever sent one, so every general conversation was one flat undifferentiated
  thread. It now actually does what it was always supposed to.

## Architecture decisions: education taxonomy + dual content model

Two structural questions came up before Flashcards, both resolved by adding
schema now rather than risking a retrofit later (the project has already hit
that exact class of bug twice — see the stabilization review below).

### Education Stage/Class — why now, not deferred
`profiles.education_level` existed as a crude `'secondary' | 'university'`
enum, unused by any code. Rather than let it keep sitting there wrong-shaped
while more features get built, it's replaced with a proper taxonomy:

- **`class_levels`** — grade/level lookup (JSS1–JSS3, SS1–SS3, 100 Level–500
  Level+), global, admin-managed, read-only to clients
- **`exam_tracks`** — BECE/WAEC/NECO/JAMB, kept as a **separate** dimension
  from class level on purpose: an SS3 student might target WAEC, NECO, or
  both, and JAMB candidates span multiple class levels — folding both into
  one column would mean encoding two independent concerns as string soup
- **`profiles.class_level_id` / `profiles.exam_track_id`** — nullable FKs,
  additive

**What's deliberately deferred:** collecting this in onboarding, editing it
in Profile, and filtering content by it. All pure additive UI with zero
schema risk either order — building it now would just be scope creep ahead
of actual need. The schema is ready; the UI isn't built until something
depends on it.

Migration: `20260105000000_education_taxonomy.sql`

### Official content vs. user-generated content — kept structurally separate
`study_materials` is a new, **ownerless** table (no `user_id`) for official
StudyNova content, tagged by `class_level_id` + `exam_track_id` +
`subject_tag`. It's deliberately NOT merged into `notes`/`ai_generated_content`
with a nullable `user_id` — that would mean every existing RLS policy on
those tables needs a second, conditional branch for "or it's official
content," for a case that doesn't apply to 95% of rows. Two parallel domains
is simpler and safer:

| | Personal (existing) | Catalog (new) |
|---|---|---|
| Tables | `notes`, `quizzes`, `flashcard_decks`, `ai_generated_content` | `study_materials` |
| Owner | `user_id`, RLS-scoped | none — admin-managed |
| Organized by | `subject_id` (personal subjects) | `class_level_id` + `exam_track_id` + `subject_tag` |
| Write access | the owning user | service role only (no admin UI yet) |

`study_materials` has RLS allowing `select` where `is_published = true`, and
no insert/update/delete policy for the client role — it's empty right now
and stays empty until admin tooling exists to populate it. The schema is
ready for that without needing another migration when it does.

## Flashcards

Mirrors the `quizzes`/`quiz_questions` pattern closely: `flashcard_decks`
(parent, like `quizzes`) + `flashcards` (children, like `quiz_questions`),
including `subject_id` from day one — no retrofit needed now that subjects
exist, which was the point of building subjects first.

**Progress tracking**, per product decision to keep it simple: three states
(`learning` / `known` / `review_later`), no spaced-repetition scheduling
(ease factors, intervals) — that's real future work, not MVP scope.

**Edge Function:** `generate-flashcards` — Premium-gated (via the note),
same idempotent-reuse pattern as `generate-summary` (returns the existing
deck for a note instead of regenerating), same sanitize-before-insert
discipline as `generate-quiz`.

**Study screen** (`app/flashcards/[id].tsx`): tap to flip (front/back, 3D
rotateY), swipe right for "known" / left for "review later" (also available
as buttons — swipe isn't the only path), progress bar, and a completion
summary with known/review-later/learning counts. Status updates persist to
`flashcards.status` immediately, so decks are genuinely revisitable — no
"save" step, every swipe is already saved.

**"Save and revisit" scope note:** decks are reachable by reopening the
source note and tapping Flashcards again (idempotent — reuses the existing
deck rather than regenerating). There's no standalone "My Flashcard Decks"
browsing screen, matching the same v1 scope cut made for Subjects
(no dedicated management screen) — revisit if this turns out to be a
real friction point once there's usage data.

## Study Planner + Assignment & Exam Tracker

Foundational milestone per the approved implementation plan — Daily Brief,
Semester Dashboard, Smart Exam Mode, and Smart Notifications all depend on
this existing first, so it shipped alone before any of those.

**Database:** `assignments`, `exams`, `study_sessions` — same discipline as
every table before them: `user_id` + RLS, `subject_id` FK reusing the
existing personal Subjects system (not a new parallel one), indexes on every
FK and date column from the start. `remind_at` columns exist on
assignments/exams now but aren't wired to any notification delivery yet —
that's the separately-scoped Smart Notifications phase; capturing the column
now avoids the exact retrofit class this project has hit before, without
shipping a "reminder" that doesn't actually remind anyone yet.

**Scope decision: day-granularity only, no time-of-day.** Assignments/exams
store `timestamptz` (room to add time precision later without a schema
change) but the picker only lets you choose a date — no time picker was
built this round. Study sessions use a plain `date` column (no time
component at all). Keeps this milestone's UI surface small; upgradeable
later without breaking existing rows.

**No new native dependency.** Rather than add
`@react-native-community/datetimepicker` (uncertain exact SDK 51-compatible
version without the ability to test-install it in this environment — and
this project has been burned by an under-verified dependency before, see the
boot audit), built `DatePickerModal` from plain RN primitives: a
month-grid calendar, prev/next navigation, tap to select. Zero new
dependencies, works identically in Expo Go.

**One form, three types.** `PlannerItemModal` handles assignments, exams,
and study sessions with conditional fields (priority for assignments,
duration for sessions) rather than three near-duplicate modals — matches the
"avoid duplicate code" instruction and the same pattern already used for
quiz/flashcard generation forms.

**"Missed" sessions are derived, not written.** `study_sessions.status`
supports `'missed'` in the schema, but nothing in this milestone
automatically flips a planned session to missed when its date passes — that
would need a scheduled job. Instead, the UI shows overdue items with
supportive framing ("3 days ago — still time to catch up") rather than an
alarming red state, per the "never shame students" product requirement, and
never silently changes what the student planned.

**Navigation:** added as a 6th tab (🗓️ Planner), positioned right after
Home. Tab label font size was reduced from 11→10 to keep 6 labels
comfortable on narrower phones — the only cross-cutting UI change made for
this feature, and it's a numeric tweak, not a redesign.

## User flow: Notes → Summary → Quiz → Tutor

```
Upload a note (Notes tab)
  → Storage upload → notes row (pending)
  → process-note Edge Function → extracted_text, status: done
  → generate-summary Edge Function (auto-triggered) → ai_generated_content (type: summary)
  → note card expands to show key points + exam tips

From an expanded, processed note card:
  🎯 Generate Quiz → generate-quiz Edge Function (source_note_id) → quizzes + quiz_questions
                   → navigates straight into /quiz/[id] (the taking screen)
  🤖 Ask AI About This → navigates to AI Tutor with note_id/note_title params
                       → ai-tutor-chat injects the note's extracted_text as system context
                       → conversation threads under the note's subject_id, same as any other thread

Practice tab:
  Manual topic entry → generate-quiz (topic only) → /quiz/[id]
  Quiz history list → tap a past quiz → review (if completed) or resume (if not)

/quiz/[id] (question flow):
  Load quiz + questions (direct client read, RLS-protected — no Edge Function needed)
  → insert quiz_attempts row (status: in_progress)
  → student answers each question, Next/Previous navigation, live timer + progress bar
  → Submit → compute score client-side → bulk-insert quiz_answers
           → update quiz_attempts (status: completed, score, correct_count, time_taken_seconds)
  → results screen: score circle, per-question correct/incorrect + explanation
```

## Edge Functions

Located in `supabase/functions/`, each self-contained and independently deployable:

- **`ai-tutor-chat`** — checks the daily cap (`check_and_log_ai_usage`), loads
  the last 12 messages for context, calls Claude, persists both the user
  message and the reply to `ai_chat_messages`, returns the reply. Returns a
  `429` with `{ error: 'daily_limit_reached', message }` when the cap is hit.
  **New:** accepts an optional `note_id` — when present, loads that note's
  `extracted_text` and injects it into the system prompt so the tutor answers
  grounded in the note's actual content; the conversation thread groups under
  the note's `subject_id` (no schema change needed for this).
- **`generate-quiz`** — checks the daily cap, pulls context from either a raw
  topic string or a processed note's `extracted_text`, asks Claude for strict
  JSON questions, writes one `quizzes` row + N `quiz_questions` rows
  (transactional-ish: rolls back the quiz row if question insert fails).
- **`generate-summary`** *(new)* — Premium-gated, takes a processed note,
  asks Claude for a structured summary (`key_points` / `sections` /
  `exam_tips`), writes one `ai_generated_content` row (`type: 'summary'`).
  Returns the existing summary instead of regenerating if one already exists
  for that note (avoids paying for duplicate Claude calls on re-expand).
  Logged to `ai_usage_log` under `note_conversion` for cost visibility, but
  not rate-limited per-day since it's already Premium-gated at the note level.
- **`generate-flashcards`** *(new)* — Premium-gated, takes a processed note,
  asks Claude for a structured flashcard set, writes one `flashcard_decks`
  row + N `flashcards` rows. Returns the existing deck instead of
  regenerating if one already exists for that note (same reuse pattern as
  `generate-summary`).
- **`process-note`** — Premium-gated server-side (not just hidden in the UI),
  downloads the file from Storage, extracts text (PDF/images via Claude's
  native document/vision support; plain text decoded directly), updates the
  `notes` row. **Known MVP limitation:** DOCX/PPTX aren't parsed yet — the
  function returns a clear `415` error for those; see the comment in
  `process-note/index.ts` for the recommended next step.

All four: validate input, wrap logic in try/catch, return structured
`{ error, message }` JSON with an appropriate status code, and never expose
raw upstream error details to the client (logged server-side only).

Shared code lives in `supabase/functions/_shared/`: `supabaseClient.ts` (user
JWT-scoped client + `AppError`), `anthropic.ts` (Claude API wrapper + JSON
parsing), `cors.ts`.

## Database — one schema change this round

Priority 1 & 2 features were built on the schema approved previously
(`quizzes` / `quiz_questions` / `quiz_attempts` / `quiz_answers`). During the
stabilization review, one real column was added: `ai_chat_messages.note_id`
(migration `20260103000000_chat_note_id.sql`) — see "Known limitations &
critical issues" below for why. One **behavioral** fix worth noting
separately: the Notes screen previously only showed notes uploaded in the
current session (local state only); it now fetches the user's persisted
`notes` rows from Supabase on mount and on pull-to-refresh, so notes survive
app restarts as they always should have.

## Boot audit (Expo Go stabilization pass)

A dedicated pass to make sure the app actually launches, separate from the
earlier functional stabilization review below. Found and fixed **four
confirmed boot blockers** and one first-run crash risk — none of this was
theoretical; each one would stop the app from bundling or rendering at all.

### 🔴 Boot blockers (app would not start)
- **`metro.config.js` was missing entirely.** NativeWind v4 requires it to
  process the `import '../global.css'` in the root layout; without it,
  Metro has no transform for that import and the bundle fails on the very
  first screen. Added, wrapping `expo/metro-config` with `withNativeWind`.
- **`@expo-google-fonts/inter` was imported in `app/_layout.tsx` but never
  declared in `package.json`.** `npm install` wouldn't have installed it,
  and the root layout — the app's entry point — would fail to resolve the
  import immediately. Added to dependencies.
- **`app.json` referenced `assets/icon.png`, `adaptive-icon.png`, and
  `splash.png`, none of which existed** (only `icon-concept.svg`, the design
  source, was ever generated — see the earlier branding work). Expo fails
  to load config at all without these. Generated placeholder PNGs in the
  brand colors; swap for a real export of the SVG when ready (see
  `assets/README.md`).
- **Supabase client construction crashed at module-load time with no `.env`
  configured**, throwing supabase-js's generic internal error before any
  screen could render. Added a clear, actionable error message instead, plus
  a `.env.example` so the required setup step isn't guesswork.

### 🟡 Robustness fixes (worked, but fragile)
- Two places used inline `require()` calls instead of top-level imports
  (`react-native-reanimated` and `react` in the Tutor screen's typing
  indicator; `nativewind` in the tabs layout) — functional under Metro's
  CommonJS interop, but unnecessarily fragile and inconsistent with every
  other import in the codebase. Converted to standard ES imports.
- Added `.gitignore` (was missing — real risk of committing `.env` secrets
  or bloating the repo with `node_modules`/build artifacts).

### ✅ Audited and confirmed clean (no issues found)
- Every `@/` alias import (`src/components`, `src/stores`, `src/hooks`,
  `src/services`, `src/theme`, `src/types`) resolves to a real file —
  checked programmatically against the filesystem, not by inspection
- Every bare npm import used in `app/`/`src/` is declared in `package.json`
  — checked package-by-package, including scoped packages
  (`@supabase/supabase-js`, `@tanstack/react-query`, etc.)
- Every `router.push`/`router.replace` target matches a real route file,
  including dynamic routes (`/quiz/[id]`, `/flashcards/[id]`)
- `tsconfig.json` path alias (`@/*` → `src/*`) is resolved by
  `expo/metro-config`'s built-in tsconfig support (confirmed present via the
  now-existing `metro.config.js` extending it) — no separate babel resolver
  plugin needed
- `babel.config.js`'s NativeWind v4 preset/plugin order and
  `react-native-reanimated/plugin` position (must be last) are both correct
- Pinned dependency versions (`expo ~51.0.0`, `expo-router ~3.5.0`,
  `react-native 0.74.0`, `react-native-reanimated ~3.10.0`,
  `react-native-gesture-handler ~2.16.0`, `nativewind ^4.0.36`) are mutually
  compatible — no version mismatches within the pinned set
- All JSON config files (`package.json`, `app.json`, `tsconfig.json`) are
  syntactically valid after every edit made across this project's history

## Setup

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Create a Supabase project** at supabase.com, then run `supabase/schema.sql`
   in the SQL editor (Table Editor → SQL Editor → paste → run), or
   `supabase db push` to apply `supabase/migrations/`.

3. **Create the `notes` storage bucket** (private) — SQL for this is
   commented at the bottom of `schema.sql`.

4. **Set Edge Function secrets**
   ```bash
   supabase secrets set ANTHROPIC_API_KEY=your-key-here
   ```
   (`SUPABASE_URL` and `SUPABASE_ANON_KEY` are injected automatically by
   Supabase for Edge Functions — you don't set those yourself.)

5. **Deploy the functions**
   ```bash
   supabase functions deploy ai-tutor-chat
   supabase functions deploy generate-quiz
   supabase functions deploy generate-summary
   supabase functions deploy generate-flashcards
   supabase functions deploy process-note
   ```

6. **App environment variables** — copy `.env.example` to `.env` and fill in
   real values:
   ```bash
   cp .env.example .env
   ```
   ```
   EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
   ```
   If this step is skipped, the app fails fast with a clear message telling
   you exactly this, instead of a cryptic crash on launch (fixed in the
   stabilization pass below).

7. **Run it**
   ```bash
   npx expo start
   ```

## Known limitations & critical issues (stabilization review)

A full bug-and-edge-case review was done before starting Priority 3. Fixes
are already applied in this codebase; what's listed here is what's
**known and intentionally left** as-is for now.

### 🔴 Must fix before any real release
- **No real payment integration.** Note upload/summaries/quiz-from-note are
  Premium-gated server-side, but there was no in-app way to *become*
  Premium — a fresh signup couldn't test the core journey at all. Profile
  now has a **dev-only "Upgrade now" toggle** that flips `profiles.plan`
  directly via an authenticated client update, clearly labeled in the code
  and UI as a stand-in. **This is also a live security gap**: the
  `profiles` RLS UPDATE policy has no column restriction, so any
  authenticated user can currently set their own `plan` to `'premium'` via
  a direct API call, toggle UI or not. Before release: replace with a real
  RevenueCat/Stripe flow, sync `plan` only via a service-role webhook, and
  tighten the RLS policy to block client writes to `plan`/`plan_renews_at`.
- **Quiz retake, not resume.** Tapping a past quiz in Practice history —
  completed or not — always starts a brand new `quiz_attempts` row; there's
  no true resume. Labeled truthfully in the UI ("Retake" / "Start", not
  "Continue" or "Review") rather than implying capability that isn't there.

### 🟡 Accepted for MVP, documented
- **Fill-in-the-blank / short-answer grading** is a case-insensitive exact
  string match against `correct_answer`, not AI-graded. A correct answer
  phrased differently than the stored answer will be marked wrong. Product
  decision: acceptable for MVP; AI-assisted grading is future work. See the
  comment above `isAnswerCorrect()` in `app/quiz/[id].tsx`.
- **"Hours studied" on the dashboard** is a proxy: sum of `time_taken_seconds`
  across completed quiz attempts in the last 7 days. It reflects quiz-taking
  time only, not broader study session time (nothing tracks that yet).
- **DOCX/PPTX notes aren't parsed** — clear `415` error on upload; PDF/image/
  text work via Claude's native document support. See `process-note`.
- Dark mode has no manual toggle (follows system appearance only).

### Bugs found and fixed in this review pass
- **Onboarding was unreachable for new signups** — the root route guard
  didn't exempt `/onboarding`, so first-time users got bounced straight to
  Login before ever seeing it.
- **Note-context AI Tutor threading was broken** — conversations were
  grouped by `notes.subject_id`, which is null for virtually every note (no
  subject-picker UI exists), so note-specific chats either pulled in
  unrelated chat history or bled into general chat. Fixed by adding
  `ai_chat_messages.note_id` and threading on that directly
  (migration `20260103000000_chat_note_id.sql`).
- **`process-note` had a duplicate, schema-incompatible summary generator**
  left over from an earlier draft, alongside the dedicated `generate-summary`
  function — the two wrote differently-shaped JSON to the same table, which
  would have crashed the Notes screen's `.map()` calls whenever the "reuse
  existing summary" check in `generate-summary` returned a row written by
  the old code path. Removed; `process-note` is extraction-only again.
- **Dashboard stats were permanently hardcoded to zero** even after
  Priority 2 shipped real quiz data — now a real 7-day aggregate query.
- **Silent upload failures** — if Storage upload or the DB insert failed
  before a `notes` row existed, the user got zero feedback. Now surfaced
  via an inline error banner.
- **Stale note-context on Tutor revisits** — because tabs stay mounted,
  asking about a second note (or clearing back to general chat) after the
  Tutor tab was already visited didn't update the welcome message or
  context; fixed with an effect keyed on `note_id`.
- **Unreliable "clear note context"** — `router.setParams({..: undefined})`
  isn't a reliable way to remove params in Expo Router; switched to
  `router.replace('/(tabs)/tutor')`.
- **Quiz history ordering bug** — sorted by `completed_at`, which is null
  for in-progress attempts, so "most recent attempt" was ambiguous. Now
  sorts by `started_at`, which is always set.
- **Unvalidated AI output against strict DB constraints** — `generate-quiz`
  trusted Claude's JSON to exactly match `quiz_questions`' CHECK constraints
  (question_type, difficulty); a single malformed field could fail the
  whole insert after the quiz row was already created. Now sanitized/clamped
  before insert. Same class of fix applied to `generate-summary` (guards
  against non-array fields the client's `.map()` calls would otherwise
  crash on).
- **Quiz result save failures were silent** — if the final `quiz_answers`/
  `quiz_attempts` write failed (e.g. mid-submit connectivity drop), the
  score still showed but "quiz history" would quietly not reflect it, with
  no indication. Now flagged inline on the results screen.
- Added offline checks to Login/Signup (only screens that lacked it) and an
  offline-aware error + duplicate-attempt guard to the quiz-taking screen's
  load step.

## Is this ready for end-to-end testing?

**Yes, with one required step first:** after signing up, use Profile →
"Upgrade now (dev toggle)" before testing Notes/Tutor/Quiz-from-note — those
are Premium-gated and there's no other way to unlock them yet (see 🔴 above).
General AI Tutor chat and topic-based quiz generation work on the free plan
without the toggle. With that step, the full journey — sign up → upload note
→ summary → generate quiz → take quiz → review results → ask AI about the
note — is traceable end-to-end through real code paths, not stubs.

**Not ready for production release** until the 🔴 items above are addressed —
particularly the payment/plan-security gap, which is a real, exploitable
hole as written, not just a missing feature.


## Feature backlog

Approved roadmap (from the GPA Hub / Semester tools planning round) — this
supersedes the older priority list below it, which is folded in where still
relevant rather than dropped.

1. ~~**Study Planner + Assignment & Exam Tracker**~~ ✅ done this round
2. **GPA Hub** — Calculator, CGPA, Predictor, Target GPA, Goal Tracker,
   Semester Projection. Independent of the Planner; can start any time.
   Needs new `courses`/`grades`/`gpa_targets` tables and a configurable
   grading scale (5.0 / 4.0 / extensible) — **onboarding should ask "University
   uses: 5.0 Scale / 4.0 Scale" and let it be changed later in Settings**,
   per product decision, so the app works across Nigerian universities and
   elsewhere without separate builds.
3. **Daily Brief** — thin dashboard layer over Planner + GPA Hub + existing
   streak/subject data. The Home dashboard's "Today's focus" card is the
   natural seed for this — already wired to real Planner data this round.
4. **Focus Mode** — Pomodoro timer, task list pulled from the Planner, AI
   Tutor shortcut, distraction-free UI
5. **Semester Dashboard + Weekly Reflection + Study Health** — natural to
   build together, rollup/analytics views over data that exists by this
   point. Folds in the older "student analytics" backlog item below.
6. **Smart Exam Mode (Premium)** — depends on the Planner's scheduling
   infrastructure; adds AI-generated revision-plan layer on top
7. **Smart Notifications (local/scheduled only)** — depends on steps 1 and 6;
   `assignments.remind_at` / `exams.remind_at` columns already exist,
   unwired, waiting for this phase
8. **Global Search (keyword-based)** — across notes, chats, quizzes,
   flashcards, subjects, official study materials
9. **Premium feature expansion + Offline Downloads** — offline downloads
   free-tier capped at 2 notes, unlimited on Premium, per product decision
10. **Future phase, separately scoped:** AI-powered natural language search
    (Premium), Widgets (needs a dev build + EAS — not Expo-Go-compatible,
    see the implementation plan doc for why), Remote push notifications

### Carried forward from the pre-existing backlog, not yet superseded
- DOCX/PPTX support in `process-note` (known limitation, unchanged)
- Weak-topic detection — `quiz_answers.topic_tag` already captures the raw
  signal; folds into step 5 above (Study Health) rather than being separate
- "My Subjects" / "My Flashcard Decks" management screens + color/icon
  picker — still cut from v1, still revisit-when-there's-usage-data
- Onboarding/Profile UI to collect `class_level_id`/`exam_track_id` — still
  schema-ready, not built; **the GPA scale prompt in step 2 is a natural
  place to extend onboarding anyway**, worth doing together when step 2 lands
- Wire real `ai_usage_log` counts into Tutor/Quiz UI (still a polish item,
  server-side cap is already authoritative)
