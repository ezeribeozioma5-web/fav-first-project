// Hand-written for now — once the schema is live, replace this file by running:
//   npx supabase gen types typescript --project-id <id> > src/types/database.ts

export type Plan = 'free' | 'premium';

export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  class_level_id: string | null;
  exam_track_id: string | null;
  plan: Plan;
  streak_count: number;
  xp_points: number;
  last_active_date: string | null;
  onboarding_completed: boolean;
  created_at: string;
}

export interface ClassLevel {
  id: string;
  stage: 'junior_secondary' | 'senior_secondary' | 'tertiary';
  label: string;
  sort_order: number;
  created_at: string;
}

export interface ExamTrack {
  id: string;
  code: string;
  label: string;
  applies_to_stage: 'junior_secondary' | 'senior_secondary' | 'tertiary' | null;
  created_at: string;
}

// Official, built-in StudyNova content — ownerless (no user_id), admin-
// managed, read-only to clients. Kept fully separate from user-generated
// content (notes / ai_generated_content) rather than merged into it.
export interface StudyMaterial {
  id: string;
  class_level_id: string | null;
  exam_track_id: string | null;
  subject_tag: string;
  type: 'note' | 'summary' | 'quiz' | 'flashcards' | 'study_guide';
  title: string;
  content: Record<string, unknown>;
  tier_required: Plan;
  is_published: boolean;
  created_at: string;
}

export interface Subject {
  id: string;
  user_id: string;
  name: string;
  color: string;
  icon: string;
  created_at: string;
}

export interface Note {
  id: string;
  user_id: string;
  subject_id: string | null;
  title: string;
  file_path: string;
  file_type: 'pdf' | 'docx' | 'pptx' | 'image' | 'text';
  extracted_text: string | null;
  processing_status: 'pending' | 'processing' | 'done' | 'failed';
  created_at: string;
}

export interface AIGeneratedContent {
  id: string;
  user_id: string;
  source_note_id: string | null;
  type: 'summary' | 'flashcards' | 'mcq' | 'true_false' | 'fill_blank' | 'short_answer';
  subject_id: string | null;
  content: Record<string, unknown>;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  user_id: string;
  subject_id: string | null;
  note_id: string | null;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}

export interface Quiz {
  id: string;
  user_id: string;
  subject_id: string | null;
  source_note_id: string | null;
  topic: string;
  title: string;
  difficulty: 'easy' | 'medium' | 'hard' | 'mixed';
  question_count: number;
  status: 'generating' | 'ready' | 'failed';
  created_at: string;
}

export interface QuizQuestion {
  id: string;
  quiz_id: string;
  order_index: number;
  question_text: string;
  question_type: 'mcq' | 'true_false' | 'fill_blank' | 'short_answer';
  options: string[] | null;
  correct_answer: string;
  explanation: string | null;
  difficulty: 'easy' | 'medium' | 'hard';
  topic_tag: string | null;
  created_at: string;
}

export interface QuizAttempt {
  id: string;
  user_id: string;
  quiz_id: string;
  status: 'in_progress' | 'completed' | 'abandoned';
  score: number | null;
  correct_count: number;
  total_questions: number;
  time_taken_seconds: number | null;
  started_at: string;
  completed_at: string | null;
}

export interface QuizAnswer {
  id: string;
  attempt_id: string;
  question_id: string;
  user_answer: string | null;
  is_correct: boolean;
  topic_tag: string | null;
  answered_at: string;
}

export interface FlashcardDeck {
  id: string;
  user_id: string;
  subject_id: string | null;
  source_note_id: string | null;
  title: string;
  card_count: number;
  created_at: string;
}

export interface Flashcard {
  id: string;
  deck_id: string;
  order_index: number;
  front: string;
  back: string;
  status: 'learning' | 'known' | 'review_later';
  last_reviewed_at: string | null;
  created_at: string;
}

export interface Assignment {
  id: string;
  user_id: string;
  subject_id: string | null;
  title: string;
  description: string | null;
  due_date: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'completed';
  remind_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Exam {
  id: string;
  user_id: string;
  subject_id: string | null;
  title: string;
  exam_date: string;
  notes: string | null;
  remind_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface StudySession {
  id: string;
  user_id: string;
  subject_id: string | null;
  linked_assignment_id: string | null;
  linked_exam_id: string | null;
  title: string;
  scheduled_date: string;
  duration_minutes: number;
  status: 'planned' | 'completed' | 'missed';
  created_at: string;
}

// Minimal Supabase Database type so the typed client compiles.
// Expand per-table as features are built out.
export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile; Insert: Partial<Profile>; Update: Partial<Profile> };
      class_levels: { Row: ClassLevel; Insert: Partial<ClassLevel>; Update: Partial<ClassLevel> };
      exam_tracks: { Row: ExamTrack; Insert: Partial<ExamTrack>; Update: Partial<ExamTrack> };
      study_materials: { Row: StudyMaterial; Insert: Partial<StudyMaterial>; Update: Partial<StudyMaterial> };
      subjects: { Row: Subject; Insert: Partial<Subject>; Update: Partial<Subject> };
      notes: { Row: Note; Insert: Partial<Note>; Update: Partial<Note> };
      ai_generated_content: {
        Row: AIGeneratedContent;
        Insert: Partial<AIGeneratedContent>;
        Update: Partial<AIGeneratedContent>;
      };
      ai_chat_messages: {
        Row: ChatMessage;
        Insert: Partial<ChatMessage>;
        Update: Partial<ChatMessage>;
      };
      quizzes: { Row: Quiz; Insert: Partial<Quiz>; Update: Partial<Quiz> };
      quiz_questions: { Row: QuizQuestion; Insert: Partial<QuizQuestion>; Update: Partial<QuizQuestion> };
      quiz_attempts: { Row: QuizAttempt; Insert: Partial<QuizAttempt>; Update: Partial<QuizAttempt> };
      quiz_answers: { Row: QuizAnswer; Insert: Partial<QuizAnswer>; Update: Partial<QuizAnswer> };
      flashcard_decks: { Row: FlashcardDeck; Insert: Partial<FlashcardDeck>; Update: Partial<FlashcardDeck> };
      flashcards: { Row: Flashcard; Insert: Partial<Flashcard>; Update: Partial<Flashcard> };
      assignments: { Row: Assignment; Insert: Partial<Assignment>; Update: Partial<Assignment> };
      exams: { Row: Exam; Insert: Partial<Exam>; Update: Partial<Exam> };
      study_sessions: { Row: StudySession; Insert: Partial<StudySession>; Update: Partial<StudySession> };
    };
  };
}
