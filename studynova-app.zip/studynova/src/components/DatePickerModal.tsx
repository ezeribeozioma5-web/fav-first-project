import { useState } from 'react';
import { View, Text, Pressable, Modal } from 'react-native';

interface DatePickerModalProps {
  visible: boolean;
  onClose: () => void;
  value: Date | null;
  onSelect: (date: Date) => void;
  title?: string;
}

const WEEKDAY_LABELS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

function startOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}
function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}
function daysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate();
}

/** A compact month-grid date picker — built with plain Views/Pressables so
 * the project doesn't need a native date-picker dependency (which would
 * need install/version verification this environment can't do). Good
 * enough for assignment/exam/study-session dates, which are day-granularity
 * only in this milestone (no time-of-day) — see README for that scope note. */
export function DatePickerModal({ visible, onClose, value, onSelect, title = 'Pick a date' }: DatePickerModalProps) {
  const [viewedMonth, setViewedMonth] = useState(() => startOfMonth(value ?? new Date()));

  const year = viewedMonth.getFullYear();
  const month = viewedMonth.getMonth();
  const firstWeekday = new Date(year, month, 1).getDay();
  const totalDays = daysInMonth(year, month);
  const today = new Date();

  const cells: (number | null)[] = [
    ...Array(firstWeekday).fill(null),
    ...Array.from({ length: totalDays }, (_, i) => i + 1),
  ];

  const changeMonth = (delta: number) => setViewedMonth(new Date(year, month + delta, 1));

  const monthLabel = viewedMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable className="flex-1 items-center justify-center bg-black/40 px-8" onPress={onClose}>
        <Pressable onPress={(e) => e.stopPropagation()} className="bg-surface dark:bg-surface-dk rounded-card p-5 w-full">
          <Text className="text-ink dark:text-ink-dk font-semibold text-base mb-4">{title}</Text>

          <View className="flex-row items-center justify-between mb-3">
            <Pressable onPress={() => changeMonth(-1)} className="px-3 py-1">
              <Text className="text-accent dark:text-accent-dk text-base">‹</Text>
            </Pressable>
            <Text className="text-ink dark:text-ink-dk font-medium text-sm">{monthLabel}</Text>
            <Pressable onPress={() => changeMonth(1)} className="px-3 py-1">
              <Text className="text-accent dark:text-accent-dk text-base">›</Text>
            </Pressable>
          </View>

          <View className="flex-row mb-1">
            {WEEKDAY_LABELS.map((w, i) => (
              <View key={i} style={{ width: `${100 / 7}%` }} className="items-center py-1">
                <Text className="text-ink-muted dark:text-ink-muted-dk text-[10px] font-medium">{w}</Text>
              </View>
            ))}
          </View>

          <View className="flex-row flex-wrap">
            {cells.map((day, i) => {
              if (day === null) return <View key={i} style={{ width: `${100 / 7}%` }} className="h-10" />;
              const cellDate = new Date(year, month, day);
              const selected = value ? isSameDay(cellDate, value) : false;
              const isToday = isSameDay(cellDate, today);
              return (
                <View key={i} style={{ width: `${100 / 7}%` }} className="h-10 items-center justify-center">
                  <Pressable
                    onPress={() => onSelect(cellDate)}
                    className={`w-8 h-8 rounded-full items-center justify-center ${
                      selected ? 'bg-primary dark:bg-primary-dk' : isToday ? 'border border-primary dark:border-primary-dk' : ''
                    }`}
                  >
                    <Text
                      className={`text-xs ${
                        selected ? 'text-ink dark:text-white font-semibold' : 'text-ink dark:text-ink-dk'
                      }`}
                    >
                      {day}
                    </Text>
                  </Pressable>
                </View>
              );
            })}
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}
