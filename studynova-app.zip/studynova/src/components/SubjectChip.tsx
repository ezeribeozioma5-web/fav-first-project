import { useState } from 'react';
import { View, Text, Pressable, Modal, TextInput, Alert } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useSubjectsStore } from '@/stores/useSubjectsStore';
import type { Subject } from '@/types/database';

interface SubjectChipProps {
  subject: Subject;
  selected?: boolean;
  onPress: () => void;
}

/** A single subject chip. Tap selects/filters; long-press opens
 * Rename/Delete — this is the only place subject management lives in v1
 * (no dedicated "My Subjects" screen), reused by both the filter rows and
 * the SubjectPicker modal so the behavior is consistent everywhere. */
export function SubjectChip({ subject, selected, onPress }: SubjectChipProps) {
  const { renameSubject, deleteSubject } = useSubjectsStore();
  const [renaming, setRenaming] = useState(false);
  const [draftName, setDraftName] = useState(subject.name);
  const [renameError, setRenameError] = useState<string | null>(null);

  const handleLongPress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert(subject.name, undefined, [
      { text: 'Rename', onPress: () => { setDraftName(subject.name); setRenameError(null); setRenaming(true); } },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () =>
          Alert.alert(
            `Delete "${subject.name}"?`,
            'Notes, quizzes, and chats under this subject will stay — they just won\'t be grouped under it anymore.',
            [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Delete', style: 'destructive', onPress: () => deleteSubject(subject.id) },
            ]
          ),
      },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  const saveRename = async () => {
    const trimmed = draftName.trim();
    if (!trimmed || trimmed === subject.name) {
      setRenaming(false);
      return;
    }
    setRenameError(null);
    const ok = await renameSubject(subject.id, trimmed);
    if (ok) {
      setRenaming(false);
    } else {
      setRenameError('That name is already in use — try something else.');
    }
  };

  return (
    <>
      <Pressable
        onPress={onPress}
        onLongPress={handleLongPress}
        className={`flex-row items-center gap-1.5 rounded-pill px-3.5 py-2 border ${
          selected ? 'border-transparent' : 'border-border dark:border-border-dk bg-surface dark:bg-surface-dk'
        }`}
        style={selected ? { backgroundColor: subject.color + '30', borderColor: subject.color } : undefined}
      >
        <Text className="text-sm">{subject.icon}</Text>
        <Text
          className={`text-sm font-medium ${selected ? '' : 'text-ink dark:text-ink-dk'}`}
          style={selected ? { color: subject.color } : undefined}
        >
          {subject.name}
        </Text>
      </Pressable>

      <Modal visible={renaming} transparent animationType="fade" onRequestClose={() => setRenaming(false)}>
        <View className="flex-1 items-center justify-center bg-black/40 px-8">
          <View className="bg-surface dark:bg-surface-dk rounded-card p-5 w-full">
            <Text className="text-ink dark:text-ink-dk font-semibold text-base mb-3">Rename subject</Text>
            <TextInput
              value={draftName}
              onChangeText={setDraftName}
              autoFocus
              placeholderTextColor="#94A3B8"
              className="bg-bg dark:bg-bg-dk text-ink dark:text-ink-dk rounded-card px-4 py-3 border border-border dark:border-border-dk text-base mb-4"
            />
            {renameError && <Text className="text-danger dark:text-danger-dk text-xs mb-3">{renameError}</Text>}
            <View className="flex-row gap-3">
              <Pressable onPress={() => setRenaming(false)} className="flex-1 items-center py-2.5">
                <Text className="text-ink-muted dark:text-ink-muted-dk font-medium">Cancel</Text>
              </Pressable>
              <Pressable onPress={saveRename} className="flex-1 items-center py-2.5 bg-primary dark:bg-primary-dk rounded-pill">
                <Text className="text-ink dark:text-white font-semibold">Save</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}
