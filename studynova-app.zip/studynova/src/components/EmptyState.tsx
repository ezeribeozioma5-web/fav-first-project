import React from 'react';
import { View, Text } from 'react-native';

interface EmptyStateProps {
  emoji: string;
  title: string;
  body: string;
}

/** Consistent empty-state pattern: an emoji mark, a direct title, and one
 * plain-language sentence telling the student what to do next. */
export function EmptyState({ emoji, title, body }: EmptyStateProps) {
  return (
    <View className="items-center px-10 py-10">
      <Text className="text-5xl mb-4">{emoji}</Text>
      <Text className="text-ink dark:text-ink-dk font-semibold text-base mb-1 text-center">{title}</Text>
      <Text className="text-ink-muted dark:text-ink-muted-dk text-sm text-center leading-5">{body}</Text>
    </View>
  );
}
