import React from 'react';
import { View, ViewProps } from 'react-native';

export function Card({ className = '', children, ...rest }: ViewProps & { className?: string }) {
  return (
    <View
      className={`bg-surface dark:bg-surface-dk rounded-card p-4 border border-border/60 dark:border-border-dk shadow-sm shadow-black/5 ${className}`}
      {...rest}
    >
      {children}
    </View>
  );
}
