import React, { useEffect } from 'react';
import { View, ViewProps } from 'react-native';
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, Easing } from 'react-native-reanimated';

/** A single shimmering placeholder block — compose these to build skeleton screens. */
export function Skeleton({ className = '', style, ...rest }: ViewProps & { className?: string }) {
  const opacity = useSharedValue(0.5);

  useEffect(() => {
    opacity.value = withRepeat(withTiming(1, { duration: 700, easing: Easing.inOut(Easing.ease) }), -1, true);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));

  return (
    <Animated.View
      style={[animatedStyle, style]}
      className={`bg-border dark:bg-border-dk rounded-md ${className}`}
      {...rest}
    />
  );
}

/** Preset: a card-shaped skeleton, used while AI content is generating. */
export function SkeletonCard() {
  return (
    <View className="bg-surface dark:bg-surface-dk rounded-card p-4 border border-border/60 dark:border-border-dk">
      <Skeleton className="h-4 w-2/3 mb-3" />
      <Skeleton className="h-3 w-full mb-2" />
      <Skeleton className="h-3 w-5/6" />
    </View>
  );
}
