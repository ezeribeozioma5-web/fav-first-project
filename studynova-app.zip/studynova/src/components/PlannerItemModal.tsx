import { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, Modal, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { Button } from '@/components/Button';
import { SubjectChip } from '@/components/SubjectChip';
import { SubjectPicker } from '@/components/SubjectPicker';
import { DatePickerModal } from '@/components/DatePickerModal';
import { useSubjectsStore } from '@/stores/useSubjectsStore';

export type PlannerItemType = 'assignment' | 'exam' | 'session';

export interface PlannerItemDraft {
  title: string;
  subjectId: string | null;
  date: Date;
  priority?: 'low' | 'medium' | 'high'; // assignment only
  durationMinutes?: number; // session only
  notes?: string; // exam/assignment description
}

interface PlannerItemModalProps {
  visible: boolean;
  type: PlannerItemType;
  onClose: () => void;
  onSave: (draft: PlannerItemDraft) => void;
  saving?: boolean;
}

const TYPE_CONFIG: Record<PlannerItemType, { title: string; dateLabel: string; titlePlaceholder: string }> = {
  assignment: { title: 'New Assignment', dateLabel: 'Due date', titlePlaceholder: 'e.g. Chemistry lab report' },
  exam: { title: 'New Exam', dateLabel: 'Exam date', titlePlaceholder: 'e.g. Mid-semester Physics test' },
  session: { title: 'New Study Session', dateLabel: 'Study date', titlePlaceholder: 'e.g. Revise Organic Chemistry' },
};

const DURATION_OPTIONS = [25, 45, 60, 90];

export function PlannerItemModal({ visible, type, onClose, onSave, saving }: PlannerItemModalProps) {
  const { subjects } = useSubjectsStore();
  const config = TYPE_CONFIG[type];

  const [title, setTitle] = useState('');
  const [subjectId, setSubjectId] = useState<string | null>(null);
  const [subjectPickerVisible, setSubjectPickerVisible] = useState(false);
  const [date, setDate] = useState<Date | null>(null);
  const [datePickerVisible, setDatePickerVisible] = useState(false);
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [duration, setDuration] = useState(45);
  const [notes, setNotes] = useState('');

  // Reset the form each time it opens for a fresh item (not on every
  // keystroke — only when visibility/type flips).
  useEffect(() => {
    if (visible) {
      setTitle('');
      setSubjectId(null);
      setDate(null);
      setPriority('medium');
      setDuration(45);
      setNotes('');
    }
  }, [visible, type]);

  const subject = subjects.find((s) => s.id === subjectId);
  const canSave = title.trim().length > 0 && date !== null;

  const handleSave = () => {
    if (!canSave || !date) return;
    onSave({
      title: title.trim(),
      subjectId,
      date,
      priority: type === 'assignment' ? priority : undefined,
      durationMinutes: type === 'session' ? duration : undefined,
      notes: notes.trim() || undefined,
    });
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable className="flex-1 bg-black/40" onPress={onClose}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1 justify-end">
          <Pressable onPress={(e) => e.stopPropagation()}>
            <ScrollView
              className="bg-surface dark:bg-surface-dk rounded-t-[24px]"
              contentContainerClassName="p-6 pb-8"
              keyboardShouldPersistTaps="handled"
              style={{ maxHeight: '85%' }}
            >
              <View className="w-10 h-1 rounded-pill bg-border dark:bg-border-dk self-center mb-4" />
              <Text className="text-ink dark:text-ink-dk font-bold text-lg mb-4">{config.title}</Text>

              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs font-medium mb-1.5">Title</Text>
              <TextInput
                value={title}
                onChangeText={setTitle}
                placeholder={config.titlePlaceholder}
                placeholderTextColor="#94A3B8"
                className="bg-bg dark:bg-bg-dk text-ink dark:text-ink-dk rounded-card px-4 py-3 border border-border dark:border-border-dk text-base mb-4"
              />

              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs font-medium mb-1.5">{config.dateLabel}</Text>
              <Pressable
                onPress={() => setDatePickerVisible(true)}
                className="bg-bg dark:bg-bg-dk rounded-card px-4 py-3 border border-border dark:border-border-dk mb-4"
              >
                <Text className={date ? 'text-ink dark:text-ink-dk text-base' : 'text-ink-muted dark:text-ink-muted-dk text-base'}>
                  {date ? date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }) : 'Select a date'}
                </Text>
              </Pressable>

              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs font-medium mb-1.5">Subject (optional)</Text>
              <View className="flex-row mb-4">
                {subject ? (
                  <SubjectChip subject={subject} selected onPress={() => setSubjectPickerVisible(true)} />
                ) : (
                  <Pressable
                    onPress={() => setSubjectPickerVisible(true)}
                    className="rounded-pill px-3.5 py-2 border border-dashed border-border dark:border-border-dk"
                  >
                    <Text className="text-ink-muted dark:text-ink-muted-dk text-sm">None — tap to add</Text>
                  </Pressable>
                )}
              </View>

              {type === 'assignment' && (
                <>
                  <Text className="text-ink-muted dark:text-ink-muted-dk text-xs font-medium mb-1.5">Priority</Text>
                  <View className="flex-row gap-2 mb-4">
                    {(['low', 'medium', 'high'] as const).map((p) => (
                      <Pressable
                        key={p}
                        onPress={() => setPriority(p)}
                        className={`flex-1 rounded-pill py-2 items-center border ${
                          priority === p
                            ? 'bg-primary/20 dark:bg-primary-dk/20 border-primary dark:border-primary-dk'
                            : 'border-border dark:border-border-dk'
                        }`}
                      >
                        <Text className="text-ink dark:text-ink-dk text-xs font-medium capitalize">{p}</Text>
                      </Pressable>
                    ))}
                  </View>
                </>
              )}

              {type === 'session' && (
                <>
                  <Text className="text-ink-muted dark:text-ink-muted-dk text-xs font-medium mb-1.5">Duration</Text>
                  <View className="flex-row gap-2 mb-4">
                    {DURATION_OPTIONS.map((mins) => (
                      <Pressable
                        key={mins}
                        onPress={() => setDuration(mins)}
                        className={`flex-1 rounded-pill py-2 items-center border ${
                          duration === mins
                            ? 'bg-primary/20 dark:bg-primary-dk/20 border-primary dark:border-primary-dk'
                            : 'border-border dark:border-border-dk'
                        }`}
                      >
                        <Text className="text-ink dark:text-ink-dk text-xs font-medium">{mins}m</Text>
                      </Pressable>
                    ))}
                  </View>
                </>
              )}

              {(type === 'assignment' || type === 'exam') && (
                <>
                  <Text className="text-ink-muted dark:text-ink-muted-dk text-xs font-medium mb-1.5">
                    Notes (optional)
                  </Text>
                  <TextInput
                    value={notes}
                    onChangeText={setNotes}
                    placeholder={type === 'exam' ? 'Location, topics covered...' : 'Any extra detail...'}
                    placeholderTextColor="#94A3B8"
                    multiline
                    className="bg-bg dark:bg-bg-dk text-ink dark:text-ink-dk rounded-card px-4 py-3 border border-border dark:border-border-dk text-base mb-4 min-h-[70px]"
                  />
                </>
              )}

              <Button label="Save" onPress={handleSave} disabled={!canSave} loading={saving} />
            </ScrollView>
          </Pressable>
        </KeyboardAvoidingView>
      </Pressable>

      <SubjectPicker
        visible={subjectPickerVisible}
        onClose={() => setSubjectPickerVisible(false)}
        onSelect={(id) => { setSubjectId(id); setSubjectPickerVisible(false); }}
        skipLabel="No subject"
        title="Tag with a subject"
      />
      <DatePickerModal
        visible={datePickerVisible}
        onClose={() => setDatePickerVisible(false)}
        value={date}
        onSelect={(d) => { setDate(d); setDatePickerVisible(false); }}
        title={config.dateLabel}
      />
    </Modal>
  );
}
