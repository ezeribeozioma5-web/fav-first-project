import React from 'react';
import { Pressable, Text, ActivityIndicator, PressableProps } from 'react-native';
import * as Haptics from 'expo-haptics';

type Variant = 'primary' | 'secondary' | 'ghost';

interface ButtonProps extends PressableProps {
  label: string;
  variant?: Variant;
  loading?: boolean;
  fullWidth?: boolean;
}

const variantStyles: Record<Variant, { container: string; text: string }> = {
  primary: {
    container: 'bg-primary dark:bg-primary-dk active:opacity-80',
    text: 'text-ink dark:text-white font-semibold',
  },
  secondary: {
    container: 'bg-secondary/40 dark:bg-secondary-dk/20 border border-primary/40 dark:border-primary-dk/40 active:opacity-80',
    text: 'text-ink dark:text-ink-dk',
  },
  ghost: {
    container: 'bg-transparent active:bg-ink/5 dark:active:bg-white/5',
    text: 'text-ink dark:text-ink-dk',
  },
};

export function Button({
  label,
  variant = 'primary',
  loading = false,
  fullWidth = true,
  disabled,
  onPress,
  ...rest
}: ButtonProps) {
  const styles = variantStyles[variant];

  return (
    <Pressable
      disabled={disabled || loading}
      onPress={(e) => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        onPress?.(e);
      }}
      className={`${styles.container} ${fullWidth ? 'w-full' : ''} rounded-card py-4 px-6 items-center justify-center shadow-sm ${
        disabled ? 'opacity-40' : ''
      }`}
      {...rest}
    >
      {loading ? (
        <ActivityIndicator color="#1E293B" />
      ) : (
        <Text className={`${styles.text} text-base`}>{label}</Text>
      )}
    </Pressable>
  );
}
