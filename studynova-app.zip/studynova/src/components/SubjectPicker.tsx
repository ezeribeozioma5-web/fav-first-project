import { useState } from 'react';
import { View, Text, Pressable, Modal, TextInput, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { useAuthStore } from '@/stores/useAuthStore';
import { useSubjectsStore } from '@/stores/useSubjectsStore';
import { SubjectChip } from '@/components/SubjectChip';

interface SubjectPickerProps {
  visible: boolean;
  onClose: () => void;
  onSelect: (subjectId: string | null) => void;
  /** Label for the "no subject" option, e.g. "Uncategorized" or "General chat". Omit to hide it. */
  skipLabel?: string;
  title?: string;
}

export function SubjectPicker({ visible, onClose, onSelect, skipLabel, title = 'Choose a subject' }: SubjectPickerProps) {
  const { session } = useAuthStore();
  const { subjects, createSubject } = useSubjectsStore();
  const [newName, setNewName] = useState('');
  const [creating, setCreating] = useState(false);

  const handleCreate = async () => {
    if (!newName.trim() || !session) return;
    setCreating(true);
    const subject = await createSubject(session.user.id, newName.trim());
    setCreating(false);
    setNewName('');
    if (subject) onSelect(subject.id);
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable className="flex-1 bg-black/40" onPress={onClose}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1 justify-end">
          <Pressable onPress={(e) => e.stopPropagation()}>
            <View className="bg-surface dark:bg-surface-dk rounded-t-[24px] p-6 pb-8">
              <View className="w-10 h-1 rounded-pill bg-border dark:bg-border-dk self-center mb-4" />
              <Text className="text-ink dark:text-ink-dk font-bold text-lg mb-4">{title}</Text>

              {skipLabel && (
                <Pressable
                  onPress={() => onSelect(null)}
                  className="rounded-pill px-3.5 py-2 border border-border dark:border-border-dk self-start mb-3"
                >
                  <Text className="text-ink-muted dark:text-ink-muted-dk text-sm font-medium">{skipLabel}</Text>
                </Pressable>
              )}

              {subjects.length > 0 && (
                <ScrollView contentContainerClassName="flex-row flex-wrap gap-2 mb-4" style={{ maxHeight: 160 }}>
                  {subjects.map((s) => (
                    <SubjectChip key={s.id} subject={s} onPress={() => onSelect(s.id)} />
                  ))}
                </ScrollView>
              )}

              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs font-medium mb-2">New subject</Text>
              <View className="flex-row gap-2">
                <TextInput
                  value={newName}
                  onChangeText={setNewName}
                  placeholder="e.g. Organic Chemistry"
                  placeholderTextColor="#94A3B8"
                  onSubmitEditing={handleCreate}
                  className="flex-1 bg-bg dark:bg-bg-dk text-ink dark:text-ink-dk rounded-card px-4 py-3 border border-border dark:border-border-dk text-base"
                />
                <Pressable
                  onPress={handleCreate}
                  disabled={!newName.trim() || creating}
                  className={`px-5 rounded-card items-center justify-center ${newName.trim() ? 'bg-primary dark:bg-primary-dk' : 'bg-primary/30 dark:bg-primary-dk/30'}`}
                >
                  <Text className="text-ink dark:text-white font-semibold text-sm">Add</Text>
                </Pressable>
              </View>
            </View>
          </Pressable>
        </KeyboardAvoidingView>
      </Pressable>
    </Modal>
  );
}
