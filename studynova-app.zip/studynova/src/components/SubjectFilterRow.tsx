import { View, Text, Pressable, ScrollView } from 'react-native';
import { SubjectChip } from '@/components/SubjectChip';
import type { Subject } from '@/types/database';

// Sentinel values for the two non-subject filter states, distinct from any
// real subject id (which is always a uuid) and from `null` (used elsewhere
// to mean "no subject" in create/select flows) so the three states — "All",
// "Uncategorized", and "no filter active" — stay unambiguous here.
export const FILTER_ALL = 'all' as const;
export const FILTER_UNCATEGORIZED = 'uncategorized' as const;
export type SubjectFilter = string | typeof FILTER_ALL | typeof FILTER_UNCATEGORIZED;

interface SubjectFilterRowProps {
  subjects: Subject[];
  value: SubjectFilter;
  onChange: (value: SubjectFilter) => void;
  onAddPress: () => void;
}

export function SubjectFilterRow({ subjects, value, onChange, onAddPress }: SubjectFilterRowProps) {
  if (subjects.length === 0) {
    // Nothing to filter by yet — a bare "+" would look like a stray button
    // with no context, so this row only appears once at least one subject exists.
    return null;
  }

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerClassName="gap-2 px-6 pb-3">
      <Pressable
        onPress={() => onChange(FILTER_ALL)}
        className={`rounded-pill px-3.5 py-2 border ${
          value === FILTER_ALL
            ? 'bg-primary dark:bg-primary-dk border-transparent'
            : 'border-border dark:border-border-dk bg-surface dark:bg-surface-dk'
        }`}
      >
        <Text className={`text-sm font-medium ${value === FILTER_ALL ? 'text-ink dark:text-white' : 'text-ink dark:text-ink-dk'}`}>
          All
        </Text>
      </Pressable>

      <Pressable
        onPress={() => onChange(FILTER_UNCATEGORIZED)}
        className={`rounded-pill px-3.5 py-2 border ${
          value === FILTER_UNCATEGORIZED
            ? 'bg-primary dark:bg-primary-dk border-transparent'
            : 'border-border dark:border-border-dk bg-surface dark:bg-surface-dk'
        }`}
      >
        <Text className={`text-sm font-medium ${value === FILTER_UNCATEGORIZED ? 'text-ink dark:text-white' : 'text-ink dark:text-ink-dk'}`}>
          Uncategorized
        </Text>
      </Pressable>

      {subjects.map((s) => (
        <SubjectChip key={s.id} subject={s} selected={value === s.id} onPress={() => onChange(s.id)} />
      ))}

      <Pressable
        onPress={onAddPress}
        className="rounded-pill px-3.5 py-2 border border-dashed border-border dark:border-border-dk items-center justify-center"
      >
        <Text className="text-ink-muted dark:text-ink-muted-dk text-sm font-medium">+</Text>
      </Pressable>
    </ScrollView>
  );
}
