import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/database';

// Pull from app config / env — set these in a `.env` file (see .env.example
// and README) and never commit real keys. Using the anon/public key here is
// safe: RLS does the actual access control.
const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

// createClient() runs at module-load time — since this file is imported by
// the auth store, which the root layout imports, a missing/empty URL used
// to throw supabase-js's generic internal error ("supabaseUrl is
// required.") and crash the entire app before the first screen rendered,
// with no indication of what to actually do about it. Fail with a clear,
// actionable message instead (still a hard stop — there's no functional
// fallback without real credentials — but at least a legible one).
if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  throw new Error(
    'StudyNova: missing Supabase configuration.\n\n' +
      'Create a `.env` file in the project root (copy `.env.example`) with:\n' +
      '  EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co\n' +
      '  EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key\n\n' +
      'Then restart with `npx expo start -c` to clear the bundler cache.'
  );
}

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});
