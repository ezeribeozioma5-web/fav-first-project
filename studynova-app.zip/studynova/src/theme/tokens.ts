// Design tokens — single source of truth, mirrored in tailwind.config.js.
// Import these when you need raw values (e.g. inside StyleSheet.create,
// SVG fills, or chart libraries that don't accept Tailwind classes).
//
// StudyNova brand — light values are default; "Dark" values are the
// dark-mode counterpart (the app follows system appearance via NativeWind's
// `dark:` variant, config: darkMode: "media").

export const colors = {
  light: {
    primary: '#7DD3FC',
    secondary: '#BFDBFE',
    accent: '#38BDF8',
    success: '#22C55E',
    warning: '#F59E0B',
    danger: '#EF4444',
    background: '#FFFDF7',
    surface: '#FFFFFF',
    border: '#E5E7EB',
    textPrimary: '#1E293B',
    textSecondary: '#64748B',
  },
  dark: {
    primary: '#38BDF8',
    secondary: '#60A5FA',
    accent: '#7DD3FC',
    success: '#22C55E',
    warning: '#FBBF24',
    danger: '#F87171',
    background: '#0F172A',
    surface: '#1E293B',
    border: '#334155',
    textPrimary: '#F8FAFC',
    textSecondary: '#CBD5E1',
  },
} as const;

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32, xxxl: 48 } as const;

export const radius = { sm: 10, md: 16, lg: 20, pill: 999 } as const;

export const typography = {
  display: { fontSize: 32, lineHeight: 40, fontWeight: '700' as const },
  h1: { fontSize: 24, lineHeight: 32, fontWeight: '700' as const },
  h2: { fontSize: 20, lineHeight: 28, fontWeight: '600' as const },
  body: { fontSize: 16, lineHeight: 24, fontWeight: '400' as const },
  bodySm: { fontSize: 14, lineHeight: 20, fontWeight: '400' as const },
  caption: { fontSize: 12, lineHeight: 16, fontWeight: '500' as const },
};

export const APP_NAME = 'StudyNova';
export const APP_TAGLINE = 'StudyNova — Your Study Companion';

// Free-tier daily AI limits — mirrored server-side in Supabase (source of
// truth is the DB function `check_and_log_ai_usage`; this copy is only for
// optimistic UI).
export const FREE_TIER_LIMITS = {
  tutorMessagesPerDay: 10,
  quizGenerationsPerDay: 3,
};
