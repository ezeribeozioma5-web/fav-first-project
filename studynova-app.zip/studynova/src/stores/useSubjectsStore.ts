import { create } from 'zustand';
import { supabase } from '@/services/supabase';
import type { Subject } from '@/types/database';

// Fixed rotation of color+icon pairs assigned automatically at creation —
// no color/icon picker in v1 per the feature scope. Colors pull from the
// existing brand palette so subject chips never clash with the design system.
const PALETTE: { color: string; icon: string }[] = [
  { color: '#38BDF8', icon: '📘' }, // accent
  { color: '#22C55E', icon: '🧪' }, // success
  { color: '#F59E0B', icon: '📐' }, // warning
  { color: '#7DD3FC', icon: '🔬' }, // primary
  { color: '#60A5FA', icon: '🌍' }, // secondary-dk
  { color: '#EF4444', icon: '📗' }, // danger (used sparingly, still legible as a chip)
  { color: '#A78BFA', icon: '🎨' },
  { color: '#F472B6', icon: '🎵' },
];

interface SubjectsState {
  subjects: Subject[];
  loading: boolean;
  loaded: boolean;
  fetchSubjects: (userId: string) => Promise<void>;
  createSubject: (userId: string, name: string) => Promise<Subject | null>;
  renameSubject: (id: string, name: string) => Promise<boolean>;
  deleteSubject: (id: string) => Promise<boolean>;
}

export const useSubjectsStore = create<SubjectsState>((set, get) => ({
  subjects: [],
  loading: false,
  loaded: false,

  fetchSubjects: async (userId) => {
    set({ loading: true });
    const { data, error } = await supabase
      .from('subjects')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: true });
    if (!error && data) set({ subjects: data as Subject[] });
    set({ loading: false, loaded: true });
  },

  createSubject: async (userId, name) => {
    const trimmed = name.trim();
    if (!trimmed) return null;
    const { subjects } = get();
    // Client-side duplicate check for instant feedback; the DB unique
    // constraint (user_id, name) is the actual source of truth.
    const existing = subjects.find((s) => s.name.toLowerCase() === trimmed.toLowerCase());
    if (existing) return existing;

    const palette = PALETTE[subjects.length % PALETTE.length];
    const { data, error } = await supabase
      .from('subjects')
      .insert({ user_id: userId, name: trimmed, color: palette.color, icon: palette.icon })
      .select()
      .single();
    if (error || !data) return null;
    set({ subjects: [...subjects, data as Subject] });
    return data as Subject;
  },

  renameSubject: async (id, name) => {
    const trimmed = name.trim();
    if (!trimmed) return false;
    const { error } = await supabase.from('subjects').update({ name: trimmed }).eq('id', id);
    if (error) return false;
    set({ subjects: get().subjects.map((s) => (s.id === id ? { ...s, name: trimmed } : s)) });
    return true;
  },

  deleteSubject: async (id) => {
    // FK is `on delete set null` on every referencing table — deleting a
    // subject un-links its notes/quizzes/chats, never deletes them.
    const { error } = await supabase.from('subjects').delete().eq('id', id);
    if (error) return false;
    set({ subjects: get().subjects.filter((s) => s.id !== id) });
    return true;
  },
}));
