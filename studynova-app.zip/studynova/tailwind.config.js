/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx,ts,tsx}", "./src/**/*.{js,jsx,ts,tsx}"],
  presets: [require("nativewind/preset")],
  darkMode: "media", // follows system appearance — no in-app toggle wired yet (see Profile > Appearance, still a stub)
  theme: {
    extend: {
      colors: {
        // StudyNova brand tokens — light values are the default; dark values
        // are reached via the `dark:` variant (e.g. `bg-surface dark:bg-surface-dk`).
        primary: { DEFAULT: "#7DD3FC", dk: "#38BDF8" },      // Light Sky Blue -> Dark mode primary
        secondary: { DEFAULT: "#BFDBFE", dk: "#60A5FA" },     // Soft Blue -> Dark mode secondary
        accent: { DEFAULT: "#38BDF8", dk: "#7DD3FC" },
        success: { DEFAULT: "#22C55E", dk: "#22C55E" },
        warning: { DEFAULT: "#F59E0B", dk: "#FBBF24" },
        danger: { DEFAULT: "#EF4444", dk: "#F87171" },
        bg: { DEFAULT: "#FFFDF7", dk: "#0F172A" },            // Warm Cream -> Deep Navy
        surface: { DEFAULT: "#FFFFFF", dk: "#1E293B" },
        border: { DEFAULT: "#E5E7EB", dk: "#334155" },
        ink: {
          DEFAULT: "#1E293B",        // Text Primary (light)
          muted: "#64748B",          // Text Secondary (light)
          dk: "#F8FAFC",             // Text Primary (dark)
          "muted-dk": "#CBD5E1",     // Text Secondary (dark)
        },
      },
      borderRadius: { card: "20px", pill: "999px" },
    },
  },
  plugins: [],
};
