import { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, ScrollView, Pressable, ActivityIndicator, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { supabase } from '@/services/supabase';
import { useAuthStore } from '@/stores/useAuthStore';
import { useIsOffline } from '@/hooks/useIsOffline';

interface QuizQuestion {
  id: string;
  order_index: number;
  question_text: string;
  question_type: 'mcq' | 'true_false' | 'fill_blank' | 'short_answer';
  options: string[] | null;
  correct_answer: string;
  explanation: string | null;
  topic_tag: string | null;
}

interface QuizRow {
  id: string;
  title: string;
  topic: string;
}

type ScreenState = 'loading' | 'taking' | 'submitting' | 'results' | 'error';

function formatElapsed(seconds: number) {
  const m = Math.floor(seconds / 60).toString().padStart(2, '0');
  const s = (seconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

// KNOWN MVP LIMITATION: fill_blank / short_answer questions are graded with
// a plain case-insensitive trim match against `correct_answer`, not AI
// grading. A correct answer phrased differently than the stored answer
// (synonyms, extra words, different word order) will be marked wrong.
// Acceptable for MVP per product decision; flagged here and in the README.
// Future: send the question + user_answer + correct_answer to Claude for a
// short-answer grading judgment instead of a string compare.
function isAnswerCorrect(question: QuizQuestion, userAnswer: string | undefined): boolean {
  if (!userAnswer) return false;
  return userAnswer.trim().toLowerCase() === question.correct_answer.trim().toLowerCase();
}

export default function QuizTakingScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { session } = useAuthStore();
  const isOffline = useIsOffline();

  const [state, setState] = useState<ScreenState>('loading');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [quiz, setQuiz] = useState<QuizRow | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [attemptId, setAttemptId] = useState<string | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [freeTextDraft, setFreeTextDraft] = useState('');
  const [saveWarning, setSaveWarning] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startedRef = useRef(false); // guards against a duplicate quiz_attempts row if this effect ever re-fires

  // --- Load quiz + questions, start an attempt ---
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!id || !session || startedRef.current) return;

      if (isOffline) {
        setErrorMessage("You're offline — reconnect to load this quiz.");
        setState('error');
        return;
      }
      startedRef.current = true;

      const { data: quizRow, error: quizError } = await supabase
        .from('quizzes')
        .select('id, title, topic')
        .eq('id', id)
        .single();
      const { data: questionRows, error: qError } = await supabase
        .from('quiz_questions')
        .select('*')
        .eq('quiz_id', id)
        .order('order_index', { ascending: true });

      if (cancelled) return;
      if (quizError || qError || !quizRow || !questionRows?.length) {
        setErrorMessage('This quiz could not be loaded.');
        setState('error');
        startedRef.current = false;
        return;
      }

      const { data: attempt, error: attemptError } = await supabase
        .from('quiz_attempts')
        .insert({
          user_id: session.user.id,
          quiz_id: quizRow.id,
          status: 'in_progress',
          total_questions: questionRows.length,
        })
        .select()
        .single();

      if (cancelled) return;
      if (attemptError || !attempt) {
        setErrorMessage('Could not start this quiz attempt.');
        setState('error');
        startedRef.current = false;
        return;
      }

      setQuiz(quizRow);
      setQuestions(questionRows as QuizQuestion[]);
      setAttemptId(attempt.id);
      setState('taking');
    })();
    return () => {
      cancelled = true;
    };
  }, [id, session]);

  // --- Timer ---
  useEffect(() => {
    if (state !== 'taking') return;
    timerRef.current = setInterval(() => setElapsedSeconds((s) => s + 1), 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [state]);

  const currentQuestion = questions[currentIndex];
  const progress = questions.length ? (currentIndex + 1) / questions.length : 0;

  const results = useMemo(() => {
    if (state !== 'results') return null;
    const correctCount = questions.filter((q) => isAnswerCorrect(q, answers[q.id])).length;
    return { correctCount, total: questions.length, score: Math.round((correctCount / questions.length) * 100) };
  }, [state, questions, answers]);

  const selectAnswer = (value: string) => {
    if (!currentQuestion) return;
    Haptics.selectionAsync();
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: value }));
  };

  const goNext = () => {
    if (currentQuestion?.question_type === 'fill_blank' || currentQuestion?.question_type === 'short_answer') {
      if (freeTextDraft.trim()) selectAnswer(freeTextDraft.trim());
    }
    setFreeTextDraft('');
    if (currentIndex < questions.length - 1) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setCurrentIndex((i) => i + 1);
    } else {
      submitQuiz();
    }
  };

  const goPrev = () => {
    if (currentIndex === 0) return;
    setFreeTextDraft('');
    setCurrentIndex((i) => i - 1);
  };

  const submitQuiz = async () => {
    if (!attemptId || !session) return;
    setState('submitting');
    if (timerRef.current) clearInterval(timerRef.current);

    // Capture any in-progress free-text draft for the final question.
    const finalAnswers = { ...answers };
    if (currentQuestion && (currentQuestion.question_type === 'fill_blank' || currentQuestion.question_type === 'short_answer') && freeTextDraft.trim()) {
      finalAnswers[currentQuestion.id] = freeTextDraft.trim();
    }
    setAnswers(finalAnswers);

    const correctCount = questions.filter((q) => isAnswerCorrect(q, finalAnswers[q.id])).length;
    const score = Math.round((correctCount / questions.length) * 100);

    const answerRows = questions.map((q) => ({
      attempt_id: attemptId,
      question_id: q.id,
      user_answer: finalAnswers[q.id] ?? null,
      is_correct: isAnswerCorrect(q, finalAnswers[q.id]),
      topic_tag: q.topic_tag,
    }));

    const [{ error: answersError }, { error: attemptError }] = await Promise.all([
      supabase.from('quiz_answers').insert(answerRows),
      supabase
        .from('quiz_attempts')
        .update({
          status: 'completed',
          score,
          correct_count: correctCount,
          total_questions: questions.length,
          time_taken_seconds: elapsedSeconds,
          completed_at: new Date().toISOString(),
        })
        .eq('id', attemptId),
    ]);

    if (answersError || attemptError) {
      console.error('failed to save quiz results', answersError, attemptError);
      // Still show results locally — the score was computed client-side and
      // is accurate even if persistence had an issue; don't block the
      // student. But silently dropping the save left "quiz history" quietly
      // missing an attempt with zero explanation (bug found in review) — now
      // flagged inline on the results screen instead.
      setSaveWarning(true);
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }

    setState('results');
  };

  if (state === 'loading') {
    return (
      <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk items-center justify-center">
        <ActivityIndicator size="large" color="#38BDF8" />
        <Text className="text-ink-muted dark:text-ink-muted-dk mt-3 text-sm">Loading quiz...</Text>
      </SafeAreaView>
    );
  }

  if (state === 'error') {
    return (
      <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk items-center justify-center px-8">
        <Text className="text-4xl mb-3">😕</Text>
        <Text className="text-ink dark:text-ink-dk font-semibold mb-1">Couldn't load this quiz</Text>
        <Text className="text-ink-muted dark:text-ink-muted-dk text-sm text-center mb-6">{errorMessage}</Text>
        <Button label="Go back" variant="secondary" onPress={() => router.back()} fullWidth={false} />
      </SafeAreaView>
    );
  }

  if (state === 'results' && results) {
    return (
      <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
        <ScrollView contentContainerClassName="px-6 pt-6 pb-10">
          <View className="items-center mb-6">
            <View className="w-28 h-28 rounded-full bg-secondary/40 dark:bg-secondary-dk/20 items-center justify-center mb-4 border-4 border-primary dark:border-primary-dk">
              <Text className="text-3xl font-bold text-ink dark:text-ink-dk">{results.score}%</Text>
            </View>
            <Text className="text-ink dark:text-ink-dk text-lg font-bold">{quiz?.title}</Text>
            <Text className="text-ink-muted dark:text-ink-muted-dk text-sm mt-1">
              {results.correctCount} of {results.total} correct · {formatElapsed(elapsedSeconds)}
            </Text>
          </View>

          {saveWarning && (
            <View className="bg-warning/10 dark:bg-warning-dk/10 rounded-card px-4 py-3 mb-5">
              <Text className="text-warning dark:text-warning-dk text-xs">
                ⚠️ This score couldn't be saved to your quiz history — it may not appear there later, but the
                result below is accurate for this session.
              </Text>
            </View>
          )}

          <Text className="text-ink dark:text-ink-dk font-bold text-base mb-3">Review your answers</Text>
          {questions.map((q, i) => {
            const userAnswer = answers[q.id];
            const correct = isAnswerCorrect(q, userAnswer);
            return (
              <Card key={q.id} className={`mb-3 ${correct ? '' : 'border-danger/40 dark:border-danger-dk/40'}`}>
                <View className="flex-row items-start gap-2 mb-2">
                  <Text className="text-base">{correct ? '✅' : '❌'}</Text>
                  <Text className="flex-1 text-ink dark:text-ink-dk font-medium text-sm">
                    {i + 1}. {q.question_text}
                  </Text>
                </View>
                <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mb-1">
                  Your answer: <Text className={correct ? 'text-success dark:text-success-dk' : 'text-danger dark:text-danger-dk'}>{userAnswer || '(no answer)'}</Text>
                </Text>
                {!correct && (
                  <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mb-1">
                    Correct answer: <Text className="text-success dark:text-success-dk">{q.correct_answer}</Text>
                  </Text>
                )}
                {q.explanation && (
                  <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mt-1.5 italic">{q.explanation}</Text>
                )}
              </Card>
            );
          })}

          <View className="mt-4 gap-3">
            <Button label="Back to Practice" onPress={() => router.replace('/(tabs)/quiz')} />
            <Button label="Done" variant="ghost" onPress={() => router.back()} />
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // --- Taking the quiz ---
  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      <View className="px-6 pt-2 pb-3">
        <View className="flex-row items-center justify-between mb-2">
          <Pressable onPress={() => router.back()}>
            <Text className="text-ink-muted dark:text-ink-muted-dk text-sm">✕ Exit</Text>
          </Pressable>
          <Text className="text-ink-muted dark:text-ink-muted-dk text-sm">⏱ {formatElapsed(elapsedSeconds)}</Text>
        </View>
        <View className="h-2 bg-border dark:bg-border-dk rounded-pill overflow-hidden">
          <View
            className="h-full bg-primary dark:bg-primary-dk rounded-pill"
            style={{ width: `${progress * 100}%` }}
          />
        </View>
        <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mt-1.5">
          Question {currentIndex + 1} of {questions.length}
        </Text>
      </View>

      <ScrollView contentContainerClassName="px-6 pb-6" keyboardShouldPersistTaps="handled">
        {currentQuestion && (
          <Card className="mb-6">
            <Text className="text-ink dark:text-ink-dk text-base font-semibold mb-4">
              {currentQuestion.question_text}
            </Text>

            {currentQuestion.question_type === 'mcq' && currentQuestion.options && (
              <View className="gap-2">
                {currentQuestion.options.map((opt) => {
                  const selected = answers[currentQuestion.id] === opt;
                  return (
                    <Pressable
                      key={opt}
                      onPress={() => selectAnswer(opt)}
                      className={`rounded-card px-4 py-3 border ${
                        selected
                          ? 'bg-primary/20 dark:bg-primary-dk/20 border-primary dark:border-primary-dk'
                          : 'bg-bg dark:bg-bg-dk border-border dark:border-border-dk'
                      }`}
                    >
                      <Text className="text-ink dark:text-ink-dk text-sm">{opt}</Text>
                    </Pressable>
                  );
                })}
              </View>
            )}

            {currentQuestion.question_type === 'true_false' && (
              <View className="flex-row gap-3">
                {['True', 'False'].map((opt) => {
                  const selected = answers[currentQuestion.id] === opt;
                  return (
                    <Pressable
                      key={opt}
                      onPress={() => selectAnswer(opt)}
                      className={`flex-1 rounded-card px-4 py-3 items-center border ${
                        selected
                          ? 'bg-primary/20 dark:bg-primary-dk/20 border-primary dark:border-primary-dk'
                          : 'bg-bg dark:bg-bg-dk border-border dark:border-border-dk'
                      }`}
                    >
                      <Text className="text-ink dark:text-ink-dk text-sm font-medium">{opt}</Text>
                    </Pressable>
                  );
                })}
              </View>
            )}

            {(currentQuestion.question_type === 'fill_blank' || currentQuestion.question_type === 'short_answer') && (
              <TextInput
                value={freeTextDraft || answers[currentQuestion.id] || ''}
                onChangeText={setFreeTextDraft}
                placeholder="Type your answer..."
                placeholderTextColor="#94A3B8"
                className="bg-bg dark:bg-bg-dk text-ink dark:text-ink-dk rounded-card px-4 py-3 border border-border dark:border-border-dk text-base"
              />
            )}
          </Card>
        )}

        <View className="flex-row gap-3">
          {currentIndex > 0 && (
            <Pressable onPress={goPrev} className="flex-1 bg-surface dark:bg-surface-dk border border-border dark:border-border-dk rounded-card py-3.5 items-center">
              <Text className="text-ink dark:text-ink-dk font-semibold text-sm">Previous</Text>
            </Pressable>
          )}
          <Pressable
            onPress={goNext}
            disabled={state === 'submitting'}
            className="flex-1 bg-primary dark:bg-primary-dk rounded-card py-3.5 items-center"
          >
            {state === 'submitting' ? (
              <ActivityIndicator color="#1E293B" />
            ) : (
              <Text className="text-ink dark:text-white font-semibold text-sm">
                {currentIndex === questions.length - 1 ? 'Submit' : 'Next'}
              </Text>
            )}
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
