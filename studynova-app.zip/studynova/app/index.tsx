import { useEffect } from 'react';
import { View, Text } from 'react-native';
import { useRouter } from 'expo-router';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  withRepeat,
  withSequence,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuthStore } from '@/stores/useAuthStore';
import { APP_NAME, APP_TAGLINE } from '@/theme/tokens';

// Branded splash — dark navy field with a glowing "Nova" star behind a
// stylized open-book mark. Deliberately theme-independent (always dark):
// a signature moment like this reads as premium in both light/dark app
// modes, matching the Linear/Gemini-style splash treatments referenced
// in the brand brief, rather than flattening to whichever mode the
// device happens to be in.
const SPLASH_DURATION_MS = 1400;

export default function SplashScreen() {
  const router = useRouter();
  const { session } = useAuthStore();

  const markScale = useSharedValue(0.7);
  const markOpacity = useSharedValue(0);
  const glowScale = useSharedValue(0.8);
  const glowOpacity = useSharedValue(0.35);
  const textOpacity = useSharedValue(0);

  const glowStyle = useAnimatedStyle(() => ({
    transform: [{ scale: glowScale.value }],
    opacity: glowOpacity.value,
  }));
  const markStyle = useAnimatedStyle(() => ({
    transform: [{ scale: markScale.value }],
    opacity: markOpacity.value,
  }));
  const textStyle = useAnimatedStyle(() => ({ opacity: textOpacity.value }));

  useEffect(() => {
    // Mark: pop in with a gentle spring.
    markScale.value = withSpring(1, { damping: 9, stiffness: 100 });
    markOpacity.value = withTiming(1, { duration: 450 });

    // Glow: continuous slow pulse, evokes a shining star ("Nova").
    glowScale.value = withRepeat(
      withSequence(
        withTiming(1.15, { duration: 900, easing: Easing.inOut(Easing.ease) }),
        withTiming(0.9, { duration: 900, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      true
    );
    glowOpacity.value = withRepeat(
      withSequence(
        withTiming(0.6, { duration: 900, easing: Easing.inOut(Easing.ease) }),
        withTiming(0.3, { duration: 900, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      true
    );

    // Wordmark + tagline fade in slightly after the mark.
    textOpacity.value = withTiming(1, { duration: 500, easing: Easing.out(Easing.ease) });

    const timer = setTimeout(async () => {
      const seenOnboarding = await AsyncStorage.getItem('onboarding_seen');
      if (session) {
        router.replace('/(tabs)');
      } else if (seenOnboarding) {
        router.replace('/(auth)/login');
      } else {
        router.replace('/onboarding');
      }
    }, SPLASH_DURATION_MS);

    return () => clearTimeout(timer);
  }, [session]);

  return (
    <LinearGradient colors={['#0F172A', '#1E293B']} className="flex-1 items-center justify-center">
      <View className="items-center justify-center">
        {/* Glow layer behind the mark — the "Nova" shine */}
        <Animated.View
          style={glowStyle}
          className="absolute w-40 h-40 rounded-full bg-primary-dk/40"
        />
        <Animated.View
          style={glowStyle}
          className="absolute w-28 h-28 rounded-full bg-accent-dk/50"
        />

        {/* Logo mark: open book + spark, StudyNova's signature combination */}
        <Animated.View style={markStyle} className="items-center justify-center mb-5">
          <View className="w-20 h-20 rounded-[22px] bg-surface-dk border border-primary-dk/40 items-center justify-center">
            <Text className="text-4xl">📖</Text>
            <Text className="text-lg absolute -top-2 -right-2">✨</Text>
          </View>
        </Animated.View>

        <Animated.View style={textStyle} className="items-center">
          <Text className="text-white text-[28px] font-bold tracking-tight">{APP_NAME}</Text>
          <Text className="text-ink-muted-dk text-sm mt-1.5">{APP_TAGLINE}</Text>
        </Animated.View>
      </View>
    </LinearGradient>
  );
}
