import { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { Card } from '@/components/Card';
import { EmptyState } from '@/components/EmptyState';
import { SkeletonCard } from '@/components/Skeleton';
import { SubjectFilterRow, FILTER_ALL, FILTER_UNCATEGORIZED, type SubjectFilter } from '@/components/SubjectFilterRow';
import { SubjectPicker } from '@/components/SubjectPicker';
import { PlannerItemModal, type PlannerItemDraft, type PlannerItemType } from '@/components/PlannerItemModal';
import { supabase } from '@/services/supabase';
import { useAuthStore } from '@/stores/useAuthStore';
import { useSubjectsStore } from '@/stores/useSubjectsStore';
import type { Assignment, Exam, StudySession } from '@/types/database';

type TypeFilter = 'all' | PlannerItemType;

interface UnifiedItem {
  id: string;
  type: PlannerItemType;
  title: string;
  subjectId: string | null;
  date: Date;
  priority?: 'low' | 'medium' | 'high';
  status?: 'pending' | 'completed' | 'planned' | 'missed';
  durationMinutes?: number;
}

const TYPE_ICON: Record<PlannerItemType, string> = { assignment: '📝', exam: '🧪', session: '⏱️' };
const PRIORITY_COLOR: Record<string, string> = {
  low: 'text-ink-muted dark:text-ink-muted-dk',
  medium: 'text-accent dark:text-accent-dk',
  high: 'text-danger dark:text-danger-dk',
};

function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function relativeDateLabel(date: Date): { label: string; overdue: boolean } {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(date);
  target.setHours(0, 0, 0, 0);
  const diffDays = Math.round((target.getTime() - today.getTime()) / 86400000);

  if (diffDays === 0) return { label: 'Today', overdue: false };
  if (diffDays === 1) return { label: 'Tomorrow', overdue: false };
  if (diffDays === -1) return { label: 'Yesterday', overdue: true };
  if (diffDays < 0) return { label: `${Math.abs(diffDays)} days ago`, overdue: true };
  if (diffDays <= 6) return { label: `In ${diffDays} days`, overdue: false };
  return { label: target.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), overdue: false };
}

export default function StudyPlanner() {
  const { session } = useAuthStore();
  const { subjects, fetchSubjects } = useSubjectsStore();

  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all');
  const [subjectFilter, setSubjectFilter] = useState<SubjectFilter>(FILTER_ALL);
  const [modalType, setModalType] = useState<PlannerItemType | null>(null);
  const [saving, setSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [addSubjectOnly, setAddSubjectOnly] = useState(false);

  const fetchAll = useCallback(async () => {
    if (!session) return;
    const uid = session.user.id;
    const [a, e, s] = await Promise.all([
      supabase.from('assignments').select('*').eq('user_id', uid).order('due_date', { ascending: true }),
      supabase.from('exams').select('*').eq('user_id', uid).order('exam_date', { ascending: true }),
      supabase.from('study_sessions').select('*').eq('user_id', uid).order('scheduled_date', { ascending: true }),
    ]);
    if (a.data) setAssignments(a.data as Assignment[]);
    if (e.data) setExams(e.data as Exam[]);
    if (s.data) setSessions(s.data as StudySession[]);
  }, [session]);

  useEffect(() => {
    if (!session) return;
    Promise.all([fetchAll(), fetchSubjects(session.user.id)]).finally(() => setLoading(false));
  }, [session, fetchAll, fetchSubjects]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([fetchAll(), session ? fetchSubjects(session.user.id) : Promise.resolve()]);
    setRefreshing(false);
  };

  const unifiedItems: UnifiedItem[] = useMemo(() => {
    const fromAssignments: UnifiedItem[] = assignments.map((a) => ({
      id: a.id,
      type: 'assignment',
      title: a.title,
      subjectId: a.subject_id,
      date: new Date(a.due_date),
      priority: a.priority,
      status: a.status,
    }));
    const fromExams: UnifiedItem[] = exams.map((e) => ({
      id: e.id,
      type: 'exam',
      title: e.title,
      subjectId: e.subject_id,
      date: new Date(e.exam_date),
    }));
    const fromSessions: UnifiedItem[] = sessions.map((s) => ({
      id: s.id,
      type: 'session',
      title: s.title,
      subjectId: s.subject_id,
      date: new Date(s.scheduled_date),
      status: s.status,
      durationMinutes: s.duration_minutes,
    }));
    return [...fromAssignments, ...fromExams, ...fromSessions].sort((x, y) => x.date.getTime() - y.date.getTime());
  }, [assignments, exams, sessions]);

  const filteredItems = useMemo(() => {
    return unifiedItems.filter((item) => {
      if (typeFilter !== 'all' && item.type !== typeFilter) return false;
      if (subjectFilter === FILTER_UNCATEGORIZED && item.subjectId) return false;
      if (subjectFilter !== FILTER_ALL && subjectFilter !== FILTER_UNCATEGORIZED && item.subjectId !== subjectFilter) return false;
      return true;
    });
  }, [unifiedItems, typeFilter, subjectFilter]);

  const subjectById = useMemo(() => new Map(subjects.map((s) => [s.id, s])), [subjects]);

  // --- Create ---
  const handleSave = async (draft: PlannerItemDraft) => {
    if (!session || !modalType) return;
    setSaving(true);
    setErrorMessage(null);
    try {
      // Day-granularity only in this milestone (no time-of-day picker) — see
      // README. Using local noon before ISO conversion avoids the date
      // shifting a day in either direction across most UTC offsets.
      const dateAtNoon = new Date(draft.date);
      dateAtNoon.setHours(12, 0, 0, 0);
      const isoDate = dateAtNoon.toISOString();

      if (modalType === 'assignment') {
        const { error } = await supabase.from('assignments').insert({
          user_id: session.user.id,
          subject_id: draft.subjectId,
          title: draft.title,
          description: draft.notes ?? null,
          due_date: isoDate,
          priority: draft.priority ?? 'medium',
        } as any);
        if (error) throw error;
      } else if (modalType === 'exam') {
        const { error } = await supabase.from('exams').insert({
          user_id: session.user.id,
          subject_id: draft.subjectId,
          title: draft.title,
          notes: draft.notes ?? null,
          exam_date: isoDate,
        } as any);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('study_sessions').insert({
          user_id: session.user.id,
          subject_id: draft.subjectId,
          title: draft.title,
          scheduled_date: draft.date.toISOString().slice(0, 10), // date column, not timestamptz
          duration_minutes: draft.durationMinutes ?? 45,
        } as any);
        if (error) throw error;
      }
      setModalType(null);
      await fetchAll();
    } catch (e: any) {
      setErrorMessage(e?.message ?? 'Could not save. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  // --- Toggle completion (assignments + sessions only) ---
  const toggleComplete = async (item: UnifiedItem) => {
    if (item.type === 'exam') return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const table = item.type === 'assignment' ? 'assignments' : 'study_sessions';
    const nextStatus = item.status === 'completed' ? (item.type === 'assignment' ? 'pending' : 'planned') : 'completed';

    if (item.type === 'assignment') {
      setAssignments((prev) => prev.map((a) => (a.id === item.id ? { ...a, status: nextStatus as any } : a)));
    } else {
      setSessions((prev) => prev.map((s) => (s.id === item.id ? { ...s, status: nextStatus as any } : s)));
    }
    const { error } = await supabase.from(table).update({ status: nextStatus }).eq('id', item.id);
    if (error) fetchAll(); // reconcile on failure rather than leave an optimistic lie on screen
  };

  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      <View className="px-6 pt-2 pb-3">
        <Text className="text-2xl font-bold text-ink dark:text-ink-dk">Planner</Text>
        <Text className="text-ink-muted dark:text-ink-muted-dk text-sm mt-1">
          Assignments, exams, and study sessions in one place.
        </Text>
      </View>

      <View className="flex-row gap-2 px-6 mb-3">
        <Pressable
          onPress={() => setModalType('assignment')}
          className="flex-1 bg-primary dark:bg-primary-dk rounded-pill py-2.5 items-center"
        >
          <Text className="text-ink dark:text-white text-xs font-semibold">📝 Assignment</Text>
        </Pressable>
        <Pressable
          onPress={() => setModalType('exam')}
          className="flex-1 bg-accent dark:bg-accent-dk rounded-pill py-2.5 items-center"
        >
          <Text className="text-ink dark:text-white text-xs font-semibold">🧪 Exam</Text>
        </Pressable>
        <Pressable
          onPress={() => setModalType('session')}
          className="flex-1 bg-secondary/50 dark:bg-secondary-dk/30 border border-primary/40 dark:border-primary-dk/40 rounded-pill py-2.5 items-center"
        >
          <Text className="text-ink dark:text-ink-dk text-xs font-semibold">⏱️ Session</Text>
        </Pressable>
      </View>

      <View className="flex-row gap-2 px-6 mb-3">
        {(['all', 'assignment', 'exam', 'session'] as TypeFilter[]).map((f) => (
          <Pressable
            key={f}
            onPress={() => setTypeFilter(f)}
            className={`px-3 py-1.5 rounded-pill border ${
              typeFilter === f
                ? 'bg-primary dark:bg-primary-dk border-transparent'
                : 'border-border dark:border-border-dk'
            }`}
          >
            <Text
              className={`text-xs font-medium capitalize ${
                typeFilter === f ? 'text-ink dark:text-white' : 'text-ink-muted dark:text-ink-muted-dk'
              }`}
            >
              {f === 'all' ? 'All' : `${f}s`}
            </Text>
          </Pressable>
        ))}
      </View>

      <SubjectFilterRow subjects={subjects} value={subjectFilter} onChange={setSubjectFilter} onAddPress={() => setAddSubjectOnly(true)} />

      {errorMessage && (
        <View className="mx-6 mt-1 mb-2 bg-danger/10 dark:bg-danger-dk/10 rounded-card px-4 py-2.5">
          <Text className="text-danger dark:text-danger-dk text-xs">{errorMessage}</Text>
        </View>
      )}

      {loading ? (
        <View className="px-6 mt-2 gap-3">
          <SkeletonCard />
          <SkeletonCard />
        </View>
      ) : filteredItems.length === 0 ? (
        <EmptyState
          emoji="🗓️"
          title="Nothing on the planner yet"
          body="Add an assignment, exam, or study session above to start building your schedule."
        />
      ) : (
        <ScrollView
          contentContainerClassName="px-6 gap-3 pb-6 mt-1"
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#38BDF8" />}
        >
          {filteredItems.map((item) => {
            const { label, overdue } = relativeDateLabel(item.date);
            const subject = item.subjectId ? subjectById.get(item.subjectId) : undefined;
            const isDone = item.status === 'completed';
            const canToggle = item.type !== 'exam';

            return (
              <Card key={`${item.type}-${item.id}`} className={isDone ? 'opacity-60' : ''}>
                <View className="flex-row items-center">
                  {canToggle && (
                    <Pressable
                      onPress={() => toggleComplete(item)}
                      className={`w-6 h-6 rounded-full border-2 items-center justify-center mr-3 ${
                        isDone ? 'bg-success dark:bg-success-dk border-success dark:border-success-dk' : 'border-border dark:border-border-dk'
                      }`}
                    >
                      {isDone && <Text className="text-white text-[10px]">✓</Text>}
                    </Pressable>
                  )}
                  <Text className="text-lg mr-2">{TYPE_ICON[item.type]}</Text>
                  <View className="flex-1">
                    <Text
                      className={`text-ink dark:text-ink-dk font-semibold text-sm ${isDone ? 'line-through' : ''}`}
                      numberOfLines={1}
                    >
                      {item.title}
                    </Text>
                    <View className="flex-row items-center gap-2 mt-0.5">
                      <Text className={`text-xs ${overdue ? 'text-warning dark:text-warning-dk' : 'text-ink-muted dark:text-ink-muted-dk'}`}>
                        {overdue ? `${label} — still time to catch up` : label}
                      </Text>
                      {item.priority && (
                        <Text className={`text-[10px] font-semibold uppercase ${PRIORITY_COLOR[item.priority]}`}>
                          {item.priority}
                        </Text>
                      )}
                      {item.durationMinutes && (
                        <Text className="text-ink-muted dark:text-ink-muted-dk text-xs">{item.durationMinutes}m</Text>
                      )}
                      {subject && (
                        <View className="flex-row items-center gap-0.5">
                          <Text className="text-[10px]">{subject.icon}</Text>
                          <Text className="text-[10px] font-medium" style={{ color: subject.color }}>
                            {subject.name}
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>
                </View>
              </Card>
            );
          })}
        </ScrollView>
      )}

      {modalType && (
        <PlannerItemModal
          visible={!!modalType}
          type={modalType}
          onClose={() => setModalType(null)}
          onSave={handleSave}
          saving={saving}
        />
      )}

      <SubjectPicker
        visible={addSubjectOnly}
        onClose={() => setAddSubjectOnly(false)}
        onSelect={(subjectId) => {
          setAddSubjectOnly(false);
          if (subjectId) setSubjectFilter(subjectId);
        }}
        title="New subject"
      />
    </SafeAreaView>
  );
}
