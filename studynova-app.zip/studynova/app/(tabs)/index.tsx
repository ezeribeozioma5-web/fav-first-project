import { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Card } from '@/components/Card';
import { StreakBadge } from '@/components/StreakBadge';
import { Skeleton } from '@/components/Skeleton';
import { useAuthStore } from '@/stores/useAuthStore';
import { supabase } from '@/services/supabase';

const QUICK_ACTIONS = [
  { id: 'upload', emoji: '📤', label: 'Upload notes', route: '/(tabs)/notes', tone: 'primary' },
  { id: 'tutor', emoji: '🤖', label: 'Ask AI Tutor', route: '/(tabs)/tutor', tone: 'accent' },
  { id: 'quiz', emoji: '🎯', label: 'Practice quiz', route: '/(tabs)/quiz', tone: 'warning' },
] as const;

const TONE_CLASS: Record<string, string> = {
  primary: 'bg-primary dark:bg-primary-dk',
  accent: 'bg-accent dark:bg-accent-dk',
  warning: 'bg-warning dark:bg-warning-dk',
};

interface WeekStats {
  quizzesDone: number;
  hoursStudied: number;
  avgScore: number | null;
}

export default function Dashboard() {
  const { profile, session, loadProfile } = useAuthStore();
  const router = useRouter();
  const [statsLoading, setStatsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState<WeekStats>({ quizzesDone: 0, hoursStudied: 0, avgScore: null });

  // Real "this week" numbers from quiz_attempts — this used to be
  // permanently hardcoded to 0/0h/— (bug found in review: once Priority 2
  // shipped real quiz-taking, the dashboard silently kept showing zero
  // activity even after completing quizzes). "Hours studied" is a proxy —
  // time spent actively taking quizzes — not full study time, since there's
  // no broader session-tracking yet; documented in the README.
  const fetchWeekStats = useCallback(async () => {
    if (!session) return;
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    const { data, error } = await supabase
      .from('quiz_attempts')
      .select('score, time_taken_seconds')
      .eq('user_id', session.user.id)
      .eq('status', 'completed')
      .gte('completed_at', sevenDaysAgo);

    if (error || !data) return;
    const quizzesDone = data.length;
    const totalSeconds = data.reduce((sum, a) => sum + (a.time_taken_seconds ?? 0), 0);
    const scores = data.map((a) => a.score).filter((s): s is number => s != null);
    const avgScore = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;

    setStats({ quizzesDone, hoursStudied: Math.round((totalSeconds / 3600) * 10) / 10, avgScore });
  }, [session]);

  const [todayCount, setTodayCount] = useState(0);

  // Powers the "Today's focus" card below — this CTA existed before the
  // Planner did and had nowhere to go; now it does, and shows something
  // real instead of a permanent placeholder.
  const fetchTodayCount = useCallback(async () => {
    if (!session) return;
    const uid = session.user.id;
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    const [a, e, s] = await Promise.all([
      supabase
        .from('assignments')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', uid)
        .eq('status', 'pending')
        .gte('due_date', startOfDay.toISOString())
        .lte('due_date', endOfDay.toISOString()),
      supabase
        .from('exams')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', uid)
        .gte('exam_date', startOfDay.toISOString())
        .lte('exam_date', endOfDay.toISOString()),
      supabase
        .from('study_sessions')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', uid)
        .eq('status', 'planned')
        .eq('scheduled_date', startOfDay.toISOString().slice(0, 10)),
    ]);
    setTodayCount((a.count ?? 0) + (e.count ?? 0) + (s.count ?? 0));
  }, [session]);

  useEffect(() => {
    fetchWeekStats().finally(() => setStatsLoading(false));
    fetchTodayCount();
  }, [fetchWeekStats, fetchTodayCount]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    setStatsLoading(true);
    await Promise.all([loadProfile(), fetchWeekStats(), fetchTodayCount()]);
    setStatsLoading(false);
    setRefreshing(false);
  }, [loadProfile, fetchWeekStats, fetchTodayCount]);

  const firstName = profile?.full_name?.split(' ')[0] ?? 'there';

  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      <ScrollView
        contentContainerClassName="px-6 pb-8"
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#38BDF8" />
        }
      >
        {/* Header */}
        <View className="flex-row items-center justify-between mt-2 mb-6">
          <View>
            <Text className="text-ink-muted dark:text-ink-muted-dk text-sm">Welcome back,</Text>
            <Text className="text-2xl font-bold text-ink dark:text-ink-dk">{firstName} 👋</Text>
          </View>
          <StreakBadge count={profile?.streak_count ?? 0} />
        </View>

        {/* Today's focus — was a dead-end placeholder before Planner existed */}
        <Card className="mb-6 bg-primary dark:bg-primary-dk border-0">
          <Text className="text-ink/70 dark:text-white/70 text-sm mb-1">Today's focus</Text>
          <Text className="text-ink dark:text-white text-lg font-semibold mb-3">
            {todayCount > 0
              ? `${todayCount} thing${todayCount === 1 ? '' : 's'} on your plate today — you've got this.`
              : 'Nothing due today — a good day to get ahead.'}
          </Text>
          <Pressable
            onPress={() => router.push('/(tabs)/planner')}
            className="self-start bg-white/40 dark:bg-white/15 rounded-pill px-4 py-2"
          >
            <Text className="text-ink dark:text-white font-semibold text-sm">
              {todayCount > 0 ? 'Open planner →' : 'Plan your day →'}
            </Text>
          </Pressable>
        </Card>

        {/* Quick actions */}
        <Text className="text-lg font-bold text-ink dark:text-ink-dk mb-3">Quick actions</Text>
        <View className="flex-row gap-3 mb-6">
          {QUICK_ACTIONS.map((action) => (
            <Pressable
              key={action.id}
              onPress={() => router.push(action.route as any)}
              className="flex-1 bg-surface dark:bg-surface-dk rounded-card p-4 items-center border border-border/60 dark:border-border-dk active:opacity-80"
            >
              <View className={`${TONE_CLASS[action.tone]} w-11 h-11 rounded-full items-center justify-center mb-2`}>
                <Text className="text-lg">{action.emoji}</Text>
              </View>
              <Text className="text-ink dark:text-ink-dk text-xs font-semibold text-center">{action.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* Progress snapshot */}
        <Text className="text-lg font-bold text-ink dark:text-ink-dk mb-3">This week</Text>
        {statsLoading ? (
          <View className="flex-row gap-3">
            {[0, 1, 2].map((i) => (
              <View key={i} className="flex-1 bg-surface dark:bg-surface-dk rounded-card items-center py-5 border border-border/60 dark:border-border-dk">
                <Skeleton className="h-6 w-10 mb-2" />
                <Skeleton className="h-3 w-16" />
              </View>
            ))}
          </View>
        ) : (
          <View className="flex-row gap-3">
            <Card className="flex-1 items-center py-5">
              <Text className="text-2xl font-bold text-accent dark:text-accent-dk">{stats.quizzesDone}</Text>
              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mt-1">Quizzes done</Text>
            </Card>
            <Card className="flex-1 items-center py-5">
              <Text className="text-2xl font-bold text-success dark:text-success-dk">{stats.hoursStudied}h</Text>
              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mt-1">Hours studied</Text>
            </Card>
            <Card className="flex-1 items-center py-5">
              <Text className="text-2xl font-bold text-warning dark:text-warning-dk">
                {stats.avgScore != null ? `${stats.avgScore}%` : '—'}
              </Text>
              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mt-1">Avg score</Text>
            </Card>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}
