import { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, FlatList, Pressable, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import Animated, { useSharedValue, useAnimatedStyle, withDelay, withRepeat, withSequence, withTiming } from 'react-native-reanimated';
import { useAuthStore } from '@/stores/useAuthStore';
import { useSubjectsStore } from '@/stores/useSubjectsStore';
import { SubjectPicker } from '@/components/SubjectPicker';
import { FREE_TIER_LIMITS } from '@/theme/tokens';
import { supabase } from '@/services/supabase';
import { useIsOffline } from '@/hooks/useIsOffline';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

function defaultWelcome(noteId?: string, noteTitle?: string, subjectName?: string): Message {
  let content: string;
  if (noteId) {
    content = `I've got "${noteTitle}" open — ask me anything about it: to explain a section, quiz you on it, or break down a tricky part.`;
  } else if (subjectName) {
    content = `Now chatting about ${subjectName} 👋 Ask me anything — this conversation will stay grouped under this subject.`;
  } else {
    content = "Hi! I'm your AI tutor 👋 Ask me to explain a topic, walk through a problem, or quiz you on something you've studied.";
  }
  return { id: `welcome-${noteId ?? subjectName ?? 'general'}`, role: 'assistant', content };
}

export default function TutorChat() {
  const { profile, session } = useAuthStore();
  const { subjects, fetchSubjects } = useSubjectsStore();
  const isPremium = profile?.plan === 'premium';
  const isOffline = useIsOffline();
  const router = useRouter();

  // "Ask AI About This Note" arrives here via router params from notes.tsx.
  const { note_id, note_title } = useLocalSearchParams<{ note_id?: string; note_title?: string }>();
  const [subjectId, setSubjectId] = useState<string | null>(null);
  const [subjectPickerVisible, setSubjectPickerVisible] = useState(false);
  const subject = subjects.find((s) => s.id === subjectId);

  useEffect(() => {
    if (session) fetchSubjects(session.user.id);
  }, [session, fetchSubjects]);

  const [messages, setMessages] = useState<Message[]>([defaultWelcome(note_id, note_title)]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [usedToday, setUsedToday] = useState(0); // TODO: hydrate from ai_usage_log via Edge Function
  const [serverLimitReached, setServerLimitReached] = useState(false);
  const listRef = useRef<FlatList>(null);
  const lastNoteIdRef = useRef(note_id);
  const lastSubjectIdRef = useRef(subjectId);

  // Tabs stay mounted, so navigating here a second time (a different note,
  // a different subject, or clearing back to general chat) doesn't remount
  // the screen — the useState initializer above only runs once. This effect
  // catches those later transitions. (Bug found in review: re-testing the
  // note → tutor leg of the journey a second time in the same session left
  // the old note's welcome message and thread showing.)
  useEffect(() => {
    if (note_id !== lastNoteIdRef.current) {
      lastNoteIdRef.current = note_id;
      setMessages([defaultWelcome(note_id, note_title)]);
    }
  }, [note_id, note_title]);

  useEffect(() => {
    if (note_id) return; // note context always takes priority over subject context
    if (subjectId !== lastSubjectIdRef.current) {
      lastSubjectIdRef.current = subjectId;
      setMessages([defaultWelcome(undefined, undefined, subject?.name)]);
    }
  }, [subjectId, note_id, subject?.name]);

  const remaining = FREE_TIER_LIMITS.tutorMessagesPerDay - usedToday;
  const limitReached = (!isPremium && remaining <= 0) || serverLimitReached;

  const send = async () => {
    if (!input.trim() || limitReached || sending) return;

    if (isOffline) {
      setMessages((prev) => [
        ...prev,
        { id: `${Date.now()}-offline`, role: 'assistant', content: "You're offline — reconnect to talk to your AI tutor." },
      ]);
      return;
    }

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: input.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setSending(true);

    try {
      const { data, error } = await supabase.functions.invoke('ai-tutor-chat', {
        body: {
          message: userMsg.content,
          note_id: note_id ?? undefined,
          // Subject only matters for general (non-note) chats — note context
          // already threads on note_id server-side and takes priority.
          subject_id: !note_id && subjectId ? subjectId : undefined,
        },
      });

      if (error) {
        const ctx = (error as any)?.context;
        if (ctx?.error === 'daily_limit_reached') {
          setServerLimitReached(true);
        }
        throw new Error(ctx?.message ?? 'Something went wrong. Please try again.');
      }

      setMessages((prev) => [...prev, { id: `${Date.now()}-ai`, role: 'assistant', content: data.reply }]);
      setUsedToday((n) => n + 1);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `${Date.now()}-err`,
          role: 'assistant',
          content: e?.message ?? "Sorry, I couldn't respond just now — please try again.",
        },
      ]);
    } finally {
      setSending(false);
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    }
  };

  const clearNoteContext = () => router.replace('/(tabs)/tutor');

  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      {/* Header with usage indicator + subject switcher (hidden while in note context) */}
      <View className="flex-row items-center justify-between px-6 py-3 border-b border-border dark:border-border-dk">
        <View className="flex-row items-center gap-2 flex-1">
          <Text className="text-xl font-bold text-ink dark:text-ink-dk">AI Tutor</Text>
          {!note_id && subjects.length > 0 && (
            <Pressable
              onPress={() => setSubjectPickerVisible(true)}
              className="rounded-pill px-2.5 py-1 border border-border dark:border-border-dk flex-row items-center gap-1"
            >
              <Text className="text-xs">{subject ? subject.icon : '💬'}</Text>
              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs font-medium">
                {subject ? subject.name : 'General'}
              </Text>
            </Pressable>
          )}
        </View>
        {!isPremium && (
          <View className="bg-secondary/50 dark:bg-secondary-dk/20 rounded-pill px-3 py-1">
            <Text className="text-accent dark:text-accent-dk text-xs font-semibold">
              {Math.max(remaining, 0)}/{FREE_TIER_LIMITS.tutorMessagesPerDay} today
            </Text>
          </View>
        )}
      </View>

      {/* Note-context chip */}
      {note_id && (
        <View className="flex-row items-center justify-between px-6 py-2 bg-secondary/25 dark:bg-secondary-dk/10">
          <Text className="text-accent dark:text-accent-dk text-xs font-medium flex-1" numberOfLines={1}>
            📄 Discussing: {note_title}
          </Text>
          <Pressable onPress={clearNoteContext}>
            <Text className="text-ink-muted dark:text-ink-muted-dk text-xs ml-2">Clear</Text>
          </Pressable>
        </View>
      )}

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1" keyboardVerticalOffset={90}>
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(m) => m.id}
          contentContainerClassName="px-4 py-4 gap-3"
          renderItem={({ item }) => (
            <View className={`max-w-[85%] ${item.role === 'user' ? 'self-end' : 'self-start'}`}>
              <View
                className={`rounded-card px-4 py-3 ${
                  item.role === 'user'
                    ? 'bg-primary dark:bg-primary-dk rounded-br-sm'
                    : 'bg-surface dark:bg-surface-dk border border-border/60 dark:border-border-dk rounded-bl-sm'
                }`}
              >
                <Text className={item.role === 'user' ? 'text-ink dark:text-white' : 'text-ink dark:text-ink-dk'}>
                  {item.content}
                </Text>
              </View>
            </View>
          )}
          ListFooterComponent={
            sending ? (
              <View className="self-start bg-surface dark:bg-surface-dk border border-border/60 dark:border-border-dk rounded-card rounded-bl-sm px-4 py-3 flex-row gap-1">
                <TypingDot delay={0} />
                <TypingDot delay={150} />
                <TypingDot delay={300} />
              </View>
            ) : null
          }
        />

        {limitReached ? (
          <View className="mx-4 mb-4 bg-warning/10 dark:bg-warning-dk/10 rounded-card p-4">
            <Text className="text-ink dark:text-ink-dk font-semibold mb-1">Daily limit reached</Text>
            <Text className="text-ink-muted dark:text-ink-muted-dk text-sm mb-3">
              You've used all {FREE_TIER_LIMITS.tutorMessagesPerDay} free messages today. Resets in 24h, or go
              Premium for unlimited tutoring.
            </Text>
            <Pressable className="bg-primary dark:bg-primary-dk rounded-pill py-2.5 items-center">
              <Text className="text-ink dark:text-white font-semibold text-sm">Upgrade to Premium</Text>
            </Pressable>
          </View>
        ) : (
          <View className="flex-row items-end gap-2 px-4 py-3 border-t border-border dark:border-border-dk bg-bg dark:bg-bg-dk">
            <TextInput
              value={input}
              onChangeText={setInput}
              placeholder={note_id ? 'Ask about this note...' : "Ask about anything you're studying..."}
              placeholderTextColor="#94A3B8"
              multiline
              className="flex-1 bg-surface dark:bg-surface-dk text-ink dark:text-ink-dk rounded-card px-4 py-3 border border-border dark:border-border-dk max-h-28 text-base"
            />
            <Pressable
              onPress={send}
              disabled={!input.trim() || sending}
              className={`w-11 h-11 rounded-full items-center justify-center ${
                input.trim() ? 'bg-primary dark:bg-primary-dk' : 'bg-primary/30 dark:bg-primary-dk/30'
              }`}
            >
              <Text className="text-ink dark:text-white text-lg">↑</Text>
            </Pressable>
          </View>
        )}
      </KeyboardAvoidingView>

      <SubjectPicker
        visible={subjectPickerVisible}
        onClose={() => setSubjectPickerVisible(false)}
        onSelect={(id) => { setSubjectId(id); setSubjectPickerVisible(false); }}
        skipLabel="General chat"
        title="Switch subject"
      />
    </SafeAreaView>
  );
}

// Small bouncing-dot typing indicator, staggered via delay.
function TypingDot({ delay }: { delay: number }) {
  const y = useSharedValue(0);
  useEffect(() => {
    y.value = withDelay(
      delay,
      withRepeat(withSequence(withTiming(-4, { duration: 300 }), withTiming(0, { duration: 300 })), -1, true)
    );
  }, []);
  const style = useAnimatedStyle(() => ({ transform: [{ translateY: y.value }] }));
  return <Animated.View style={style} className="w-2 h-2 rounded-full bg-ink-muted dark:bg-ink-muted-dk" />;
}
