import { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Pressable, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import * as DocumentPicker from 'expo-document-picker';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { EmptyState } from '@/components/EmptyState';
import { SkeletonCard } from '@/components/Skeleton';
import { SubjectPicker } from '@/components/SubjectPicker';
import { SubjectFilterRow, FILTER_ALL, FILTER_UNCATEGORIZED, type SubjectFilter } from '@/components/SubjectFilterRow';
import { supabase } from '@/services/supabase';
import { useAuthStore } from '@/stores/useAuthStore';
import { useSubjectsStore } from '@/stores/useSubjectsStore';
import { useIsOffline } from '@/hooks/useIsOffline';
import type { Note } from '@/types/database';

interface SummaryContent {
  key_points: string[];
  sections: { heading: string; body: string }[];
  exam_tips: string[];
}

type SummaryState = { status: 'idle' | 'loading' | 'ready' | 'error'; data?: SummaryContent; error?: string };
type PendingFile = { uri: string; name: string; fileType: Note['file_type'] };

const FILE_ICON: Record<string, string> = { pdf: '📕', docx: '📘', pptx: '📙', image: '🖼️', text: '📄' };

export default function NotesUpload() {
  const { session } = useAuthStore();
  const { subjects, fetchSubjects } = useSubjectsStore();
  const router = useRouter();
  const isOffline = useIsOffline();

  const [notes, setNotes] = useState<Note[]>([]);
  const [loadingNotes, setLoadingNotes] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [picking, setPicking] = useState(false);
  const [summaries, setSummaries] = useState<Record<string, SummaryState>>({});
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [quizGenerating, setQuizGenerating] = useState<string | null>(null);
  const [flashcardsGenerating, setFlashcardsGenerating] = useState<string | null>(null);
  const [filter, setFilter] = useState<SubjectFilter>(FILTER_ALL);
  const [pendingFile, setPendingFile] = useState<PendingFile | null>(null); // waiting on subject choice before upload proceeds
  const [addSubjectOnly, setAddSubjectOnly] = useState(false); // "+" in filter row: create without an upload attached

  // Non-blocking inline error surface (no native Alert dependency), used
  // across upload / summary / quiz-generation failures on this screen.
  const [inlineError, setInlineError] = useState<string | null>(null);
  const alertInline = (msg: string) => {
    setInlineError(msg);
    setTimeout(() => setInlineError(null), 4000);
  };

  const fetchNotes = useCallback(async () => {
    if (!session) return;
    const { data, error } = await supabase
      .from('notes')
      .select('*')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false });
    if (!error && data) setNotes(data as Note[]);
  }, [session]);

  useEffect(() => {
    if (!session) return;
    Promise.all([fetchNotes(), fetchSubjects(session.user.id)]).finally(() => setLoadingNotes(false));
  }, [session, fetchNotes, fetchSubjects]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([fetchNotes(), session ? fetchSubjects(session.user.id) : Promise.resolve()]);
    setRefreshing(false);
  };

  const updateNote = (id: string, patch: Partial<Note>) =>
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, ...patch } : n)));

  const filteredNotes = useMemo(() => {
    if (filter === FILTER_ALL) return notes;
    if (filter === FILTER_UNCATEGORIZED) return notes.filter((n) => !n.subject_id);
    return notes.filter((n) => n.subject_id === filter);
  }, [notes, filter]);

  // --- Upload: pick a file, then ask which subject it belongs to ---
  const pickFile = async () => {
    if (isOffline || !session) return;
    const result = await DocumentPicker.getDocumentAsync({
      type: ['application/pdf', 'image/*', 'text/plain',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation'],
      copyToCacheDirectory: true,
    });
    if (result.canceled) return;

    const file = result.assets[0];
    const ext = file.name.split('.').pop()?.toLowerCase() ?? 'text';
    const fileType = (ext === 'pdf' ? 'pdf' : ext === 'docx' ? 'docx' : ext === 'pptx' ? 'pptx' : 'text') as Note['file_type'];
    setPendingFile({ uri: file.uri, name: file.name, fileType });
  };

  const proceedUpload = async (subjectId: string | null) => {
    const file = pendingFile;
    setPendingFile(null);
    if (!file || !session) return;
    setPicking(true);

    try {
      const tempId = `local-${Date.now()}`;
      const path = `${session.user.id}/${tempId}-${file.name}`;
      const fileData = await fetch(file.uri).then((r) => r.blob());

      const { error: uploadError } = await supabase.storage.from('notes').upload(path, fileData);
      if (uploadError) throw uploadError;

      const { data: noteRow, error: insertError } = await supabase
        .from('notes')
        .insert({
          user_id: session.user.id,
          subject_id: subjectId,
          title: file.name,
          file_path: path,
          file_type: file.fileType,
          processing_status: 'pending',
        } as any)
        .select()
        .single();
      if (insertError) throw insertError;

      setNotes((prev) => [noteRow as Note, ...prev]);
      updateNote(noteRow.id, { processing_status: 'processing' });

      const { data, error: fnError } = await supabase.functions.invoke('process-note', {
        body: { note_id: noteRow.id },
      });
      if (fnError) {
        const message = (fnError as any)?.context?.message ?? 'Note processing failed.';
        throw new Error(message);
      }

      const processedStatus = data?.note?.processing_status ?? 'done';
      updateNote(noteRow.id, { processing_status: processedStatus, extracted_text: data?.note?.extracted_text });

      // Auto-generate the summary right after extraction succeeds — this is
      // what makes the note feel "ready" the moment upload finishes.
      if (processedStatus === 'done') {
        generateSummary(noteRow.id);
      }
    } catch (e: any) {
      alertInline(e?.message ?? 'Upload failed. Please check your connection and try again.');
      fetchNotes();
    } finally {
      setPicking(false);
    }
  };

  // --- Summary ---
  const generateSummary = async (noteId: string) => {
    setSummaries((prev) => ({ ...prev, [noteId]: { status: 'loading' } }));
    try {
      const { data, error } = await supabase.functions.invoke('generate-summary', { body: { note_id: noteId } });
      if (error) {
        const message = (error as any)?.context?.message ?? 'Could not generate a summary.';
        setSummaries((prev) => ({ ...prev, [noteId]: { status: 'error', error: message } }));
        return;
      }
      setSummaries((prev) => ({ ...prev, [noteId]: { status: 'ready', data: data.summary.content } }));
      setExpanded((prev) => ({ ...prev, [noteId]: true }));
    } catch {
      setSummaries((prev) => ({ ...prev, [noteId]: { status: 'error', error: 'Could not generate a summary.' } }));
    }
  };

  const toggleExpand = (note: Note) => {
    const isOpen = !!expanded[note.id];
    setExpanded((prev) => ({ ...prev, [note.id]: !isOpen }));
    if (!isOpen && !summaries[note.id]) generateSummary(note.id);
  };

  // --- Generate Quiz from a note ---
  const generateQuizFromNote = async (note: Note) => {
    if (isOffline) return;
    setQuizGenerating(note.id);
    try {
      const { data, error } = await supabase.functions.invoke('generate-quiz', {
        body: { source_note_id: note.id, subject_id: note.subject_id, topic: note.title },
      });
      if (error) {
        const message = (error as any)?.context?.message ?? 'Could not generate a quiz from this note.';
        alertInline(message);
        return;
      }
      router.push(`/quiz/${data.quiz.id}`);
    } finally {
      setQuizGenerating(null);
    }
  };

  const askAiAboutNote = (note: Note) => {
    router.push({ pathname: '/(tabs)/tutor', params: { note_id: note.id, note_title: note.title } });
  };

  // --- Generate (or reopen) a flashcard deck from a note ---
  const generateFlashcardsFromNote = async (note: Note) => {
    if (isOffline) return;
    setFlashcardsGenerating(note.id);
    try {
      const { data, error } = await supabase.functions.invoke('generate-flashcards', {
        body: { source_note_id: note.id, subject_id: note.subject_id },
      });
      if (error) {
        const message = (error as any)?.context?.message ?? 'Could not generate flashcards from this note.';
        alertInline(message);
        return;
      }
      router.push(`/flashcards/${data.deck.id}`);
    } finally {
      setFlashcardsGenerating(null);
    }
  };

  const subjectById = useMemo(() => new Map(subjects.map((s) => [s.id, s])), [subjects]);

  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      <View className="px-6 pt-2 pb-4">
        <Text className="text-2xl font-bold text-ink dark:text-ink-dk">Your Notes</Text>
        <Text className="text-ink-muted dark:text-ink-muted-dk text-sm mt-1">
          Upload lecture notes, slides, or textbook pages — AI turns them into study material.
        </Text>
      </View>

      <View className="px-6 mb-2">
        <Button
          label={isOffline ? 'Offline — reconnect to upload' : picking ? 'Uploading...' : '📤  Upload a note'}
          onPress={pickFile}
          loading={picking}
          disabled={isOffline}
        />
      </View>

      <SubjectFilterRow
        subjects={subjects}
        value={filter}
        onChange={setFilter}
        onAddPress={() => setAddSubjectOnly(true)}
      />

      {inlineError && (
        <View className="mx-6 mt-1 mb-2 bg-danger/10 dark:bg-danger-dk/10 rounded-card px-4 py-2.5">
          <Text className="text-danger dark:text-danger-dk text-xs">{inlineError}</Text>
        </View>
      )}

      {loadingNotes ? (
        <View className="px-6 mt-4 gap-3">
          <SkeletonCard />
          <SkeletonCard />
        </View>
      ) : filteredNotes.length === 0 ? (
        <EmptyState
          emoji="📚"
          title={notes.length === 0 ? 'No notes yet' : 'Nothing here yet'}
          body={
            notes.length === 0
              ? 'Upload your first PDF, Word doc, slides, or a photo of your notes to get started.'
              : 'No notes filed under this subject yet.'
          }
        />
      ) : (
        <FlatList
          data={filteredNotes}
          keyExtractor={(n) => n.id}
          contentContainerClassName="px-6 gap-3 pb-6 mt-2"
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#38BDF8" />}
          renderItem={({ item }) => (
            <NoteCard
              note={item}
              subject={item.subject_id ? subjectById.get(item.subject_id) : undefined}
              isExpanded={!!expanded[item.id]}
              summary={summaries[item.id]}
              quizGenerating={quizGenerating === item.id}
              flashcardsGenerating={flashcardsGenerating === item.id}
              onToggleExpand={() => toggleExpand(item)}
              onRetrySummary={() => generateSummary(item.id)}
              onGenerateQuiz={() => generateQuizFromNote(item)}
              onGenerateFlashcards={() => generateFlashcardsFromNote(item)}
              onAskAi={() => askAiAboutNote(item)}
            />
          )}
        />
      )}

      {/* Subject assignment — opens right after a file is picked, before upload starts */}
      <SubjectPicker
        visible={!!pendingFile}
        onClose={() => setPendingFile(null)}
        onSelect={(subjectId) => proceedUpload(subjectId)}
        skipLabel="Uncategorized"
        title={`Which subject is "${pendingFile?.name ?? ''}" for?`}
      />

      {/* "+" from the filter row — just creates a subject, no note attached */}
      <SubjectPicker
        visible={addSubjectOnly}
        onClose={() => setAddSubjectOnly(false)}
        onSelect={(subjectId) => {
          setAddSubjectOnly(false);
          if (subjectId) setFilter(subjectId);
        }}
        title="New subject"
      />
    </SafeAreaView>
  );
}

function NoteCard({
  note,
  subject,
  isExpanded,
  summary,
  quizGenerating,
  flashcardsGenerating,
  onToggleExpand,
  onRetrySummary,
  onGenerateQuiz,
  onGenerateFlashcards,
  onAskAi,
}: {
  note: Note;
  subject?: { name: string; icon: string; color: string };
  isExpanded: boolean;
  summary?: SummaryState;
  quizGenerating: boolean;
  flashcardsGenerating: boolean;
  onToggleExpand: () => void;
  onRetrySummary: () => void;
  onGenerateQuiz: () => void;
  onGenerateFlashcards: () => void;
  onAskAi: () => void;
}) {
  const isDone = note.processing_status === 'done';
  const isBusy = note.processing_status === 'pending' || note.processing_status === 'processing';

  return (
    <Card>
      <Pressable onPress={isDone ? onToggleExpand : undefined} className="flex-row items-center">
        <Text className="text-2xl mr-3">{FILE_ICON[note.file_type]}</Text>
        <View className="flex-1">
          <Text className="text-ink dark:text-ink-dk font-semibold" numberOfLines={1}>
            {note.title}
          </Text>
          <View className="flex-row items-center gap-1.5 mt-0.5">
            <StatusLabel status={note.processing_status} />
            {subject && (
              <View className="flex-row items-center gap-0.5 ml-1">
                <Text className="text-[10px]">{subject.icon}</Text>
                <Text className="text-[10px] font-medium" style={{ color: subject.color }}>
                  {subject.name}
                </Text>
              </View>
            )}
          </View>
        </View>
        {isBusy && <ActivityIndicator color="#38BDF8" />}
        {isDone && <Text className="text-ink-muted dark:text-ink-muted-dk text-lg">{isExpanded ? '︿' : '﹀'}</Text>}
      </Pressable>

      {isDone && isExpanded && (
        <View className="mt-4 pt-4 border-t border-border/60 dark:border-border-dk">
          {/* Summary */}
          {summary?.status === 'loading' && (
            <View className="flex-row items-center gap-2 mb-3">
              <ActivityIndicator size="small" color="#38BDF8" />
              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs">Generating summary...</Text>
            </View>
          )}
          {summary?.status === 'error' && (
            <View className="mb-3">
              <Text className="text-danger dark:text-danger-dk text-xs mb-2">{summary.error}</Text>
              <Pressable onPress={onRetrySummary}>
                <Text className="text-accent dark:text-accent-dk text-xs font-semibold">Retry</Text>
              </Pressable>
            </View>
          )}
          {summary?.status === 'ready' && summary.data && (
            <View className="mb-4">
              <Text className="text-ink dark:text-ink-dk font-semibold text-sm mb-2">Key points</Text>
              {summary.data.key_points.map((pt, i) => (
                <Text key={i} className="text-ink-muted dark:text-ink-muted-dk text-xs mb-1">• {pt}</Text>
              ))}
              {summary.data.exam_tips?.length > 0 && (
                <>
                  <Text className="text-ink dark:text-ink-dk font-semibold text-sm mb-2 mt-3">Exam tips</Text>
                  {summary.data.exam_tips.map((tip, i) => (
                    <Text key={i} className="text-ink-muted dark:text-ink-muted-dk text-xs mb-1">💡 {tip}</Text>
                  ))}
                </>
              )}
            </View>
          )}

          {/* Actions */}
          <View className="gap-2">
            <View className="flex-row gap-2">
              <Pressable
                onPress={onGenerateQuiz}
                disabled={quizGenerating}
                className="flex-1 bg-primary dark:bg-primary-dk rounded-pill py-2.5 items-center flex-row justify-center gap-1.5"
              >
                {quizGenerating ? (
                  <ActivityIndicator size="small" color="#1E293B" />
                ) : (
                  <Text className="text-ink dark:text-white text-xs font-semibold">🎯 Quiz</Text>
                )}
              </Pressable>
              <Pressable
                onPress={onGenerateFlashcards}
                disabled={flashcardsGenerating}
                className="flex-1 bg-accent dark:bg-accent-dk rounded-pill py-2.5 items-center flex-row justify-center gap-1.5"
              >
                {flashcardsGenerating ? (
                  <ActivityIndicator size="small" color="#1E293B" />
                ) : (
                  <Text className="text-ink dark:text-white text-xs font-semibold">🗂️ Flashcards</Text>
                )}
              </Pressable>
            </View>
            <Pressable
              onPress={onAskAi}
              className="bg-secondary/40 dark:bg-secondary-dk/20 border border-primary/40 dark:border-primary-dk/40 rounded-pill py-2.5 items-center"
            >
              <Text className="text-ink dark:text-ink-dk text-xs font-semibold">🤖 Ask AI About This</Text>
            </Pressable>
          </View>
        </View>
      )}
    </Card>
  );
}

function StatusLabel({ status }: { status: Note['processing_status'] }) {
  const map: Record<Note['processing_status'], { text: string; className: string }> = {
    pending: { text: 'Queued...', className: 'text-ink-muted dark:text-ink-muted-dk' },
    processing: { text: 'AI is reading this note...', className: 'text-accent dark:text-accent-dk' },
    done: { text: 'Ready — tap for summary & actions', className: 'text-success dark:text-success-dk' },
    failed: { text: 'Processing failed — DOCX/PPTX not supported yet', className: 'text-danger dark:text-danger-dk' },
  };
  const { text, className } = map[status];
  return <Text className={`text-xs ${className}`}>{text}</Text>;
}
