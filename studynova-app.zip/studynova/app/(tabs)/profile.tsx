import { useState } from 'react';
import { View, Text, ScrollView, Pressable, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Card } from '@/components/Card';
import { useAuthStore } from '@/stores/useAuthStore';
import { supabase } from '@/services/supabase';

const MENU = [
  { label: 'Edit profile', icon: '✏️' },
  { label: 'Notification settings', icon: '🔔' },
  { label: 'Appearance', icon: '🌗' },
  { label: 'Manage subscription', icon: '💎' },
  { label: 'Privacy & data', icon: '🔒' },
  { label: 'Help & support', icon: '💬' },
];

export default function Profile() {
  const { profile, session, signOut, loadProfile } = useAuthStore();
  const [togglingPlan, setTogglingPlan] = useState(false);

  // CRITICAL MVP GAP, found in review: there is no real payment integration
  // yet (RevenueCat/Stripe was only ever sketched, never built), so a brand
  // new signup has zero in-app path to Premium — and note upload, summaries,
  // and quiz-from-note are all Premium-gated server-side. Without this,
  // nobody could test the primary journey without manually editing the DB.
  // This toggle is a temporary stand-in ONLY — replace with real purchase
  // flow + webhook-driven `subscriptions` sync before any real release.
  const toggleDevPlan = async () => {
    if (!session || !profile) return;
    setTogglingPlan(true);
    const nextPlan = profile.plan === 'premium' ? 'free' : 'premium';
    const { error } = await supabase.from('profiles').update({ plan: nextPlan }).eq('id', session.user.id);
    if (!error) await loadProfile();
    setTogglingPlan(false);
  };

  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      <ScrollView contentContainerClassName="px-6 pt-2 pb-8">
        <View className="items-center mb-6">
          <View className="w-20 h-20 rounded-full bg-secondary/50 dark:bg-secondary-dk/25 items-center justify-center mb-3">
            <Text className="text-3xl">{profile?.full_name?.[0]?.toUpperCase() ?? '🎓'}</Text>
          </View>
          <Text className="text-xl font-bold text-ink dark:text-ink-dk">{profile?.full_name ?? 'Student'}</Text>
          <View className={`mt-2 rounded-pill px-3 py-1 ${profile?.plan === 'premium' ? 'bg-warning/15 dark:bg-warning-dk/15' : 'bg-ink/5 dark:bg-white/10'}`}>
            <Text className={`text-xs font-semibold ${profile?.plan === 'premium' ? 'text-warning dark:text-warning-dk' : 'text-ink-muted dark:text-ink-muted-dk'}`}>
              {profile?.plan === 'premium' ? '💎 Premium' : 'Free plan'}
            </Text>
          </View>
        </View>

        {profile?.plan !== 'premium' && (
          <Card className="mb-6 bg-primary dark:bg-primary-dk border-0">
            <Text className="text-ink dark:text-white font-bold text-base mb-1">Go Premium</Text>
            <Text className="text-ink/70 dark:text-white/80 text-sm mb-3">
              Unlimited AI tutoring, unlimited quizzes, and full note-to-flashcard conversion.
            </Text>
            <Pressable
              onPress={toggleDevPlan}
              disabled={togglingPlan}
              className="self-start bg-white/50 dark:bg-white rounded-pill px-4 py-2 flex-row items-center gap-2"
            >
              {togglingPlan && <ActivityIndicator size="small" color="#1E293B" />}
              <Text className="text-ink dark:text-primary-dk font-semibold text-sm">Upgrade now (dev toggle)</Text>
            </Pressable>
          </Card>
        )}

        {profile?.plan === 'premium' && (
          <Pressable onPress={toggleDevPlan} disabled={togglingPlan} className="mb-6">
            <Text className="text-ink-muted dark:text-ink-muted-dk text-xs text-center underline">
              {togglingPlan ? 'Updating...' : 'Dev: switch back to Free plan'}
            </Text>
          </Pressable>
        )}

        <Card className="p-0 overflow-hidden mb-6">
          {MENU.map((item, i) => (
            <Pressable
              key={item.label}
              className={`flex-row items-center px-4 py-4 ${i !== MENU.length - 1 ? 'border-b border-border/60 dark:border-border-dk' : ''}`}
            >
              <Text className="text-lg mr-3">{item.icon}</Text>
              <Text className="flex-1 text-ink dark:text-ink-dk text-base">{item.label}</Text>
              <Text className="text-ink-muted dark:text-ink-muted-dk">›</Text>
            </Pressable>
          ))}
        </Card>

        <Pressable onPress={signOut} className="items-center py-3">
          <Text className="text-danger dark:text-danger-dk font-semibold">Log out</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}
