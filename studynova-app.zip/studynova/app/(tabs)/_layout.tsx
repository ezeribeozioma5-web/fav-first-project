import { Tabs } from 'expo-router';
import { Text } from 'react-native';
import { useColorScheme } from 'nativewind';

const ICONS: Record<string, string> = {
  index: '🏠',
  planner: '🗓️',
  tutor: '🤖',
  notes: '📄',
  quiz: '🎯',
  profile: '👤',
};

// Colors resolved manually (not via Tailwind classes) because React
// Navigation's tabBarActiveTintColor prop takes a raw color string, not a
// className. Kept in sync with tailwind.config.js's primary/ink tokens.
const LIGHT = { active: '#38BDF8', inactive: '#64748B', bar: '#FFFFFF', border: '#E5E7EB' };
const DARK = { active: '#7DD3FC', inactive: '#CBD5E1', bar: '#1E293B', border: '#334155' };

export default function TabsLayout() {
  // Mirrors the system setting used by the `dark:` variant elsewhere in the
  // app, so the tab bar stays in sync.
  const { colorScheme } = useColorScheme();
  const palette = colorScheme === 'dark' ? DARK : LIGHT;

  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: palette.active,
        tabBarInactiveTintColor: palette.inactive,
        tabBarStyle: {
          borderTopWidth: 1,
          borderTopColor: palette.border,
          backgroundColor: palette.bar,
          elevation: 8,
          height: 84,
          paddingTop: 8,
          paddingBottom: 24,
        },
        tabBarLabelStyle: { fontSize: 10, fontWeight: '600' },
        tabBarIcon: () => <Text style={{ fontSize: 20 }}>{ICONS[route.name]}</Text>,
      })}
    >
      <Tabs.Screen name="index" options={{ title: 'Home' }} />
      <Tabs.Screen name="planner" options={{ title: 'Planner' }} />
      <Tabs.Screen name="tutor" options={{ title: 'AI Tutor' }} />
      <Tabs.Screen name="notes" options={{ title: 'Notes' }} />
      <Tabs.Screen name="quiz" options={{ title: 'Practice' }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile' }} />
    </Tabs>
  );
}
