import { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, TextInput, ScrollView, Pressable, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { SkeletonCard } from '@/components/Skeleton';
import { EmptyState } from '@/components/EmptyState';
import { SubjectChip } from '@/components/SubjectChip';
import { SubjectPicker } from '@/components/SubjectPicker';
import { SubjectFilterRow, FILTER_ALL, FILTER_UNCATEGORIZED, type SubjectFilter } from '@/components/SubjectFilterRow';
import { useAuthStore } from '@/stores/useAuthStore';
import { useSubjectsStore } from '@/stores/useSubjectsStore';
import { FREE_TIER_LIMITS } from '@/theme/tokens';
import { supabase } from '@/services/supabase';
import { useIsOffline } from '@/hooks/useIsOffline';

interface QuizHistoryItem {
  id: string;
  title: string;
  topic: string;
  subject_id: string | null;
  created_at: string;
  latestScore: number | null;
  attemptStatus: 'not_started' | 'completed' | 'in_progress';
}

export default function QuizGenerator() {
  const { profile, session } = useAuthStore();
  const { subjects, fetchSubjects } = useSubjectsStore();
  const isPremium = profile?.plan === 'premium';
  const isOffline = useIsOffline();
  const router = useRouter();

  const [topic, setTopic] = useState('');
  const [genSubjectId, setGenSubjectId] = useState<string | null>(null);
  const [genPickerVisible, setGenPickerVisible] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [usedToday, setUsedToday] = useState(0); // TODO: hydrate from ai_usage_log
  const [serverLimitReached, setServerLimitReached] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [history, setHistory] = useState<QuizHistoryItem[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<SubjectFilter>(FILTER_ALL);
  const [addSubjectOnly, setAddSubjectOnly] = useState(false);

  const remaining = FREE_TIER_LIMITS.quizGenerationsPerDay - usedToday;
  const limitReached = (!isPremium && remaining <= 0) || serverLimitReached;

  const fetchHistory = useCallback(async () => {
    if (!session) return;
    const { data: quizzes } = await supabase
      .from('quizzes')
      .select('id, title, topic, subject_id, created_at')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false })
      .limit(20);
    if (!quizzes?.length) {
      setHistory([]);
      return;
    }

    const quizIds = quizzes.map((q) => q.id);
    // Ordered by started_at (always set) rather than completed_at (null for
    // in-progress attempts, which made "most recent" ambiguous — bug found
    // in review: an old completed attempt could shadow a newer in-progress
    // one, or vice versa, depending on how Postgres sorts nulls).
    const { data: attempts } = await supabase
      .from('quiz_attempts')
      .select('quiz_id, score, status, started_at')
      .in('quiz_id', quizIds)
      .order('started_at', { ascending: false });

    const latestByQuiz = new Map<string, { score: number | null; status: string }>();
    (attempts ?? []).forEach((a) => {
      if (!latestByQuiz.has(a.quiz_id)) latestByQuiz.set(a.quiz_id, { score: a.score, status: a.status });
    });

    setHistory(
      quizzes.map((q) => {
        const latest = latestByQuiz.get(q.id);
        return {
          ...q,
          latestScore: latest?.score ?? null,
          attemptStatus: (latest?.status as any) ?? 'not_started',
        };
      })
    );
  }, [session]);

  useEffect(() => {
    if (!session) return;
    Promise.all([fetchHistory(), fetchSubjects(session.user.id)]).finally(() => setHistoryLoading(false));
  }, [session, fetchHistory, fetchSubjects]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([fetchHistory(), session ? fetchSubjects(session.user.id) : Promise.resolve()]);
    setRefreshing(false);
  };

  const filteredHistory = useMemo(() => {
    if (filter === FILTER_ALL) return history;
    if (filter === FILTER_UNCATEGORIZED) return history.filter((h) => !h.subject_id);
    return history.filter((h) => h.subject_id === filter);
  }, [history, filter]);

  const genSubject = subjects.find((s) => s.id === genSubjectId);

  const generate = async () => {
    if (!topic.trim() || limitReached) return;
    if (isOffline) {
      setErrorMessage("You're offline — reconnect to generate a quiz.");
      return;
    }
    setGenerating(true);
    setErrorMessage(null);
    try {
      const { data, error } = await supabase.functions.invoke('generate-quiz', {
        body: { topic, subject_id: genSubjectId ?? undefined },
      });
      if (error) {
        const ctx = (error as any)?.context;
        if (ctx?.error === 'daily_limit_reached') setServerLimitReached(true);
        setErrorMessage(ctx?.message ?? 'Could not generate a quiz. Please try again.');
        return;
      }
      setUsedToday((n) => n + 1);
      setTopic('');
      router.push(`/quiz/${data.quiz.id}`);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      <ScrollView
        contentContainerClassName="px-6 pt-2 pb-8"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#38BDF8" />}
      >
        <Text className="text-2xl font-bold text-ink dark:text-ink-dk mb-1">Practice</Text>
        <Text className="text-ink-muted dark:text-ink-muted-dk text-sm mb-6">
          Generate a quick quiz on any topic, or from one of your uploaded notes.
        </Text>

        {!isPremium && (
          <View className="bg-secondary/40 dark:bg-secondary-dk/15 rounded-card px-4 py-3 mb-5 flex-row justify-between items-center">
            <Text className="text-accent dark:text-accent-dk text-sm font-semibold">
              {Math.max(remaining, 0)}/{FREE_TIER_LIMITS.quizGenerationsPerDay} quizzes left today
            </Text>
          </View>
        )}

        <Card className="mb-6">
          <Text className="text-ink dark:text-ink-dk font-semibold mb-2">What do you want to practice?</Text>
          <TextInput
            value={topic}
            onChangeText={setTopic}
            placeholder="e.g. Photosynthesis, Newton's laws, French Revolution..."
            placeholderTextColor="#94A3B8"
            className="bg-bg dark:bg-bg-dk text-ink dark:text-ink-dk rounded-card px-4 py-3 border border-border dark:border-border-dk text-base mb-3"
          />

          {subjects.length > 0 && (
            <View className="flex-row items-center flex-wrap gap-2 mb-4">
              <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mr-1">Subject:</Text>
              {genSubject ? (
                <SubjectChip subject={genSubject} selected onPress={() => setGenPickerVisible(true)} />
              ) : (
                <Pressable
                  onPress={() => setGenPickerVisible(true)}
                  className="rounded-pill px-3.5 py-2 border border-dashed border-border dark:border-border-dk"
                >
                  <Text className="text-ink-muted dark:text-ink-muted-dk text-sm">None — tap to add</Text>
                </Pressable>
              )}
            </View>
          )}

          <Button
            label={limitReached ? 'Daily limit reached' : generating ? 'Generating...' : 'Generate quiz'}
            onPress={generate}
            loading={generating}
            disabled={limitReached || !topic.trim()}
          />
          {errorMessage && <Text className="text-danger dark:text-danger-dk text-sm mt-3">{errorMessage}</Text>}
        </Card>

        <Text className="text-lg font-bold text-ink dark:text-ink-dk mb-3">Your quizzes</Text>
        <SubjectFilterRow
          subjects={subjects}
          value={filter}
          onChange={setFilter}
          onAddPress={() => setAddSubjectOnly(true)}
        />
        <View className="h-1" />

        {historyLoading ? (
          <View className="gap-3">
            <SkeletonCard />
            <SkeletonCard />
          </View>
        ) : filteredHistory.length === 0 ? (
          <EmptyState
            emoji="🎯"
            title={history.length === 0 ? 'No quizzes yet' : 'Nothing here yet'}
            body={
              history.length === 0
                ? 'Generate one above, or from a processed note in the Notes tab.'
                : 'No quizzes filed under this subject yet.'
            }
          />
        ) : (
          <View className="gap-3">
            {filteredHistory.map((q) => (
              <Pressable key={q.id} onPress={() => router.push(`/quiz/${q.id}`)}>
                <Card className="flex-row items-center justify-between">
                  <View className="flex-1 mr-3">
                    <Text className="text-ink dark:text-ink-dk font-semibold text-sm" numberOfLines={1}>
                      {q.title}
                    </Text>
                    <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mt-0.5">
                      {q.attemptStatus === 'completed'
                        ? `Last score: ${q.latestScore}%`
                        : q.attemptStatus === 'in_progress'
                        ? 'Attempted, not finished'
                        : 'Not started yet'}
                    </Text>
                  </View>
                  <View
                    className={`rounded-pill px-3 py-1.5 ${
                      q.attemptStatus === 'completed'
                        ? (q.latestScore ?? 0) >= 70
                          ? 'bg-success/15 dark:bg-success-dk/15'
                          : 'bg-warning/15 dark:bg-warning-dk/15'
                        : 'bg-secondary/40 dark:bg-secondary-dk/20'
                    }`}
                  >
                    <Text
                      className={`text-xs font-semibold ${
                        q.attemptStatus === 'completed'
                          ? (q.latestScore ?? 0) >= 70
                            ? 'text-success dark:text-success-dk'
                            : 'text-warning dark:text-warning-dk'
                          : 'text-accent dark:text-accent-dk'
                      }`}
                    >
                      {/* Tapping always starts a fresh attempt (no resume/review-only
                          mode yet) — label says so truthfully rather than "Review",
                          which previously implied viewing past results without
                          retaking. Known limitation, see README. */}
                      {q.attemptStatus === 'completed' ? 'Retake' : 'Start'}
                    </Text>
                  </View>
                </Card>
              </Pressable>
            ))}
          </View>
        )}
      </ScrollView>

      <SubjectPicker
        visible={genPickerVisible}
        onClose={() => setGenPickerVisible(false)}
        onSelect={(id) => { setGenSubjectId(id); setGenPickerVisible(false); }}
        skipLabel="No subject"
        title="Tag this quiz with a subject"
      />

      <SubjectPicker
        visible={addSubjectOnly}
        onClose={() => setAddSubjectOnly(false)}
        onSelect={(subjectId) => {
          setAddSubjectOnly(false);
          if (subjectId) setFilter(subjectId);
        }}
        title="New subject"
      />
    </SafeAreaView>
  );
}
