import { useState } from 'react';
import { View, Text, TextInput, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Link, useRouter } from 'expo-router';
import { Button } from '@/components/Button';
import { supabase } from '@/services/supabase';
import { APP_NAME } from '@/theme/tokens';
import { useIsOffline } from '@/hooks/useIsOffline';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const isOffline = useIsOffline();

  const handleLogin = async () => {
    setError(null);
    if (isOffline) {
      setError("You're offline — reconnect to log in.");
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    router.replace('/(tabs)');
  };

  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1">
        <ScrollView contentContainerClassName="flex-1 px-6 justify-center" keyboardShouldPersistTaps="handled">
          <Text className="text-3xl font-bold text-ink dark:text-ink-dk mb-1">Welcome back</Text>
          <Text className="text-base text-ink-muted dark:text-ink-muted-dk mb-8">
            Log in to {APP_NAME} to keep your streak going.
          </Text>

          <Text className="text-sm font-medium text-ink dark:text-ink-dk mb-1.5">Email</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            placeholder="you@school.edu"
            placeholderTextColor="#94A3B8"
            className="bg-surface dark:bg-surface-dk text-ink dark:text-ink-dk rounded-card px-4 py-3.5 mb-4 border border-border dark:border-border-dk text-base"
          />

          <Text className="text-sm font-medium text-ink dark:text-ink-dk mb-1.5">Password</Text>
          <TextInput
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            placeholder="••••••••"
            placeholderTextColor="#94A3B8"
            className="bg-surface dark:bg-surface-dk text-ink dark:text-ink-dk rounded-card px-4 py-3.5 mb-2 border border-border dark:border-border-dk text-base"
          />

          {error && <Text className="text-danger dark:text-danger-dk text-sm mb-2">{error}</Text>}

          <View className="mt-4">
            <Button label="Log In" onPress={handleLogin} loading={loading} disabled={isOffline} />
          </View>

          <View className="flex-row justify-center mt-6">
            <Text className="text-ink-muted dark:text-ink-muted-dk">Don't have an account? </Text>
            <Link href="/(auth)/signup" className="text-accent dark:text-accent-dk font-semibold">
              Sign up
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
