import { useState } from 'react';
import { View, Text, TextInput, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Link, useRouter } from 'expo-router';
import { Button } from '@/components/Button';
import { supabase } from '@/services/supabase';
import { APP_NAME } from '@/theme/tokens';
import { useIsOffline } from '@/hooks/useIsOffline';

export default function Signup() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const isOffline = useIsOffline();

  const handleSignup = async () => {
    setError(null);
    if (isOffline) {
      setError("You're offline — reconnect to create an account.");
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    // A DB trigger (see supabase/schema.sql) creates the `profiles` row
    // automatically on signup, defaulted to the free plan.
    if (data.session) {
      router.replace('/(tabs)');
    } else {
      router.replace('/(auth)/login');
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1">
        <ScrollView contentContainerClassName="flex-1 px-6 justify-center" keyboardShouldPersistTaps="handled">
          <Text className="text-3xl font-bold text-ink dark:text-ink-dk mb-1">Create your account</Text>
          <Text className="text-base text-ink-muted dark:text-ink-muted-dk mb-8">
            Join {APP_NAME} and start studying smarter today.
          </Text>

          <Text className="text-sm font-medium text-ink dark:text-ink-dk mb-1.5">Full name</Text>
          <TextInput
            value={fullName}
            onChangeText={setFullName}
            placeholder="Ada Lovelace"
            placeholderTextColor="#94A3B8"
            className="bg-surface dark:bg-surface-dk text-ink dark:text-ink-dk rounded-card px-4 py-3.5 mb-4 border border-border dark:border-border-dk text-base"
          />

          <Text className="text-sm font-medium text-ink dark:text-ink-dk mb-1.5">Email</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            placeholder="you@school.edu"
            placeholderTextColor="#94A3B8"
            className="bg-surface dark:bg-surface-dk text-ink dark:text-ink-dk rounded-card px-4 py-3.5 mb-4 border border-border dark:border-border-dk text-base"
          />

          <Text className="text-sm font-medium text-ink dark:text-ink-dk mb-1.5">Password</Text>
          <TextInput
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            placeholder="At least 6 characters"
            placeholderTextColor="#94A3B8"
            className="bg-surface dark:bg-surface-dk text-ink dark:text-ink-dk rounded-card px-4 py-3.5 mb-2 border border-border dark:border-border-dk text-base"
          />

          {error && <Text className="text-danger dark:text-danger-dk text-sm mb-2">{error}</Text>}

          <View className="mt-4">
            <Button label="Create Account" onPress={handleSignup} loading={loading} disabled={isOffline} />
          </View>

          <View className="flex-row justify-center mt-6">
            <Text className="text-ink-muted dark:text-ink-muted-dk">Already have an account? </Text>
            <Link href="/(auth)/login" className="text-accent dark:text-accent-dk font-semibold">
              Log in
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
