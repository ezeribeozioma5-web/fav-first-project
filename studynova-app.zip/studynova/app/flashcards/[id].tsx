import { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
  interpolate,
  Extrapolation,
  runOnJS,
} from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { Button } from '@/components/Button';
import { supabase } from '@/services/supabase';

interface FlashcardRow {
  id: string;
  front: string;
  back: string;
  status: 'learning' | 'known' | 'review_later';
}

type ScreenState = 'loading' | 'studying' | 'done' | 'error';
const SWIPE_THRESHOLD = 120;

export default function FlashcardDeckScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();

  const [state, setState] = useState<ScreenState>('loading');
  const [deckTitle, setDeckTitle] = useState('');
  const [cards, setCards] = useState<FlashcardRow[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [statuses, setStatuses] = useState<Record<string, FlashcardRow['status']>>({});
  const [isFlipped, setIsFlipped] = useState(false);

  const translateX = useSharedValue(0);
  const flipRotation = useSharedValue(0);

  useEffect(() => {
    (async () => {
      if (!id) return;
      const { data: deck, error: deckError } = await supabase
        .from('flashcard_decks')
        .select('title')
        .eq('id', id)
        .single();
      const { data: cardRows, error: cardsError } = await supabase
        .from('flashcards')
        .select('id, front, back, status')
        .eq('deck_id', id)
        .order('order_index', { ascending: true });

      if (deckError || cardsError || !deck || !cardRows?.length) {
        setState('error');
        return;
      }

      setDeckTitle(deck.title);
      setCards(cardRows as FlashcardRow[]);
      setStatuses(Object.fromEntries(cardRows.map((c) => [c.id, c.status])));
      setState('studying');
    })();
  }, [id]);

  const currentCard = cards[currentIndex];

  const flip = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    flipRotation.value = withTiming(isFlipped ? 0 : 180, { duration: 350 });
    setIsFlipped((f) => !f);
  };

  const persistStatus = (cardId: string, status: FlashcardRow['status']) => {
    supabase
      .from('flashcards')
      .update({ status, last_reviewed_at: new Date().toISOString() })
      .eq('id', cardId)
      .then(({ error }) => {
        if (error) console.error('failed to save flashcard progress', error);
      });
  };

  const advance = (status: FlashcardRow['status']) => {
    if (!currentCard) return;
    setStatuses((prev) => ({ ...prev, [currentCard.id]: status }));
    persistStatus(currentCard.id, status);

    translateX.value = 0;
    flipRotation.value = 0;
    setIsFlipped(false);

    if (currentIndex < cards.length - 1) {
      setCurrentIndex((i) => i + 1);
    } else {
      setState('done');
    }
  };

  const panGesture = Gesture.Pan()
    .onUpdate((e) => {
      translateX.value = e.translationX;
    })
    .onEnd((e) => {
      if (e.translationX > SWIPE_THRESHOLD) {
        translateX.value = withTiming(500, { duration: 200 });
        runOnJS(advance)('known');
      } else if (e.translationX < -SWIPE_THRESHOLD) {
        translateX.value = withTiming(-500, { duration: 200 });
        runOnJS(advance)('review_later');
      } else {
        translateX.value = withSpring(0);
      }
    });

  const cardStyle = useAnimatedStyle(() => {
    const rotateZ = interpolate(translateX.value, [-300, 0, 300], [-12, 0, 12], Extrapolation.CLAMP);
    return { transform: [{ translateX: translateX.value }, { rotateZ: `${rotateZ}deg` }] };
  });

  const frontFaceStyle = useAnimatedStyle(() => ({
    transform: [{ rotateY: `${flipRotation.value}deg` }],
    opacity: flipRotation.value >= 90 ? 0 : 1,
    backfaceVisibility: 'hidden',
  }));
  const backFaceStyle = useAnimatedStyle(() => ({
    transform: [{ rotateY: `${flipRotation.value - 180}deg` }],
    opacity: flipRotation.value >= 90 ? 1 : 0,
    backfaceVisibility: 'hidden',
    position: 'absolute',
  }));

  const restart = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
    translateX.value = 0;
    flipRotation.value = 0;
    setState('studying');
  };

  if (state === 'loading') {
    return (
      <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk items-center justify-center">
        <ActivityIndicator size="large" color="#38BDF8" />
        <Text className="text-ink-muted dark:text-ink-muted-dk mt-3 text-sm">Loading flashcards...</Text>
      </SafeAreaView>
    );
  }

  if (state === 'error') {
    return (
      <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk items-center justify-center px-8">
        <Text className="text-4xl mb-3">😕</Text>
        <Text className="text-ink dark:text-ink-dk font-semibold mb-1">Couldn't load this deck</Text>
        <Button label="Go back" variant="secondary" onPress={() => router.back()} fullWidth={false} />
      </SafeAreaView>
    );
  }

  if (state === 'done') {
    const known = Object.values(statuses).filter((s) => s === 'known').length;
    const reviewLater = Object.values(statuses).filter((s) => s === 'review_later').length;
    const learning = Object.values(statuses).filter((s) => s === 'learning').length;
    return (
      <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk items-center justify-center px-8">
        <Text className="text-4xl mb-3">🎉</Text>
        <Text className="text-ink dark:text-ink-dk text-lg font-bold mb-1">Deck complete</Text>
        <Text className="text-ink-muted dark:text-ink-muted-dk text-sm mb-6">{deckTitle}</Text>

        <View className="flex-row gap-3 mb-8 w-full">
          <StatPill label="Known" value={known} colorClass="text-success dark:text-success-dk" />
          <StatPill label="Review later" value={reviewLater} colorClass="text-warning dark:text-warning-dk" />
          <StatPill label="Still learning" value={learning} colorClass="text-accent dark:text-accent-dk" />
        </View>

        <View className="w-full gap-3">
          <Button label="Study again" onPress={restart} />
          <Button label="Done" variant="ghost" onPress={() => router.back()} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-bg dark:bg-bg-dk">
      <View className="px-6 pt-2 pb-3">
        <View className="flex-row items-center justify-between mb-2">
          <Pressable onPress={() => router.back()}>
            <Text className="text-ink-muted dark:text-ink-muted-dk text-sm">✕ Exit</Text>
          </Pressable>
          <Text className="text-ink-muted dark:text-ink-muted-dk text-sm" numberOfLines={1}>
            {deckTitle}
          </Text>
        </View>
        <View className="h-2 bg-border dark:bg-border-dk rounded-pill overflow-hidden">
          <View
            className="h-full bg-primary dark:bg-primary-dk rounded-pill"
            style={{ width: `${((currentIndex + 1) / cards.length) * 100}%` }}
          />
        </View>
        <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mt-1.5">
          Card {currentIndex + 1} of {cards.length}
        </Text>
      </View>

      <View className="flex-1 items-center justify-center px-6">
        {currentCard && (
          <GestureDetector gesture={panGesture}>
            <Animated.View style={cardStyle} className="w-full">
              <Pressable onPress={flip}>
                <View style={{ height: 320 }}>
                  <Animated.View
                    style={[frontFaceStyle, { position: 'absolute', width: '100%', height: '100%' }]}
                    className="bg-surface dark:bg-surface-dk rounded-card border border-border dark:border-border-dk items-center justify-center px-6"
                  >
                    <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mb-3">TERM</Text>
                    <Text className="text-ink dark:text-ink-dk text-xl font-semibold text-center">
                      {currentCard.front}
                    </Text>
                    <Text className="text-ink-muted dark:text-ink-muted-dk text-xs mt-6">Tap to flip</Text>
                  </Animated.View>
                  <Animated.View
                    style={[backFaceStyle, { width: '100%', height: '100%' }]}
                    className="bg-primary/10 dark:bg-primary-dk/10 rounded-card border border-primary/40 dark:border-primary-dk/40 items-center justify-center px-6"
                  >
                    <Text className="text-accent dark:text-accent-dk text-xs mb-3">DEFINITION</Text>
                    <Text className="text-ink dark:text-ink-dk text-base text-center">{currentCard.back}</Text>
                  </Animated.View>
                </View>
              </Pressable>
            </Animated.View>
          </GestureDetector>
        )}
      </View>

      <View className="px-6 pb-6">
        <Text className="text-ink-muted dark:text-ink-muted-dk text-xs text-center mb-3">
          Swipe right if you know it, left to review later — or use the buttons
        </Text>
        <View className="flex-row gap-3">
          <Pressable
            onPress={() => advance('review_later')}
            className="flex-1 bg-warning/15 dark:bg-warning-dk/15 rounded-card py-3.5 items-center"
          >
            <Text className="text-warning dark:text-warning-dk font-semibold text-sm">📚 Review later</Text>
          </Pressable>
          <Pressable
            onPress={() => advance('known')}
            className="flex-1 bg-success/15 dark:bg-success-dk/15 rounded-card py-3.5 items-center"
          >
            <Text className="text-success dark:text-success-dk font-semibold text-sm">✅ Known</Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}

function StatPill({ label, value, colorClass }: { label: string; value: number; colorClass: string }) {
  return (
    <View className="flex-1 bg-surface dark:bg-surface-dk rounded-card py-4 items-center border border-border dark:border-border-dk">
      <Text className={`text-xl font-bold ${colorClass}`}>{value}</Text>
      <Text className="text-ink-muted dark:text-ink-muted-dk text-[10px] mt-1 text-center">{label}</Text>
    </View>
  );
}
